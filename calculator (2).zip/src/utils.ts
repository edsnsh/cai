import { CalculatorTool, ProjectionData } from "./types";

/**
 * Safely evaluates a math formula utilizing a scoped sandboxed execution.
 */
export function calculateFormula(
  formulaString: string,
  inputsState: Record<string, any>,
  toolId?: string
): number {
  if (toolId) {
    if (toolId === "mortgage_calculator") {
      const homePrice = Number(inputsState["home_price"] ?? 350000);
      const downPayment = Number(inputsState["down_payment"] ?? 20);
      const interestRate = Number(inputsState["interest_rate"] ?? 6.5);
      const termMonths = Number(inputsState["term_months"] ?? 360);
      const loanAmount = homePrice * (1 - downPayment / 100);
      const monthlyRate = interestRate / 1200;
      if (monthlyRate === 0) return loanAmount / termMonths;
      return loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);
    }

    if (toolId === "investment_calculator") {
      const principal = Number(inputsState["principal"] ?? 10000);
      const monthlyContribution = Number(inputsState["monthly_contribution"] ?? 300);
      const annualReturn = Number(inputsState["annual_return"] ?? 8.0);
      const termMonths = inputsState["term_months"] !== undefined
        ? Number(inputsState["term_months"])
        : (inputsState["years"] !== undefined ? Number(inputsState["years"]) * 12 : 120);
      const r = annualReturn / 1200;
      const m = Math.max(1, termMonths);
      const fvPrincipal = principal * Math.pow(1 + r, m);
      const fvAnnuity = r === 0 ? (monthlyContribution * m) : (monthlyContribution * (Math.pow(1 + r, m) - 1)) / r;
      return fvPrincipal + fvAnnuity;
    }

    if (toolId === "loan_calculator") {
      const loanAmount = Number(inputsState["loan_amount"] ?? 25000);
      const interestRate = Number(inputsState["interest_rate"] ?? 7.5);
      const termMonths = Number(inputsState["term_months"] ?? 60);
      const extraPayment = Number(inputsState["extra_payment"] ?? 0);
      const monthlyRate = interestRate / 1200;
      if (monthlyRate === 0) return loanAmount / termMonths;
      const basePayment = loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);
      return basePayment + extraPayment;
    }

    if (toolId === "debt_payoff_calculator") {
      const debtAmount = Number(inputsState["debt_amount"] ?? 5000);
      const interestRate = Number(inputsState["interest_rate"] ?? 22.0);
      const monthlyRate = interestRate / 1200;
      return debtAmount * monthlyRate;
    }

    if (toolId === "fifty_thirty_twenty_calculator") {
      const income = Number(inputsState["income"] ?? 5000);
      return income * 0.20;
    }

    if (toolId === "apr_calculator") {
      const loanAmount = Number(inputsState["loan_amount"] ?? 100000);
      const interestRate = Number(inputsState["interest_rate"] ?? 6.0);
      const closingCosts = Number(inputsState["closing_costs"] ?? 3000);
      const termMonths = Number(inputsState["term_months"] ?? 360);
      
      const netLoan = loanAmount - closingCosts;
      const rNominal = interestRate / 1200;
      const pmt = rNominal === 0 ? loanAmount / termMonths : loanAmount * (rNominal * Math.pow(1 + rNominal, termMonths)) / (Math.pow(1 + rNominal, termMonths) - 1);
      
      let low = 0;
      let high = 1.0;
      for (let iter = 0; iter < 40; iter++) {
        const mid = (low + high) / 2;
        const pVal = mid === 0 ? pmt * termMonths : pmt * (1 - Math.pow(1 + mid, -termMonths)) / mid;
        if (pVal > netLoan) {
          low = mid;
        } else {
          high = mid;
        }
      }
      return low * 1200;
    }

    if (toolId === "stock_profit_calculator") {
      const buyPrice = Number(inputsState["buy_price"] ?? 150);
      const sellPrice = Number(inputsState["sell_price"] ?? 185);
      const shares = Number(inputsState["shares"] ?? 100);
      const commissions = Number(inputsState["commissions"] ?? 15);
      return (sellPrice - buyPrice) * shares - commissions;
    }

    if (toolId === "dividend_yield_calculator") {
      const stockPrice = Number(inputsState["stock_price"] ?? 100);
      const annualDividend = Number(inputsState["annual_dividend"] ?? 4.0);
      if (stockPrice === 0) return 0;
      return (annualDividend / stockPrice) * 100;
    }

    if (toolId === "inflation_calculator") {
      const currentAmount = Number(inputsState["current_amount"] ?? 50000);
      const inflationRate = Number(inputsState["inflation_rate"] ?? 3.5);
      const years = Number(inputsState["years"] ?? 10);
      return currentAmount / Math.pow(1 + inflationRate / 100, years);
    }

    if (toolId === "emergency_fund_calculator") {
      const monthlyExpenses = Number(inputsState["monthly_expenses"] ?? 3500);
      const coverageMonths = Number(inputsState["coverage_months"] ?? 6);
      const currentSavings = Number(inputsState["current_savings"] ?? 5000);
      return Math.max(0, (monthlyExpenses * coverageMonths) - currentSavings);
    }

    if (toolId === "bmi_calculator") {
      const weight = Number(inputsState["weight"] ?? 70);
      const height = Number(inputsState["height"] ?? 175) / 100;
      if (height === 0) return 0;
      return weight / (height * height);
    }

    if (toolId === "bmr_calculator") {
      const height = Number(inputsState["height"] ?? 175);
      const weight = Number(inputsState["weight"] ?? 70);
      const age = Number(inputsState["age"] ?? 30);
      const gender = String(inputsState["gender"] ?? "Male");
      if (gender === "Male") {
        return 10 * weight + 6.25 * height - 5 * age + 5;
      } else {
        return 10 * weight + 6.25 * height - 5 * age - 161;
      }
    }

    if (toolId === "calories_burned_calculator") {
      const activity = String(inputsState["activity_type"] ?? "Running (9 km/h)");
      const duration = Number(inputsState["duration"] ?? 45);
      const weight = Number(inputsState["weight"] ?? 70);
      let met = 8.8;
      if (activity.includes("Running")) met = 8.8;
      else if (activity.includes("Bicycling")) met = 8.0;
      else if (activity.includes("Swimming")) met = 7.0;
      else if (activity.includes("Walking")) met = 3.5;
      else if (activity.includes("Weight Lifting")) met = 6.0;
      else if (activity.includes("Yoga")) met = 2.5;
      return (met * 3.5 * weight / 200) * duration;
    }

    if (toolId === "ideal_weight_calculator") {
      const height = Number(inputsState["height"] ?? 175);
      const gender = String(inputsState["gender"] ?? "Male");
      const inchesOver5Feet = Math.max(0, (height / 2.54) - 60);
      if (gender === "Male") {
        return 50.0 + 2.3 * inchesOver5Feet;
      } else {
        return 45.5 + 2.3 * inchesOver5Feet;
      }
    }

    if (toolId === "water_intake_calculator") {
      const weight = Number(inputsState["weight"] ?? 70);
      const activityDuration = Number(inputsState["activity_duration"] ?? 30);
      return (weight * 0.033) + (activityDuration / 30) * 0.35;
    }

    if (toolId === "protein_carb_fat_salt_calculator") {
      return Number(inputsState["calorie_target"] ?? 2000);
    }

    if (toolId === "body_fat_calculator") {
      const gender = String(inputsState["gender"] ?? "Male");
      const waist = Number(inputsState["waist"] ?? 85);
      const neck = Number(inputsState["neck"] ?? 38);
      const height = Number(inputsState["height"] ?? 175);
      const hip = Number(inputsState["hip"] ?? 95);
      if (gender === "Male") {
        if (waist <= neck) return 15;
        return 495 / (1.0324 - 0.19077 * Math.log10(waist - neck) + 0.15456 * Math.log10(height)) - 450;
      } else {
        if (waist + hip <= neck) return 22;
        return 495 / (1.29579 - 0.35004 * Math.log10(waist + hip - neck) + 0.22100 * Math.log10(height)) - 450;
      }
    }

    if (toolId === "age_calculator") {
      const year = Number(inputsState["birth_year"] ?? 1995);
      const month = Number(inputsState["birth_month"] ?? 6) - 1;
      const day = Number(inputsState["birth_day"] ?? 15);
      const birth = new Date(year, month, day);
      const now = new Date();
      let diffYears = now.getFullYear() - birth.getFullYear();
      if (now.getMonth() < birth.getMonth() || (now.getMonth() === birth.getMonth() && now.getDate() < birth.getDate())) {
        diffYears--;
      }
      return Math.max(0, diffYears);
    }

    if (toolId === "date_calculator") {
      const startDateStr = String(inputsState["start_date"] ?? "2026-07-01");
      const endDateStr = String(inputsState["end_date"] ?? "2026-12-31");

      const d1 = new Date(startDateStr);
      if (isNaN(d1.getTime())) return 0;

      const d2 = new Date(endDateStr);
      if (isNaN(d2.getTime())) return 0;

      const diffTime = d2.getTime() - d1.getTime();
      return Math.round(diffTime / (1000 * 60 * 60 * 24));
    }

    if (toolId === "payment_calculator") {
      const principal = Number(inputsState["principal"] ?? 15000);
      const annualRate = Number(inputsState["annual_rate"] ?? 6.0);
      const termMonths = Number(inputsState["term_months"] ?? (inputsState["loan_years"] !== undefined ? Number(inputsState["loan_years"]) * 12 : 60));
      const loanYears = termMonths / 12;
      const frequency = String(inputsState["frequency"] ?? "Monthly");

      let periodsPerYear = 12;
      if (frequency.includes("Bi-weekly")) periodsPerYear = 26;
      else if (frequency.includes("Weekly")) periodsPerYear = 52;

      const totalPeriods = loanYears * periodsPerYear;
      const ratePerPeriod = (annualRate / 100) / periodsPerYear;
      if (ratePerPeriod === 0) return principal / totalPeriods;
      return principal * (ratePerPeriod * Math.pow(1 + ratePerPeriod, totalPeriods)) / (Math.pow(1 + ratePerPeriod, totalPeriods) - 1);
    }

    if (toolId === "house_loan_calculator") {
      const housePrice = Number(inputsState["house_price"] ?? 400000);
      const downPct = Number(inputsState["down_payment_pct"] ?? 20);
      const interestRate = Number(inputsState["interest_rate"] ?? 6.5);
      const termMonths = Number(inputsState["term_months"] ?? (inputsState["loan_years"] !== undefined ? Number(inputsState["loan_years"]) * 12 : 360));
      const annualTax = Number(inputsState["annual_tax"] ?? 4800);
      const annualInsurance = Number(inputsState["annual_insurance"] ?? 1200);
      const monthlyHoa = Number(inputsState["monthly_hoa"] ?? 150);

      const loanAmount = housePrice * (1 - downPct / 100);
      const monthlyRate = interestRate / 1200;
      const totalMonths = termMonths;
      const pi = monthlyRate === 0 ? loanAmount / totalMonths : loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, totalMonths)) / (Math.pow(1 + monthlyRate, totalMonths) - 1);
      return pi + (annualTax / 12) + (annualInsurance / 12) + monthlyHoa;
    }

    if (toolId === "car_loan_calculator") {
      const vehiclePrice = Number(inputsState["vehicle_price"] ?? 32000);
      const downPayment = Number(inputsState["down_payment"] ?? 4000);
      const tradeIn = Number(inputsState["trade_in_value"] ?? 3000);
      const salesTaxPct = Number(inputsState["sales_tax_pct"] ?? 7.0);
      const interestRate = Number(inputsState["interest_rate"] ?? 5.5);
      const termMonths = Number(inputsState["term_months"] ?? 60);

      const taxable = Math.max(0, vehiclePrice - tradeIn);
      const tax = taxable * (salesTaxPct / 100);
      const financed = Math.max(0, vehiclePrice + tax - downPayment - tradeIn);
      const monthlyRate = interestRate / 1200;
      if (monthlyRate === 0) return financed / termMonths;
      return financed * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);
    }

    if (toolId === "tax_calculator") {
      const income = Number(inputsState["gross_income"] ?? 85000);
      const stateTaxRate = Number(inputsState["state_tax_rate"] ?? 4.5);
      const pretax = Number(inputsState["pretax_deductions"] ?? 6000);

      const taxable = Math.max(0, income - pretax);
      const fedTax = taxable * 0.18; // Average effective estimated rate
      const stateTax = taxable * (stateTaxRate / 100);
      return Math.max(0, income - pretax - fedTax - stateTax);
    }

    if (toolId === "retirement_calculator") {
      const currentAge = Number(inputsState["current_age"] ?? 32);
      const retAge = Number(inputsState["retirement_age"] ?? 65);
      const curSavings = Number(inputsState["current_savings"] ?? 45000);
      const monSavings = Number(inputsState["monthly_savings"] ?? 600);
      const retReturn = Number(inputsState["investment_return"] ?? 7.5);

      const years = Math.max(1, retAge - currentAge);
      const r = retReturn / 1200;
      const m = years * 12;
      const fvCapital = curSavings * Math.pow(1 + r, m);
      const fvAnnuity = r === 0 ? (monSavings * m) : (monSavings * (Math.pow(1 + r, m) - 1)) / r;
      return fvCapital + fvAnnuity;
    }

    if (toolId === "carbohydrate_calculator") {
      const calories = Number(inputsState["daily_calories"] ?? 2200);
      const dietGoal = String(inputsState["diet_goal"] ?? "Balanced (50% Carbs)");

      let ratio = 0.50;
      if (dietGoal.includes("Low-Carb")) ratio = 0.25;
      else if (dietGoal.includes("High-Carb")) ratio = 0.60;
      else if (dietGoal.includes("Keto")) ratio = 0.05;

      return (calories * ratio) / 4; // 4 kcal per gram of carbs
    }

    if (toolId === "protein_calculator") {
      const weight = Number(inputsState["weight"] ?? 75);
      const activity = String(inputsState["activity_level"] ?? "Moderate Exercise (3-4x/wk)");
      const goal = String(inputsState["goal"] ?? "Muscle Building");

      let mult = 1.6;
      if (activity.includes("Sedentary")) mult = 1.0;
      else if (activity.includes("Light")) mult = 1.2;
      else if (activity.includes("Intense")) mult = 2.0;

      if (goal.includes("Muscle Building")) mult += 0.2;
      else if (goal.includes("Fat Loss")) mult += 0.2;

      return weight * mult;
    }

    if (toolId === "calorie_calculator") {
      const gender = String(inputsState["gender"] ?? "Male");
      const age = Number(inputsState["age"] ?? 28);
      const height = Number(inputsState["height"] ?? 175);
      const weight = Number(inputsState["weight"] ?? 72);
      const activity = String(inputsState["activity"] ?? "Moderate (3-5 days/wk)");
      const goal = String(inputsState["goal"] ?? "Maintain Weight");

      const bmr = gender === "Male" ? (10 * weight + 6.25 * height - 5 * age + 5) : (10 * weight + 6.25 * height - 5 * age - 161);
      let actMult = 1.55;
      if (activity.includes("Sedentary")) actMult = 1.2;
      else if (activity.includes("Light")) actMult = 1.375;
      else if (activity.includes("Very Active")) actMult = 1.725;

      const tdee = bmr * actMult;
      let adj = 0;
      if (goal.includes("Mild Weight Loss")) adj = -250;
      else if (goal.includes("Weight Loss")) adj = -500;
      else if (goal.includes("Mild Weight Gain")) adj = +250;

      return Math.max(1200, tdee + adj);
    }

    if (toolId === "height_calculator") {
      const fH = Number(inputsState["father_height"] ?? 178);
      const mH = Number(inputsState["mother_height"] ?? 165);
      const gender = String(inputsState["child_gender"] ?? "Boy");

      if (gender.includes("Boy")) {
        return (fH + mH + 13) / 2;
      } else {
        return (fH + mH - 13) / 2;
      }
    }

    if (toolId === "weight_calculator") {
      const height = Number(inputsState["height"] ?? 175);
      const gender = String(inputsState["gender"] ?? "Male");
      const inchesOver5Ft = Math.max(0, (height / 2.54) - 60);

      if (gender === "Male") {
        return 50.0 + 2.3 * inchesOver5Ft;
      } else {
        return 45.5 + 2.3 * inchesOver5Ft;
      }
    }

    if (toolId === "time_calculator") {
      const h1 = Number(inputsState["hours_1"] ?? 4);
      const m1 = Number(inputsState["mins_1"] ?? 35);
      const s1 = Number(inputsState["secs_1"] ?? 20);
      const op = String(inputsState["operation"] ?? "Add (+)");
      const h2 = Number(inputsState["hours_2"] ?? 2);
      const m2 = Number(inputsState["mins_2"] ?? 45);
      const s2 = Number(inputsState["secs_2"] ?? 50);

      const tot1 = h1 * 3600 + m1 * 60 + s1;
      const tot2 = h2 * 3600 + m2 * 60 + s2;
      const res = op.includes("-") ? Math.max(0, tot1 - tot2) : (tot1 + tot2);
      return Math.round((res / 3600) * 100) / 100;
    }

    if (toolId === "birth_chart_calculator") {
      return 100;
    }

    if (toolId === "timecard_calculator") {
      const rate = Number(inputsState["hourly_rate"] ?? 28);
      const regHrs = Number(inputsState["regular_hours"] ?? 40);
      const otHrs = Number(inputsState["overtime_hours"] ?? 5);
      const otMult = String(inputsState["overtime_multiplier"] ?? "1.5x (Time & Half)").includes("2.0") ? 2.0 : 1.5;

      const regPay = regHrs * rate;
      const otPay = otHrs * rate * otMult;
      return regPay + otPay;
    }

    if (toolId === "grade_calculator") {
      const curGrade = Number(inputsState["current_grade"] ?? 82);
      const targetGrade = Number(inputsState["target_grade"] ?? 88);
      const weight = Number(inputsState["final_weight"] ?? 20) / 100;

      if (weight === 0) return 100;
      const req = (targetGrade - curGrade * (1 - weight)) / weight;
      return Math.round(req * 10) / 10;
    }

    if (toolId === "random_password_generator") {
      const len = Number(inputsState["password_length"] ?? 16);
      return len * 6; // entropy bits estimate
    }

    if (toolId === "speed_calculator") {
      const dist = Number(inputsState["distance"] ?? 10);
      const h = Number(inputsState["time_hours"] ?? 0);
      const m = Number(inputsState["time_minutes"] ?? 50);
      const s = Number(inputsState["time_seconds"] ?? 0);

      const totalHrs = h + (m / 60) + (s / 3600);
      if (totalHrs === 0) return 0;
      return Math.round((dist / totalHrs) * 10) / 10;
    }
  }

  try {
    const normalizedState: Record<string, any> = {};
    const varKeys: string[] = [];
    const varValues: any[] = [];
    
    // Normalize keys to allow safe JS identifiers
    Object.keys(inputsState).forEach(k => {
      const v = inputsState[k];
      const numericVal = typeof v === "string" ? (isNaN(Number(v)) ? v : Number(v)) : v;
      
      const safeKey = k.replace(/[^a-zA-Z0-9_]/g, "_");
      normalizedState[safeKey] = numericVal;
      
      if (safeKey !== k) {
        normalizedState[k] = numericVal;
      }
    });

    Object.keys(normalizedState).forEach(k => {
      if (/^[a-zA-Z_]/.test(k)) {
        varKeys.push(k);
        varValues.push(normalizedState[k]);
      }
    });

    let processedFormula = formulaString;
    Object.keys(inputsState).forEach(k => {
      if (k.includes("-") || k.includes(" ")) {
        const safeKey = k.replace(/[^a-zA-Z0-9_]/g, "_");
        const escaped = k.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        processedFormula = processedFormula.replace(new RegExp(escaped, 'g'), safeKey);
      }
    });

    const fn = new Function(
      ...varKeys,
      `
      const pow = Math.pow;
      const log = Math.log;
      const exp = Math.exp;
      const sqrt = Math.sqrt;
      const round = Math.round;
      const floor = Math.floor;
      const ceil = Math.ceil;
      const min = Math.min;
      const max = Math.max;
      const abs = Math.abs;
      const pi = Math.PI;
      const PI = Math.PI;
      
      try {
        return (${processedFormula});
      } catch (err) {
        return 0;
      }
      `
    );

    const result = fn(...varValues);
    return typeof result === "number" && !isNaN(result) && isFinite(result)
      ? result
      : 0;
  } catch (error) {
    console.warn("Formula evaluation failed:", error, formulaString);
    return 0;
  }
}

/**
 * Searches inputsState for a key with semantic keywords or returns fallback.
 */
function findValue(
  state: Record<string, any>,
  keywords: string[],
  fallback: number
): number {
  for (const k of Object.keys(state)) {
    const lowerKey = k.toLowerCase();
    if (keywords.some((kw) => lowerKey.includes(kw))) {
      const val = Number(state[k]);
      if (!isNaN(val)) return val;
    }
  }
  return fallback;
}

/**
 * Generates structural projections for drawing iOS-style charts dynamically.
 */
export function generateProjections(
  tool: CalculatorTool,
  inputsState: Record<string, any>
): ProjectionData[] {
  // --- Start Predefined Calculators Projections ---
  if (tool.id === "mortgage_calculator" || tool.tool_type === "mortgage") {
    const homePrice = Number(inputsState["home_price"] ?? inputsState["price"] ?? 0);
    const downPayment = Number(inputsState["down_payment"] ?? inputsState["down"] ?? 0);
    const interestRate = Number(inputsState["interest_rate"] ?? inputsState["rate"] ?? 0);
    const termYears = inputsState["years"] !== undefined ? Number(inputsState["years"]) : undefined;
    const termMonths = Number(inputsState["term_months"] ?? (termYears !== undefined ? termYears * 12 : null) ?? 360);

    const loanAmount = Math.max(0, homePrice * (1 - downPayment / 100));
    const monthlyRate = interestRate / 1200;
    
    const showMonthly = termMonths <= 30;
    const list: ProjectionData[] = [];

    list.push({
      label: showMonthly ? "Month 0" : "Start",
      value: Math.round(loanAmount),
      mainLabel: "Remaining Balance"
    });

    if (termMonths <= 0 || loanAmount <= 0) {
      list.push({
        label: showMonthly ? "Month 1" : "Year 1",
        value: 0,
        mainLabel: "Remaining Balance"
      });
      return list;
    }

    const monthlyPayment = monthlyRate === 0 
      ? loanAmount / termMonths
      : loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);

    let remainingPrincipal = loanAmount;
    let accumulatedInterest = 0;

    for (let m = 1; m <= termMonths; m++) {
      const interestForMonth = remainingPrincipal * monthlyRate;
      const principalForMonth = Math.min(remainingPrincipal, Math.max(0, monthlyPayment - interestForMonth));
      accumulatedInterest += interestForMonth;
      remainingPrincipal = Math.max(remainingPrincipal - principalForMonth, 0);

      if (showMonthly) {
        list.push({
          label: `Month ${m}`,
          value: Math.round(remainingPrincipal),
          mainLabel: "Remaining Balance"
        });
      } else {
        if (m % 12 === 0 || m === termMonths) {
          const yearNum = Math.ceil(m / 12);
          const label = m % 12 === 0 ? `Year ${yearNum}` : `Month ${m}`;
          list.push({
            label: label,
            value: Math.round(remainingPrincipal),
            mainLabel: "Remaining Balance"
          });
        }
      }
    }
    return list;
  }

  if (tool.id === "investment_calculator") {
    const principal = Number(inputsState["principal"] ?? inputsState["initial_investment"] ?? 0);
    const monthlyContribution = Number(inputsState["monthly_contribution"] ?? 0);
    const annualReturn = Number(inputsState["annual_return"] ?? inputsState["interest_rate"] ?? inputsState["annual_rate"] ?? 0);
    const termMonths = inputsState["term_months"] !== undefined
      ? Number(inputsState["term_months"])
      : (inputsState["years"] !== undefined ? Number(inputsState["years"]) * 12 : 120);
    const totalMonths = Math.max(1, termMonths);
    const showMonthly = totalMonths <= 36;

    const r = annualReturn / 1200;
    const list: ProjectionData[] = [];

    list.push({
      label: showMonthly ? "Month 0" : "Start",
      value: Math.round(principal),
      secondaryValue: Math.round(principal),
      secondaryLabel: "Contributions",
      mainLabel: "Balance"
    });

    if (showMonthly) {
      let currentBal = principal;
      let totalDeposited = principal;
      for (let m = 1; m <= totalMonths; m++) {
        currentBal = currentBal * (1 + r) + monthlyContribution;
        totalDeposited += monthlyContribution;
        list.push({
          label: `Month ${m}`,
          value: Math.round(currentBal),
          secondaryValue: Math.round(totalDeposited),
          secondaryLabel: "Contributions",
          mainLabel: "Balance"
        });
      }
    } else {
      const yearsCount = Math.ceil(totalMonths / 12);
      for (let y = 1; y <= yearsCount; y++) {
        const m = Math.min(y * 12, totalMonths);
        const fvPrincipal = principal * Math.pow(1 + r, m);
        const fvAnnuity = r === 0 
          ? (monthlyContribution * m)
          : (monthlyContribution * (Math.pow(1 + r, m) - 1)) / r;
        const totalAccumulated = Math.round(fvPrincipal + fvAnnuity);
        const totalDeposited = Math.round(principal + monthlyContribution * m);

        list.push({
          label: m % 12 === 0 ? `Year ${y}` : `Month ${m}`,
          value: totalAccumulated,
          secondaryValue: totalDeposited,
          secondaryLabel: "Contributions",
          mainLabel: "Balance"
        });
      }
    }
    return list;
  }

  if (tool.id === "loan_calculator") {
    const loanAmount = Number(inputsState["loan_amount"] ?? 0);
    const interestRate = Number(inputsState["interest_rate"] ?? 0);
    const termYears = inputsState["years"] !== undefined ? Number(inputsState["years"]) : undefined;
    const termMonths = Number(inputsState["term_months"] ?? (termYears !== undefined ? termYears * 12 : null) ?? 60);
    const extraPayment = Number(inputsState["extra_payment"] ?? 0);

    const showMonthly = termMonths <= 30;
    const monthlyRate = interestRate / 1200;
    const basePayment = monthlyRate === 0 
      ? (termMonths > 0 ? loanAmount / termMonths : 0)
      : loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);

    const list: ProjectionData[] = [];
    let remainingPrincipal = loanAmount;
    let accumulatedInterest = 0;

    list.push({
      label: showMonthly ? "Month 0" : "Start",
      value: Math.round(remainingPrincipal),
      secondaryValue: 0,
      secondaryLabel: "Interest Paid",
      mainLabel: "Remaining Balance"
    });

    if (termMonths <= 0 || loanAmount <= 0) {
      list.push({
        label: showMonthly ? "Month 1" : "Year 1",
        value: 0,
        secondaryValue: 0,
        secondaryLabel: "Interest Paid",
        mainLabel: "Remaining Balance"
      });
      return list;
    }

    for (let m = 1; m <= termMonths; m++) {
      if (remainingPrincipal <= 0) break;
      const interestForMonth = remainingPrincipal * monthlyRate;
      const actualPayment = Math.min(basePayment + extraPayment, remainingPrincipal + interestForMonth);
      const principalForMonth = Math.min(remainingPrincipal, Math.max(0, actualPayment - interestForMonth));
      accumulatedInterest += interestForMonth;
      remainingPrincipal = Math.max(remainingPrincipal - principalForMonth, 0);

      if (showMonthly) {
        list.push({
          label: `Month ${m}`,
          value: Math.round(remainingPrincipal),
          secondaryValue: Math.round(accumulatedInterest),
          secondaryLabel: "Cumul. Interest",
          mainLabel: "Remaining Balance"
        });
      } else {
        if (m % 12 === 0 || m === termMonths) {
          const yearNum = Math.ceil(m / 12);
          const label = m % 12 === 0 ? `Year ${yearNum}` : `Month ${m}`;
          list.push({
            label: label,
            value: Math.round(remainingPrincipal),
            secondaryValue: Math.round(accumulatedInterest),
            secondaryLabel: "Cumul. Interest",
            mainLabel: "Remaining Balance"
          });
        }
      }
    }
    return list;
  }

  if (tool.id === "debt_payoff_calculator") {
    const debtAmount = Number(inputsState["debt_amount"] ?? 0);
    const interestRate = Number(inputsState["interest_rate"] ?? 0);
    const monthlyPayment = Number(inputsState["monthly_payment"] ?? 0);

    const list: ProjectionData[] = [];
    const monthlyRate = interestRate / 1200;

    let balance = debtAmount;
    let accInterest = 0;
    let months = 0;

    const simulatedPoints: { m: number; bal: number; interest: number }[] = [];
    while (balance > 0 && months < 360) {
      months++;
      const interestForMonth = balance * monthlyRate;
      accInterest += interestForMonth;
      const paymentNeeded = monthlyPayment > 0 ? Math.min(monthlyPayment, balance + interestForMonth) : 0;
      if (paymentNeeded <= interestForMonth && interestForMonth > 0) {
        simulatedPoints.push({ m: months, bal: balance, interest: accInterest });
        break;
      }
      balance = Math.max(balance + interestForMonth - paymentNeeded, 0);
      simulatedPoints.push({ m: months, bal: balance, interest: accInterest });
    }

    const totalSimMonths = simulatedPoints.length;
    const showMonthly = totalSimMonths <= 30;

    list.push({
      label: showMonthly ? "Month 0" : "Start",
      value: Math.round(debtAmount),
      secondaryValue: 0,
      secondaryLabel: "Interest Paid",
      mainLabel: "Balance"
    });

    if (totalSimMonths === 0 || debtAmount <= 0) {
      list.push({
        label: showMonthly ? "Month 1" : "Year 1",
        value: 0,
        secondaryValue: 0,
        secondaryLabel: "Interest Paid",
        mainLabel: "Balance"
      });
      return list;
    }

    if (showMonthly) {
      simulatedPoints.forEach(pt => {
        list.push({
          label: `Month ${pt.m}`,
          value: Math.round(pt.bal),
          secondaryValue: Math.round(pt.interest),
          secondaryLabel: "Interest Paid",
          mainLabel: "Balance"
        });
      });
    } else {
      simulatedPoints.forEach(pt => {
        if (pt.m % 12 === 0 || pt.m === totalSimMonths) {
          const yearNum = Math.ceil(pt.m / 12);
          const label = pt.m % 12 === 0 ? `Year ${yearNum}` : `Month ${pt.m}`;
          list.push({
            label: label,
            value: Math.round(pt.bal),
            secondaryValue: Math.round(pt.interest),
            secondaryLabel: "Interest Paid",
            mainLabel: "Balance"
          });
        }
      });
    }
    return list;
  }

  if (tool.id === "fifty_thirty_twenty_calculator") {
    const income = Number(inputsState["income"] ?? 5000);
    const needs = Math.round(income * 0.50);
    const wants = Math.round(income * 0.30);
    const savings = Math.round(income * 0.20);

    return [
      { label: "Needs (50%)", value: needs },
      { label: "Wants (30%)", value: wants },
      { label: "Savings & Debt (20%)", value: savings }
    ];
  }

  if (tool.id === "apr_calculator") {
    const loanAmount = Number(inputsState["loan_amount"] ?? 100000);
    const interestRate = Number(inputsState["interest_rate"] ?? 6.0);
    const closingCosts = Number(inputsState["closing_costs"] ?? 3000);
    const trueApr = calculateFormula("", inputsState, "apr_calculator");
    return [
      { label: "Nominal Rate (%)", value: interestRate },
      { label: "Effective True APR (%)", value: Math.round(trueApr * 100) / 100 },
      { label: "Fees / Loan Ratio (%)", value: Math.round((closingCosts / loanAmount) * 10000) / 100 }
    ];
  }

  if (tool.id === "stock_profit_calculator") {
    const buyPrice = Number(inputsState["buy_price"] ?? 150);
    const sellPrice = Number(inputsState["sell_price"] ?? 185);
    const shares = Number(inputsState["shares"] ?? 100);
    const commissions = Number(inputsState["commissions"] ?? 15);
    const totalCost = buyPrice * shares;
    const totalSales = sellPrice * shares;
    const profit = (sellPrice - buyPrice) * shares - commissions;
    return [
      { label: "Total Capital Investment", value: totalCost },
      { label: "Ending Asset Sales", value: totalSales },
      { label: "Transaction Commissions", value: commissions },
      { label: "Net Trade Profit", value: Math.round(profit) }
    ];
  }

  if (tool.id === "dividend_yield_calculator") {
    const stockPrice = Number(inputsState["stock_price"] ?? 100);
    const annualDividend = Number(inputsState["annual_dividend"] ?? 4.0);
    const shares = Number(inputsState["shares"] ?? 250);
    const totalValue = stockPrice * shares;
    const annualIncome = annualDividend * shares;
    return [
      { label: "Total Portfolio Value", value: totalValue },
      { label: "Annual Dividend Income", value: annualIncome },
      { label: "5-Year Passive Earnings", value: annualIncome * 5 }
    ];
  }

  if (tool.id === "inflation_calculator") {
    const currentAmount = Number(inputsState["current_amount"] ?? 0);
    const inflationRate = Number(inputsState["inflation_rate"] ?? 0);
    const years = Number(inputsState["years"] ?? 10);
    const totalMonths = Math.max(1, years * 12);
    const showMonthly = totalMonths <= 30;

    const list: ProjectionData[] = [];
    list.push({
      label: showMonthly ? "Month 0" : "Start",
      value: Math.round(currentAmount),
      secondaryValue: Math.round(currentAmount),
      secondaryLabel: "Real Power Value",
      mainLabel: "Real Value"
    });

    if (showMonthly) {
      for (let m = 1; m <= totalMonths; m++) {
        const realPower = Math.round(currentAmount / Math.pow(1 + (inflationRate / 100) / 12, m));
        list.push({
          label: `Month ${m}`,
          value: realPower,
          secondaryValue: Math.round(currentAmount),
          secondaryLabel: "Nominal Cash",
          mainLabel: "Real Value"
        });
      }
    } else {
      for (let y = 1; y <= years; y++) {
        const futureNominal = currentAmount;
        const realPower = Math.round(currentAmount / Math.pow(1 + inflationRate / 100, y));
        list.push({
          label: `Year ${y}`,
          value: realPower,
          secondaryValue: Math.round(futureNominal),
          secondaryLabel: "Nominal Cash",
          mainLabel: "Real Value"
        });
      }
    }
    return list;
  }

  if (tool.id === "emergency_fund_calculator") {
    const monthlyExpenses = Number(inputsState["monthly_expenses"] ?? 3500);
    const coverageMonths = Number(inputsState["coverage_months"] ?? 6);
    const currentSavings = Number(inputsState["current_savings"] ?? 5000);
    const targetFund = monthlyExpenses * coverageMonths;
    return [
      { label: "Target Fund Need", value: targetFund },
      { label: "Current Liquid Savings", value: currentSavings },
      { label: "Fund Gap Remaining", value: Math.max(0, targetFund - currentSavings) }
    ];
  }

  if (tool.id === "bmi_calculator") {
    const bmiVal = calculateFormula("", inputsState, "bmi_calculator");
    return [
      { label: "Underweight Limit", value: 18.5 },
      { label: "Normal Limit", value: 24.9 },
      { label: "Overweight Limit", value: 29.9 },
      { label: "Your BMI Score", value: Math.round(bmiVal * 10) / 10 }
    ];
  }

  if (tool.id === "bmr_calculator") {
    const bmr = calculateFormula("", inputsState, "bmr_calculator");
    return [
      { label: "BMR Base resting rate", value: Math.round(bmr) },
      { label: "Sedentary Rest (1.2x)", value: Math.round(bmr * 1.2) },
      { label: "Light Activity (1.375x)", value: Math.round(bmr * 1.375) },
      { label: "Moderate Activity (1.55x)", value: Math.round(bmr * 1.55) },
      { label: "Very Active (1.725x)", value: Math.round(bmr * 1.725) }
    ];
  }

  if (tool.id === "calories_burned_calculator") {
    const duration = Number(inputsState["duration"] ?? 45);
    const weight = Number(inputsState["weight"] ?? 70);
    
    const mets = [
      { act: "Running (9 km/h)", met: 8.8 },
      { act: "Bicycling (mod)", met: 8.0 },
      { act: "Swimming (mod)", met: 7.0 },
      { act: "Walking (5 km/h)", met: 3.5 },
      { act: "Weight Lift (vig)", met: 6.0 },
      { act: "Yoga Class", met: 2.5 }
    ];

    return mets.map(m => ({
      label: m.act,
      value: Math.round((m.met * 3.5 * weight / 200) * duration * 10) / 10
    }));
  }

  if (tool.id === "ideal_weight_calculator") {
    const height = Number(inputsState["height"] ?? 175);
    const inchesOver5Feet = Math.max(0, (height / 2.54) - 60);
    
    // Robinson Formula
    const robinson = 52.0 + 1.9 * inchesOver5Feet;
    // Miller Formula
    const miller = 56.2 + 1.41 * inchesOver5Feet;
    // Devine Formula
    const devine = 50.0 + 2.3 * inchesOver5Feet;

    return [
      { label: "Robinson Std", value: Math.round(robinson * 10) / 10 },
      { label: "Miller Std", value: Math.round(miller * 10) / 10 },
      { label: "Devine Std", value: Math.round(devine * 10) / 10 }
    ];
  }

  if (tool.id === "water_intake_calculator") {
    const intake = calculateFormula("", inputsState, "water_intake_calculator");
    return [
      { label: "Minimum Hydration Target", value: Math.round(intake * 0.8 * 10) / 10 },
      { label: "Active Recommended Target", value: Math.round(intake * 10) / 10 },
      { label: "High Hot Weather Target", value: Math.round((intake + 0.6) * 10) / 10 }
    ];
  }

  if (tool.id === "body_fat_calculator") {
    const fatVal = calculateFormula("", inputsState, "body_fat_calculator");
    const leanRatio = Math.max(0, 100 - fatVal);
    return [
      { label: "Lean Mass (%)", value: Math.round(leanRatio * 10) / 10 },
      { label: "Estimated Body Fat (%)", value: Math.round(fatVal * 10) / 10 }
    ];
  }

  if (tool.id === "age_calculator") {
    const birthYear = Number(inputsState["birth_year"] ?? 1995);
    const birthMonth = Number(inputsState["birth_month"] ?? 6) - 1;
    const birthDay = Number(inputsState["birth_day"] ?? 15);
    const birth = new Date(birthYear, birthMonth, birthDay);
    const now = new Date();
    
    const diffMs = now.getTime() - birth.getTime();
    const diffDays = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
    const diffWeeks = Math.max(0, Math.floor(diffDays / 7));
    const diffMonths = Math.max(0, Math.floor(diffDays / 30.437));
    const currentAge = calculateFormula("", inputsState, "age_calculator");
    return [
      { label: "Total Days Lived", value: diffDays },
      { label: "Total Weeks Lived", value: diffWeeks },
      { label: "Total Months Lived", value: diffMonths },
      { label: "Current Age (Years)", value: currentAge }
    ];
  }
  // --- Backwards compatible fallback projections ---

  const type = tool.tool_type;
  const isSpecializedComp = ["mortgage", "compound_interest", "investment", "debt_payoff", "budget", "loan_calculator"].includes(type) || 
                            tool.id === "loss_tracker" || 
                            inputsState["daily_loss"] !== undefined;

  // Prioritize Formula Sweep for custom/generic tools with user-defined formulas (excluding specialized ones)
  if (tool && tool.formula && !isSpecializedComp) {
    const numericInputs = tool.inputs ? tool.inputs.filter(i => i.type === "slider" || i.type === "number") : [];
    if (numericInputs.length > 0) {
      const mainInput = numericInputs[0];
      const currentVal = inputsState[mainInput.id] ?? mainInput.default;
      
      // Determine bounds for the sweep
      const minVal = mainInput.min !== undefined ? mainInput.min : 0;
      const maxVal = mainInput.max !== undefined ? mainInput.max : (currentVal > 0 ? currentVal * 2 : 100);
      const stepSize = (maxVal - minVal) / 4 || 1;
      
      const data: ProjectionData[] = [];
      for (let i = 0; i <= 4; i++) {
         const tempVal = Number((minVal + stepSize * i).toFixed(1));
         const tempState = { ...inputsState, [mainInput.id]: tempVal };
         const computedResult = calculateFormula(tool.formula, tempState);
         
         data.push({
           label: `${mainInput.label.split("(")[0].trim()}: ${formatValue(tempVal, mainInput.prefix || "", mainInput.suffix || "")}`,
           value: Math.round(computedResult),
         });
      }
      return data;
    }
  }

  if (type === "compound_interest" || type === "investment") {
    if (tool.id === "interest_calculator") {
      const results = calculateInterestEarnings(inputsState);
      const data: ProjectionData[] = [];
      const totalMonths = Number(inputsState["years"] ?? 5) * 12 + Number(inputsState["months"] ?? 0);
      const showMonthly = totalMonths <= 30;

      if (showMonthly) {
        data.push({
          label: "Month 0",
          value: Math.round(Number(inputsState["initial_investment"] ?? 0)),
          secondaryValue: Math.round(Number(inputsState["initial_investment"] ?? 0)),
          secondaryLabel: "Contributions",
          mainLabel: "Balance"
        });

        const initInv = Number(inputsState["initial_investment"] ?? 0);
        const monthlyContrib = Number(inputsState["monthly_contribution"] ?? 0);
        const annualContrib = Number(inputsState["annual_contribution"] ?? 0);

        results.monthlySchedule.forEach((row) => {
          const m = row.period;
          const cumDeposits = initInv + (monthlyContrib * m) + (annualContrib * Math.floor(m / 12));
          data.push({
            label: `Month ${row.period}`,
            value: Math.round(row.endingBalance),
            secondaryValue: Math.round(cumDeposits),
            secondaryLabel: "Contributions",
            mainLabel: "Balance"
          });
        });
        return data;
      }

      const sched = results.yearlySchedule;
      const yearsCount = sched.length;

      data.push({
        label: "Start",
        value: Math.round(Number(inputsState["initial_investment"] ?? 0)),
        secondaryValue: Math.round(Number(inputsState["initial_investment"] ?? 0)),
        secondaryLabel: "Contributions",
        mainLabel: "Balance"
      });

      sched.forEach((row) => {
        const monthlyContrib = Number(inputsState["monthly_contribution"] ?? 0);
        const annualContrib = Number(inputsState["annual_contribution"] ?? 0);
        
        let cumDeposits = Number(inputsState["initial_investment"] ?? 0);
        const yr = row.period;
        const totalMonths = yr * 12;
        
        cumDeposits += (monthlyContrib * totalMonths) + (annualContrib * yr);

        data.push({
          label: `Year ${yr}`,
          value: Math.round(row.endingBalance),
          secondaryValue: Math.round(cumDeposits),
          secondaryLabel: "Contributions",
          mainLabel: "Balance"
        });
      });
      return data;
    }

    const principal = findValue(inputsState, ["principal", "init", "start", "balance", "amount"], 0);
    const rate = findValue(inputsState, ["rate", "apr", "interest", "return", "yield"], 0);
    const years = Math.min(Math.max(findValue(inputsState, ["years", "time", "period", "term", "duration"], 10), 0), 50);
    const monthly = findValue(inputsState, ["monthly", "contrib", "dep", "save", "addition"], 0);
    const totalMonths = years * 12;
    const showMonthly = totalMonths <= 30;

    const data: ProjectionData[] = [];
    let currentBalance = principal;
    let totalInvested = principal;
    const r = rate / 100 / 12;

    data.push({
      label: showMonthly ? "Month 0" : "Start",
      value: Math.round(principal),
      secondaryValue: Math.round(principal),
      secondaryLabel: "Contributions",
      mainLabel: "Balance"
    });

    if (showMonthly) {
      for (let m = 1; m <= totalMonths; m++) {
        currentBalance = (currentBalance + monthly) * (1 + r);
        totalInvested += monthly;
        data.push({
          label: `Month ${m}`,
          value: Math.round(currentBalance),
          secondaryValue: Math.round(totalInvested),
          secondaryLabel: "Contributions",
          mainLabel: "Balance"
        });
      }
    } else {
      for (let yr = 1; yr <= years; yr++) {
        for (let m = 0; m < 12; m++) {
          currentBalance = (currentBalance + monthly) * (1 + r);
          totalInvested += monthly;
        }
        data.push({
          label: `Year ${yr}`,
          value: Math.round(currentBalance),
          secondaryValue: Math.round(totalInvested),
          secondaryLabel: "Contributions",
          mainLabel: "Balance"
        });
      }
    }
    return data;
  }

  if (type === "debt_payoff") {
    const balance = findValue(inputsState, ["balance", "debt", "principal", "amount"], 0);
    const apr = findValue(inputsState, ["apr", "rate", "interest"], 0);
    const payment = findValue(inputsState, ["payment", "pay", "monthly"], 0);

    const data: ProjectionData[] = [];
    const monthlyRate = apr / 100 / 12;
    let currBalance = balance;
    let month = 0;
    let cumulativeInterest = 0;

    const simPoints: { m: number; bal: number; interest: number }[] = [];

    // Safely simulate up to 360 months (30 years) max
    while (currBalance > 0 && month < 360) {
      const interest = currBalance * monthlyRate;
      cumulativeInterest += interest;
      
      const pPay = payment - interest;
      if (pPay <= 0 && interest > 0) {
        simPoints.push({ m: month + 1, bal: currBalance, interest: cumulativeInterest });
        break;
      }

      currBalance -= pPay;
      if (currBalance < 0) currBalance = 0;
      month++;
      simPoints.push({ m: month, bal: currBalance, interest: cumulativeInterest });
    }

    const totalSim = simPoints.length;
    const showMonthly = totalSim <= 30;

    data.push({
      label: showMonthly ? "Month 0" : "Start",
      value: Math.round(balance),
      secondaryValue: 0,
      secondaryLabel: "Interest Paid",
      mainLabel: "Balance"
    });

    if (showMonthly) {
      simPoints.forEach(pt => {
        data.push({
          label: `Month ${pt.m}`,
          value: Math.round(pt.bal),
          secondaryValue: Math.round(pt.interest),
          secondaryLabel: "Interest Paid",
          mainLabel: "Balance"
        });
      });
    } else {
      simPoints.forEach(pt => {
        if (pt.m % 12 === 0 || pt.m === totalSim) {
          const yearNum = Math.ceil(pt.m / 12);
          const label = pt.m % 12 === 0 ? `Year ${yearNum}` : `Month ${pt.m}`;
          data.push({
            label: label,
            value: Math.round(pt.bal),
            secondaryValue: Math.round(pt.interest),
            secondaryLabel: "Interest Paid",
            mainLabel: "Balance"
          });
        }
      });
    }

    return data;
  }



  if (type === "loan_calculator") {
    const isAmortized = tool.id === "amortized_loan";
    const isDeferred = tool.id === "deferred_loan";
    const isBond = tool.id === "bond_loan";

    const loanAmt = Number(inputsState["loan_amount"] ?? inputsState["predetermined_amount"] ?? 100000);
    const years = Number(inputsState["years"] ?? 10);
    const months = Number(inputsState["months"] ?? 0);
    const rate = Number(inputsState["rate"] ?? 6);
    
    const totalMonths = (years * 12) + months;
    const periodicRate = rate / 100 / 12;

    let totalInterestPaid = 0;
    let amountReceivedAtStart = 0;

    if (totalMonths > 0) {
      if (isAmortized) {
        const pmnt = periodicRate === 0
          ? loanAmt / totalMonths
          : (loanAmt * (periodicRate * Math.pow(1 + periodicRate, totalMonths))) /
            (Math.pow(1 + periodicRate, totalMonths) - 1);
        totalInterestPaid = (pmnt * totalMonths) - loanAmt;
      } else if (isDeferred) {
        const compoundVal = inputsState["compound"] || "Annually (APY)";
        const isCompoundMonthly = compoundVal.toLowerCase().includes("monthly");
        let finalAmt = 0;
        if (isCompoundMonthly) {
          finalAmt = loanAmt * Math.pow(1 + periodicRate, totalMonths);
        } else {
          finalAmt = loanAmt * Math.pow(1 + (rate / 100), totalMonths / 12);
        }
        totalInterestPaid = finalAmt - loanAmt;
      } else if (isBond) {
        const compoundVal = inputsState["compound"] || "Annually (APY)";
        const isCompoundMonthly = compoundVal.toLowerCase().includes("monthly");
        if (isCompoundMonthly) {
          amountReceivedAtStart = loanAmt / Math.pow(1 + periodicRate, totalMonths);
        } else {
          amountReceivedAtStart = loanAmt / Math.pow(1 + (rate / 100), totalMonths / 12);
        }
        totalInterestPaid = loanAmt - amountReceivedAtStart;
      }
    } else {
      if (isBond) {
        amountReceivedAtStart = loanAmt;
      }
    }

    return [
      {
        label: isBond ? "Net Received Proceeds" : "Loan Principal",
        value: Math.round(isBond ? amountReceivedAtStart : loanAmt)
      },
      {
        label: "Total Interest Accrued",
        value: Math.round(totalInterestPaid)
      }
    ];
  }

  if (inputsState["daily_loss"] !== undefined || tool.id === "loss_tracker") {
    const dailyLoss = Number(inputsState["daily_loss"] ?? 400);
    const activeDays = Number(inputsState["active_days"] ?? 365);
    const otherLossMonthly = Number(inputsState["other_loss"] ?? 0);

    const totalYearlyDirectLoss = dailyLoss * activeDays;
    const totalYearlyOtherLoss = otherLossMonthly * 12;

    return [
      {
        label: "Daily Loss",
        value: Math.round(dailyLoss)
      },
      {
        label: "Weekly Loss",
        value: Math.round(dailyLoss * 7 + (otherLossMonthly / 4.33))
      },
      {
        label: "Monthly Cumulative",
        value: Math.round(dailyLoss * 30 + otherLossMonthly)
      },
      {
        label: "Annual Cumulative",
        value: Math.round(totalYearlyDirectLoss + totalYearlyOtherLoss)
      }
    ];
  }

  if (type === "budget" || tool.chart_type === "distribution") {
    // Generates a distribution comparisons bar chart
    const income = findValue(inputsState, ["income", "salary", "take_home", "earnings"], 4000);
    
    // 50/30/20 standard budget or custom allocation ratio
    const needsPct = findValue(inputsState, ["needs", "fixed", "essential"], 50);
    const wantsPct = findValue(inputsState, ["wants", "fun", "discretionary"], 30);
    const savingsPct = findValue(inputsState, ["savings", "investing", "future"], 20);

    const totalPct = needsPct + wantsPct + savingsPct;
    const normalizer = totalPct > 0 ? totalPct : 100;

    return [
      {
        label: "Fixed Needs",
        value: Math.round((income * needsPct) / normalizer),
        secondaryValue: 50,
        secondaryLabel: "Rule %",
      },
      {
        label: "Flexible Wants",
        value: Math.round((income * wantsPct) / normalizer),
        secondaryValue: 30,
        secondaryLabel: "Rule %",
      },
      {
        label: "Growth Savings",
        value: Math.round((income * savingsPct) / normalizer),
        secondaryValue: 20,
        secondaryLabel: "Rule %",
      },
    ];
  }

  if (tool.chart_type === "gauge") {
    const computedVal = calculateFormula(tool.formula, inputsState);
    return [
      {
        label: tool.output_label || "Score Index",
        value: computedVal,
      }
    ];
  }

  if (tool.chart_type === "comparison") {
    const rentVal = findValue(inputsState, ["rent"], 1500);
    const pVal = findValue(inputsState, ["price", "msrp", "value"], 300000);
    
    // Check years, term, and months cleanly to avoid years vs months mixup
    let yearsVal = inputsState["years"] ?? inputsState["term"] ?? null;
    let monthsVal = inputsState["months"] ?? null;
    let months = 120; // default 10 years
    
    if (yearsVal !== null) {
      months = Number(yearsVal) * 12;
    } else if (monthsVal !== null) {
      months = Number(monthsVal);
    } else {
      const fallbackYrs = findValue(inputsState, ["years", "term"], 10);
      months = fallbackYrs * 12;
    }
    
    // Check if Rent vs Buy or Rebate vs Low Interest
    if (tool.formula.includes("rebate")) {
      const rebate = findValue(inputsState, ["rebate"], 2000);
      const promoRate = findValue(inputsState, ["promo_rate"], 1.9);
      const withRebateRate = findValue(inputsState, ["with_rebate", "rate_with_rebate"], 6.0);
      
      const scenario1Cost = (pVal - rebate) * (withRebateRate / 100) * 5 + (pVal - rebate);
      const scenario2Cost = pVal * (promoRate / 100) * 5 + pVal;
      return [
        { label: "With Cash Back Rebate Option", value: Math.round(scenario1Cost) },
        { label: "With Low Promotional APR Option", value: Math.round(scenario2Cost) }
      ];
    } else {
      // Rent vs Buy comparison estimate
      const totalRentPaid = rentVal * months;
      // Buy cost estimate with 20% down payment simulated
      const totalBuyPaid = pVal * 0.20 + (pVal * 0.05 * (months / 12)); 
      return [
        { label: "Scenario A: Buying Cumulative Expense", value: Math.round(totalBuyPaid) },
        { label: "Scenario B: Renting Cumulative Expense", value: Math.round(totalRentPaid) }
      ];
    }
  }

  if (type === "salary") {
    const rawSalary = findValue(inputsState, ["salary", "wage", "income", "earnings"], 75000);
    
    // Standard tax breakdown approximation
    const federalTax = Math.round(rawSalary * 0.12);
    const stateTax = Math.round(rawSalary * 0.05);
    const ficaTax = Math.round(rawSalary * 0.0765);
    const netPay = Math.round(rawSalary - (federalTax + stateTax + ficaTax));

    return [
      { label: "Net Take-Home", value: netPay },
      { label: "Federal Tax (Est)", value: federalTax },
      { label: "State Tax (Est)", value: stateTax },
      { label: "FICA / Social Security", value: ficaTax },
    ];
  }

  if (type === "macronutrient") {
    const calories = findValue(inputsState, ["calories", "kcal", "energy"], 2000);
    const proteinRatio = findValue(inputsState, ["protein_ratio", "protein"], 30);
    const fatsRatio = findValue(inputsState, ["fats_ratio", "fats"], 30);
    // Leftover is Carb ratio
    const carbsRatio = Math.max(100 - (proteinRatio + fatsRatio), 0);

    const proteinGrams = (calories * (proteinRatio / 100)) / 4;
    const carbsGrams = (calories * (carbsRatio / 100)) / 4;
    const fatsGrams = (calories * (fatsRatio / 100)) / 9;

    return [
      {
        label: "Protein grams",
        value: Math.round(proteinGrams),
        secondaryValue: proteinRatio,
        secondaryLabel: "Protein %",
      },
      {
        label: "Carbohydrates grams",
        value: Math.round(carbsGrams),
        secondaryValue: carbsRatio,
        secondaryLabel: "Carbs %",
      },
      {
        label: "Healthy Fats grams",
        value: Math.round(fatsGrams),
        secondaryValue: fatsRatio,
        secondaryLabel: "Fats %",
      },
    ];
  }

  if (type === "freelancer_allocator") {
    const rev = findValue(inputsState, ["monthly_rev", "revenue", "monthly_revenue"], 8000);
    const taxRate = findValue(inputsState, ["tax_ratio", "tax"], 25);
    const expRate = findValue(inputsState, ["exp_ratio", "expenses"], 15);
    const invRate = findValue(inputsState, ["inv_ratio", "investments"], 20);

    const taxAmount = Math.round(rev * (taxRate / 100));
    const expAmount = Math.round(rev * (expRate / 100));
    const invAmount = Math.round(rev * (invRate / 100));
    const personalAmount = Math.max(rev - (taxAmount + expAmount + invAmount), 0);

    return [
      { label: "Net Owner Salary Draw", value: personalAmount, secondaryValue: Math.max(100 - taxRate - expRate - invRate, 0), secondaryLabel: "Share %" },
      { label: "Tax Buffer Reserves", value: taxAmount, secondaryValue: taxRate, secondaryLabel: "Tax %" },
      { label: "Business Overheads & SaaS", value: expAmount, secondaryValue: expRate, secondaryLabel: "Expenses %" },
      { label: "Compound Wealth Investments", value: invAmount, secondaryValue: invRate, secondaryLabel: "Invest %" }
    ];
  }

  if (type === "freelancer_wealth_multiplying_tracker") {
    const initVal = findValue(inputsState, ["init_reserve", "principal"], 1000);
    const monthlyDep = findValue(inputsState, ["monthly_dep", "monthly"], 500);
    const returnRate = findValue(inputsState, ["annual_return", "rate"], 20) / 100;
    const years = findValue(inputsState, ["growth_years", "years"], 10);

    const projectionsList: ProjectionData[] = [];
    
    // Create compounding points
    for (let i = 0; i <= 5; i++) {
      const currentYear = Math.max(Math.round((years / 5) * i), 1);
      
      const fvPrincipal = initVal * Math.pow(1 + returnRate, currentYear);
      const fvAnnuity = returnRate === 0 
        ? (monthlyDep * 12 * currentYear)
        : (monthlyDep * 12 * (Math.pow(1 + returnRate, currentYear) - 1)) / returnRate;
      
      const totalAccumulated = Math.round(fvPrincipal + fvAnnuity);
      const totalDeposited = Math.round(initVal + (monthlyDep * 12 * currentYear));

      projectionsList.push({
        label: `Year ${currentYear}`,
        value: totalAccumulated,
        secondaryValue: totalDeposited,
        secondaryLabel: "Deposited Principal"
      });
    }
    return projectionsList;
  }

  if (type === "age" || tool.chart_type === "countdown") {
    const day = findValue(inputsState, ["birth_day", "day"], 15);
    const month = findValue(inputsState, ["birth_month", "month"], 6);
    const year = findValue(inputsState, ["birth_year", "year"], 2000);

    const now = new Date();
    // Default fallback to 2026/06/02 if Date parses empty relative to system testing
    const birthDate = new Date(year, month - 1, day);
    
    // Total days lived
    const diffTime = Math.abs(now.getTime() - birthDate.getTime());
    const totalDaysLived = Math.floor(diffTime / (1000 * 60 * 60 * 24)) || 1;
    
    // Days until next birthday
    let nextBday = new Date(now.getFullYear(), month - 1, day);
    if (nextBday.getTime() < now.getTime()) {
      nextBday.setFullYear(now.getFullYear() + 1);
    }
    const daysToBday = Math.ceil((nextBday.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    // Percentage milestone through current year (from last birthday to next birthday)
    const lastBday = new Date(nextBday.getFullYear() - 1, month - 1, day);
    const totalYearMs = nextBday.getTime() - lastBday.getTime();
    const elapsedSinceLast = now.getTime() - lastBday.getTime();
    const pctYear = Math.min(Math.max(Math.round((elapsedSinceLast / totalYearMs) * 100), 0), 100);

    // Current exact age
    let currentAge = now.getFullYear() - year;
    const hasHadBdayThisYear = now.getMonth() > (month - 1) || (now.getMonth() === (month - 1) && now.getDate() >= day);
    if (!hasHadBdayThisYear) {
      currentAge -= 1;
    }

    // Days to key decade milestone (30, 40, etc)
    const nextDecade = Math.ceil((currentAge + 1) / 10) * 10;
    const decadeDate = new Date(year + nextDecade, month - 1, day);
    const daysToDecade = Math.ceil((decadeDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    return [
      {
        label: "Days Lived",
        value: totalDaysLived,
        secondaryValue: pctYear,
        secondaryLabel: "Year Progress %"
      },
      {
        label: "Days to Next Birthday",
        value: daysToBday,
        secondaryValue: currentAge,
        secondaryLabel: "Years Old Lived"
      },
      {
        label: "Days to Next Decade",
        value: daysToDecade,
        secondaryValue: nextDecade,
        secondaryLabel: "Target Decade"
      },
      {
        label: "Est. Lived Hours Sleept",
        value: Math.round(totalDaysLived * 8), // assuming 8 hours sleep per day
        secondaryValue: Math.round(totalDaysLived * 3), // eaten meals
        secondaryLabel: "Meals Consumed"
      }
    ];
  }

  if (type === "date_difference" || tool.tool_type === "date_difference") {
    const day = findValue(inputsState, ["start_day", "day"], 15);
    const month = findValue(inputsState, ["start_month", "month"], 12);
    const year = findValue(inputsState, ["start_year", "year"], 2026);

    const now = new Date(); // Current date e.g. June 2, 2026
    const targetDate = new Date(year, month - 1, day);

    // Calculate straight millisecond difference
    const diffTime = targetDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const absDays = Math.abs(diffDays);

    const labelDirection = diffDays >= 0 ? "Days Remaining" : "Days Elapsed";
    const statusLabel = diffDays >= 0 ? "Future Countdown" : "Past Duration";

    return [
      {
        label: labelDirection,
        value: absDays,
        secondaryValue: absDays * 24,
        secondaryLabel: "Total Hours"
      },
      {
        label: "Weeks Distance",
        value: Math.round(absDays / 7),
        secondaryValue: absDays * 1440,
        secondaryLabel: "Total Minutes"
      },
      {
        label: "Months Distance",
        value: Math.round(absDays / 30.4),
        secondaryValue: Math.round((absDays / 365) * 100),
        secondaryLabel: "Year Percentage"
      }
    ];
  }

  if (type === "boy_kilo" || tool.tool_type === "boy_kilo") {
    const weightKg = findValue(inputsState, ["weight_kg", "weight", "kilo"], 70);
    const heightCm = findValue(inputsState, ["height_cm", "height", "boy"], 175);

    const weightLbs = Math.round(weightKg * 2.20462 * 10) / 10;
    const heightInches = Math.round(heightCm * 0.393701 * 10) / 10;
    const bmi = heightCm === 0 ? 0 : Math.round((weightKg / Math.pow(heightCm / 100, 2)) * 10) / 10;

    return [
      {
        label: "Weight (Kg vs Lbs)",
        value: weightKg,
        secondaryValue: weightLbs,
        secondaryLabel: "Pounds (lbs)",
      },
      {
        label: "Height (Cm vs Inches)",
        value: heightCm,
        secondaryValue: heightInches,
        secondaryLabel: "Inches (in)",
      },
      {
        label: "Body Mass Index (BMI)",
        value: bmi,
        secondaryValue: 21.7,
        secondaryLabel: "Ideal Median Ref",
      }
    ];
  }

  // Dynamic Variable Sweep for Custom Calculators: Detects numeric inputs, varies the primary input
  // across 5 steps from its min to max (or fallback based on current value), and computes the formula results.
  const numericInputs = tool?.inputs ? tool.inputs.filter(i => i.type === "slider" || i.type === "number") : [];
  if (numericInputs.length > 0) {
    const mainInput = numericInputs[0];
    const currentVal = inputsState[mainInput.id] ?? mainInput.default;
    
    // Determine bounds for the sweep
    const minVal = mainInput.min !== undefined ? mainInput.min : 0;
    const maxVal = mainInput.max !== undefined ? mainInput.max : (currentVal > 0 ? currentVal * 2 : 100);
    const stepSize = (maxVal - minVal) / 4 || 1;
    
    const data: ProjectionData[] = [];
    for (let i = 0; i <= 4; i++) {
       const tempVal = Number((minVal + stepSize * i).toFixed(1));
       const tempState = { ...inputsState, [mainInput.id]: tempVal };
       const computedResult = calculateFormula(tool.formula, tempState);
       
       data.push({
         label: `${mainInput.label.split("(")[0].trim()}: ${formatValue(tempVal, mainInput.prefix || "", mainInput.suffix || "")}`,
         value: Math.round(computedResult),
       });
    }
    return data;
  }

  // Fallback Custom calculator coordinates - creates an illustrative 5-step growth / reduction curve
  const amount = findValue(inputsState, ["principal", "amount", "budget", "salary", "balance", "cost", "target", "input_a"], 1000);
  const factor = findValue(inputsState, ["rate", "apr", "interest", "multiplier", "factor", "input_b"], 10);
  
  const data: ProjectionData[] = [];
  for (let i = 0; i <= 4; i++) {
    const multiplier = 1 + (factor / 100) * i;
    data.push({
      label: `Point ${i + 1}`,
      value: Math.round(amount * multiplier),
    });
  }
  return data;
}

/**
 * Format currency numbers correctly (e.g. $10,420.50 or $5,420)
 */
export function formatValue(val: number, prefix = "", suffix = ""): string {
  if (isNaN(val) || !isFinite(val)) return prefix + "0" + suffix;
  
  // Format based on standard scale
  let formatted = "";
  if (Math.abs(val) >= 1_000_000) {
    formatted = (val / 1_000_000).toFixed(2).replace(/\.00$/, "") + "M";
  } else if (Math.abs(val) >= 1_000) {
    formatted = val.toLocaleString(undefined, { maximumFractionDigits: 0 });
  } else {
    formatted = val.toLocaleString(undefined, { maximumFractionDigits: 2 });
  }

  // Double symbol check - if prefix is $ and some string already has $, avoid duplicates
  const actualPrefix = prefix.trim();
  const actualSuffix = suffix.trim();

  return `${actualPrefix}${formatted}${actualSuffix}`;
}

export interface AmortizationRow {
  period: number;
  beginningBalance: number;
  payment: number;
  interest: number;
  principalPaid: number;
  endingBalance: number;
}

export function generateAmortizationSchedule(
  tool: CalculatorTool,
  inputsState: Record<string, any>
): { yearly: AmortizationRow[]; monthly: AmortizationRow[] } | null {
  const type = tool.tool_type;
  if (!["mortgage", "compound_interest", "investment", "debt_payoff", "freelancer_wealth_multiplying_tracker", "loan_calculator"].includes(type)) {
    return null;
  }

  const yearly: AmortizationRow[] = [];
  const monthly: AmortizationRow[] = [];

  if (type === "mortgage") {
    const price = Number(inputsState["price"] ?? inputsState["home_price"] ?? inputsState["house_price"] ?? 400000);
    const downPercent = Number(inputsState["down"] ?? inputsState["down_payment"] ?? inputsState["down_payment_pct"] ?? 20);
    const termYears = inputsState["years"] !== undefined ? Number(inputsState["years"]) : (inputsState["loan_years"] !== undefined ? Number(inputsState["loan_years"]) : undefined);
    const totalMonths = Number(inputsState["term_months"] ?? inputsState["months"] ?? (termYears !== undefined ? termYears * 12 : 360));
    const rate = Number(inputsState["rate"] ?? inputsState["interest_rate"] ?? inputsState["annual_rate"] ?? 6.576);

    const loanAmount = price * (1 - downPercent / 100);
    const monthlyRate = rate / 100 / 12;

    if (totalMonths <= 0) {
      return { yearly, monthly };
    }

    const monthlyPayment =
      monthlyRate === 0
        ? loanAmount / totalMonths
        : (loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, totalMonths))) /
          (Math.pow(1 + monthlyRate, totalMonths) - 1);

    let currBalance = loanAmount;
    let yearInterestAccumulator = 0;
    let yearPaymentAccumulator = 0;
    let yearPrincipalAccumulator = 0;
    let yearStartBalance = loanAmount;

    for (let m = 1; m <= totalMonths; m++) {
      const startBal = currBalance;
      const interest = currBalance * monthlyRate;
      const principal = Math.min(startBal, monthlyPayment - interest);
      currBalance = Math.max(0, currBalance - principal);

      monthly.push({
        period: m,
        beginningBalance: Number(startBal.toFixed(2)),
        payment: Number(monthlyPayment.toFixed(2)),
        interest: Number(interest.toFixed(2)),
        principalPaid: Number(principal.toFixed(2)),
        endingBalance: Number(currBalance.toFixed(2)),
      });

      yearInterestAccumulator += interest;
      yearPaymentAccumulator += monthlyPayment;
      yearPrincipalAccumulator += principal;

      if (m % 12 === 0 || m === totalMonths) {
        const yr = Math.ceil(m / 12);
        yearly.push({
          period: yr,
          beginningBalance: Number(yearStartBalance.toFixed(2)),
          payment: Number(yearPaymentAccumulator.toFixed(2)),
          interest: Number(yearInterestAccumulator.toFixed(2)),
          principalPaid: Number(yearPrincipalAccumulator.toFixed(2)),
          endingBalance: Number(currBalance.toFixed(2)),
        });

        // Reset year level accumulators
        yearInterestAccumulator = 0;
        yearPaymentAccumulator = 0;
        yearPrincipalAccumulator = 0;
        yearStartBalance = currBalance;
      }
    }
  } else if (type === "compound_interest" || type === "investment" || type === "freelancer_wealth_multiplying_tracker") {
    if (tool.id === "interest_calculator") {
      const results = calculateInterestEarnings(inputsState);
      return {
        yearly: results.yearlySchedule,
        monthly: results.monthlySchedule
      };
    }

    const isWealthTracker = type === "freelancer_wealth_multiplying_tracker";
    
    // Pick the right input mapping
    const principal = isWealthTracker 
      ? findValue(inputsState, ["init_reserve", "principal"], 1000)
      : findValue(inputsState, ["principal", "init", "start", "balance", "amount"], 5000);
      
    const rate = isWealthTracker
      ? findValue(inputsState, ["annual_return", "rate"], 20)
      : findValue(inputsState, ["rate", "apr", "interest", "return", "yield"], 8);
      
    const years = isWealthTracker
      ? findValue(inputsState, ["growth_years", "years"], 10)
      : Math.min(Math.max(findValue(inputsState, ["years", "time", "period", "term", "duration"], 10), 1), 50);
      
    const monthlyContribution = isWealthTracker
      ? findValue(inputsState, ["monthly_dep", "monthly"], 500)
      : findValue(inputsState, ["monthly", "contrib", "dep", "save", "addition"], 200);

    const r = rate / 100 / 12;
    const totalMonths = years * 12;

    if (totalMonths <= 0) {
      return { yearly, monthly };
    }

    let currBalance = principal;
    
    let yearInterestAccumulator = 0;
    let yearContributionAccumulator = 0;
    let yearStartBalance = principal;

    for (let m = 1; m <= totalMonths; m++) {
      const startBal = currBalance;
      const compoundBase = startBal + monthlyContribution;
      const compoundEnd = compoundBase * (1 + r);
      const interestEarned = compoundEnd - compoundBase;
      currBalance = compoundEnd;

      monthly.push({
        period: m,
        beginningBalance: Number(startBal.toFixed(2)),
        payment: Number(monthlyContribution.toFixed(2)),
        interest: Number(interestEarned.toFixed(2)),
        principalPaid: 0,
        endingBalance: Number(currBalance.toFixed(2))
      });

      yearInterestAccumulator += interestEarned;
      yearContributionAccumulator += monthlyContribution;

      if (m % 12 === 0 || m === totalMonths) {
        const yr = Math.ceil(m / 12);
        yearly.push({
          period: yr,
          beginningBalance: Number(yearStartBalance.toFixed(2)),
          payment: Number(yearContributionAccumulator.toFixed(2)),
          interest: Number(yearInterestAccumulator.toFixed(2)),
          principalPaid: 0,
          endingBalance: Number(currBalance.toFixed(2))
        });

        yearInterestAccumulator = 0;
        yearContributionAccumulator = 0;
        yearStartBalance = currBalance;
      }
    }
  } else if (type === "debt_payoff") {
    const balance = findValue(inputsState, ["balance", "debt", "principal", "amount"], 10000);
    const apr = findValue(inputsState, ["apr", "rate", "interest"], 22);
    const payment = findValue(inputsState, ["payment", "pay", "monthly"], 350);

    const monthlyRate = apr / 100 / 12;
    let currBalance = balance;
    let month = 0;

    let yearInterestAccumulator = 0;
    let yearPaymentAccumulator = 0;
    let yearPrincipalAccumulator = 0;
    let yearStartBalance = balance;

    while (currBalance > 0 && month < 360) {
      month++;
      const startBal = currBalance;
      const interest = currBalance * monthlyRate;
      
      const pPay = payment - interest;
      if (pPay <= 0 && interest > 0) {
        break;
      }

      const rawPrincipalPaid = Math.min(startBal, pPay);
      const actualPayment = rawPrincipalPaid + interest;
      currBalance = Math.max(0, currBalance - rawPrincipalPaid);

      monthly.push({
        period: month,
        beginningBalance: Number(startBal.toFixed(2)),
        payment: Number(actualPayment.toFixed(2)),
        interest: Number(interest.toFixed(2)),
        principalPaid: Number(rawPrincipalPaid.toFixed(2)),
        endingBalance: Number(currBalance.toFixed(2))
      });

      yearInterestAccumulator += interest;
      yearPaymentAccumulator += actualPayment;
      yearPrincipalAccumulator += rawPrincipalPaid;

      if (month % 12 === 0 || currBalance === 0) {
        const yr = Math.ceil(month / 12);
        yearly.push({
          period: yr,
          beginningBalance: Number(yearStartBalance.toFixed(2)),
          payment: Number(yearPaymentAccumulator.toFixed(2)),
          interest: Number(yearInterestAccumulator.toFixed(2)),
          principalPaid: Number(yearPrincipalAccumulator.toFixed(2)),
          endingBalance: Number(currBalance.toFixed(2))
        });

        yearInterestAccumulator = 0;
        yearPaymentAccumulator = 0;
        yearPrincipalAccumulator = 0;
        yearStartBalance = currBalance;
      }
    }
  } else if (type === "loan_calculator") {
    const isDeferred = tool.id === "deferred_loan";
    const isBond = tool.id === "bond_loan";
    const isAmortized = !isDeferred && !isBond;

    const loanAmount = Number(inputsState["loan_amount"] ?? inputsState["principal"] ?? inputsState["vehicle_price"] ?? inputsState["predetermined_amount"] ?? 100000);
    const termYears = inputsState["years"] !== undefined ? Number(inputsState["years"]) : (inputsState["loan_years"] !== undefined ? Number(inputsState["loan_years"]) : undefined);
    const totalMonths = Number(inputsState["term_months"] ?? inputsState["months"] ?? (termYears !== undefined ? termYears * 12 : 60));
    const rate = Number(inputsState["rate"] ?? inputsState["interest_rate"] ?? inputsState["annual_rate"] ?? 6);

    const monthlyRate = rate / 100 / 12;

    if (totalMonths <= 0) {
      return { yearly, monthly };
    }

    if (isAmortized) {
      const monthlyPayment =
        monthlyRate === 0
          ? loanAmount / totalMonths
          : (loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, totalMonths))) /
            (Math.pow(1 + monthlyRate, totalMonths) - 1);

      let currBalance = loanAmount;
      let yearInterestAccumulator = 0;
      let yearPaymentAccumulator = 0;
      let yearPrincipalAccumulator = 0;
      let yearStartBalance = loanAmount;

      for (let m = 1; m <= totalMonths; m++) {
        const startBal = currBalance;
        const interest = currBalance * monthlyRate;
        const principal = Math.min(startBal, monthlyPayment - interest);
        currBalance = Math.max(0, currBalance - principal);

        monthly.push({
          period: m,
          beginningBalance: Number(startBal.toFixed(2)),
          payment: Number(monthlyPayment.toFixed(2)),
          interest: Number(interest.toFixed(2)),
          principalPaid: Number(principal.toFixed(2)),
          endingBalance: Number(currBalance.toFixed(2)),
        });

        yearInterestAccumulator += interest;
        yearPaymentAccumulator += monthlyPayment;
        yearPrincipalAccumulator += principal;

        if (m % 12 === 0 || m === totalMonths) {
          const yr = Math.ceil(m / 12);
          yearly.push({
            period: yr,
            beginningBalance: Number(yearStartBalance.toFixed(2)),
            payment: Number(yearPaymentAccumulator.toFixed(2)),
            interest: Number(yearInterestAccumulator.toFixed(2)),
            principalPaid: Number(yearPrincipalAccumulator.toFixed(2)),
            endingBalance: Number(currBalance.toFixed(2)),
          });

          yearInterestAccumulator = 0;
          yearPaymentAccumulator = 0;
          yearPrincipalAccumulator = 0;
          yearStartBalance = currBalance;
        }
      }
    } else if (isDeferred) {
      const compoundVal = inputsState["compound"] || "Annually (APY)";
      const isCompoundMonthly = compoundVal.toLowerCase().includes("monthly");

      let currBalance = loanAmount;
      let yearInterestAccumulator = 0;
      let yearStartBalance = loanAmount;

      for (let m = 1; m <= totalMonths; m++) {
        const startBal = currBalance;
        let monthlyInterest = 0;
        if (isCompoundMonthly) {
          monthlyInterest = currBalance * (rate / 100 / 12);
        } else {
          monthlyInterest = currBalance * (Math.pow(1 + (rate / 100), 1 / 12) - 1);
        }
        currBalance += monthlyInterest;

        monthly.push({
          period: m,
          beginningBalance: Number(startBal.toFixed(2)),
          payment: 0,
          interest: Number(monthlyInterest.toFixed(2)),
          principalPaid: 0,
          endingBalance: Number(currBalance.toFixed(2)),
        });

        yearInterestAccumulator += monthlyInterest;

        if (m % 12 === 0 || m === totalMonths) {
          const yr = Math.ceil(m / 12);
          yearly.push({
            period: yr,
            beginningBalance: Number(yearStartBalance.toFixed(2)),
            payment: yr === Math.ceil(totalMonths / 12) ? Number(currBalance.toFixed(2)) : 0,
            interest: Number(yearInterestAccumulator.toFixed(2)),
            principalPaid: 0,
            endingBalance: Number(currBalance.toFixed(2)),
          });

          yearInterestAccumulator = 0;
          yearStartBalance = currBalance;
        }
      }
    } else if (isBond) {
      const compoundVal = inputsState["compound"] || "Annually (APY)";
      const isCompoundMonthly = compoundVal.toLowerCase().includes("monthly");

      let startPV = 0;
      if (isCompoundMonthly) {
        startPV = loanAmount / Math.pow(1 + monthlyRate, totalMonths);
      } else {
        startPV = loanAmount / Math.pow(1 + (rate / 100), totalMonths / 12);
      }

      let currBalance = startPV;
      let yearInterestAccumulator = 0;
      let yearStartBalance = startPV;

      for (let m = 1; m <= totalMonths; m++) {
        const startBal = currBalance;
        let monthlyInterest = 0;
        if (isCompoundMonthly) {
          monthlyInterest = currBalance * monthlyRate;
        } else {
          monthlyInterest = currBalance * (Math.pow(1 + (rate / 100), 1 / 12) - 1);
        }
        currBalance += monthlyInterest;

        monthly.push({
          period: m,
          beginningBalance: Number(startBal.toFixed(2)),
          payment: 0,
          interest: Number(monthlyInterest.toFixed(2)),
          principalPaid: 0,
          endingBalance: Number(currBalance.toFixed(2)),
        });

        yearInterestAccumulator += monthlyInterest;

        if (m % 12 === 0 || m === totalMonths) {
          const yr = Math.ceil(m / 12);
          yearly.push({
            period: yr,
            beginningBalance: Number(yearStartBalance.toFixed(2)),
            payment: yr === Math.ceil(totalMonths / 12) ? Number(currBalance.toFixed(2)) : 0,
            interest: Number(yearInterestAccumulator.toFixed(2)),
            principalPaid: 0,
            endingBalance: Number(currBalance.toFixed(2)),
          });

          yearInterestAccumulator = 0;
          yearStartBalance = currBalance;
        }
      }
    }
  }

  return { yearly, monthly };
}

export interface InterestCalculationResults {
  endingBalance: number;
  totalPrincipal: number;
  totalContributions: number;
  totalInterest: number;
  interestInitial: number;
  interestContributions: number;
  buyingPower: number;
  yearlySchedule: AmortizationRow[];
  monthlySchedule: AmortizationRow[];
}

export function calculateInterestEarnings(inputsState: Record<string, any>): InterestCalculationResults {
  const initialInvestment = Number(inputsState["initial_investment"] ?? inputsState["principal"] ?? inputsState["current_savings"] ?? 0);
  const annualContribution = Number(inputsState["annual_contribution"] ?? 0);
  const monthlyContribution = Number(inputsState["monthly_contribution"] ?? inputsState["monthly_savings"] ?? 0);
  const timing = inputsState["contribution_timing"] ?? "Beginning of period";
  const rawInterestRate = Number(inputsState["interest_rate"] ?? inputsState["annual_rate"] ?? inputsState["annual_return"] ?? inputsState["investment_return"] ?? inputsState["rate"] ?? 0);
  const frequency = inputsState["compound_frequency"] ?? "Monthly";
  const termMonths = inputsState["term_months"] !== undefined
    ? Number(inputsState["term_months"])
    : (inputsState["years"] !== undefined ? Number(inputsState["years"]) * 12 : 60);
  const months = Number(inputsState["months"] ?? 0);
  const taxRate = Number(inputsState["tax_rate"] ?? 0);
  const inflationRate = Number(inputsState["inflation_rate"] ?? 3);

  const totalMonths = Math.max(1, termMonths + months);
  const timingIsBeginning = timing.toLowerCase().includes("beginning");

  // Multiplier for compound frequency
  let c = 1; // compounding periods per year
  const freqLower = frequency.toLowerCase();
  if (freqLower.includes("daily")) c = 365;
  else if (freqLower.includes("monthly")) c = 12;
  else if (freqLower.includes("quarterly")) c = 4;
  else if (freqLower.includes("semi")) c = 2;
  else c = 1;

  // Adjust interest rate for tax
  const rateAfterTax = rawInterestRate * (1 - taxRate / 100);

  let balance = initialInvestment;
  let initialInvestmentBalance = initialInvestment;
  let totalPctContributions = 0;

  const yearlySchedule: AmortizationRow[] = [];
  const monthlySchedule: AmortizationRow[] = [];

  let accruedInterestBalance = 0;
  let accruedInterestInitial = 0;

  let yearStartBalance = balance;
  let yearInterestAccumulator = 0;
  let yearContributionAccumulator = 0;

  for (let m = 1; m <= totalMonths; m++) {
    const startBal = balance;

    let mContrib = 0;
    let yContrib = 0;

    // Beginning of period additions
    if (timingIsBeginning) {
      mContrib += monthlyContribution;
      if ((m - 1) % 12 === 0) {
        yContrib += annualContribution;
      }
    }

    balance += (mContrib + yContrib);
    totalPctContributions += (mContrib + yContrib);
    yearContributionAccumulator += (mContrib + yContrib);

    // Interest Accrual for this month
    if (c === 12) {
      // Monthly compounding
      const r_m = rateAfterTax / 100 / 12;
      const intBalance = balance * r_m;
      const intInitial = initialInvestmentBalance * r_m;

      balance += intBalance;
      initialInvestmentBalance += intInitial;

      accruedInterestBalance += intBalance;
      accruedInterestInitial += intInitial;
    } else if (c === 365) {
      // Daily compounding: approx 30.4167 days in a month
      const r_d = rateAfterTax / 100 / 365;
      const compoundFactor = Math.pow(1 + r_d, 365 / 12) - 1;

      const intBalance = balance * compoundFactor;
      const intInitial = initialInvestmentBalance * compoundFactor;

      balance += intBalance;
      initialInvestmentBalance += intInitial;

      accruedInterestBalance += intBalance;
      accruedInterestInitial += intInitial;
    } else {
      // Annually (1), semi-annually (2), quarterly (4)
      // Accumulate simple interest during the compounding interval
      const simpleFactor = rateAfterTax / 100 / 12;
      accruedInterestBalance += balance * simpleFactor;
      accruedInterestInitial += initialInvestmentBalance * simpleFactor;

      const compoundPeriodMonths = 12 / c;
      if (m % compoundPeriodMonths === 0 || m === totalMonths) {
        balance += accruedInterestBalance;
        initialInvestmentBalance += accruedInterestInitial;
        
        accruedInterestBalance = 0;
        accruedInterestInitial = 0;
      }
    }

    // End of period additions
    let endMContrib = 0;
    let endYContrib = 0;
    if (!timingIsBeginning) {
      endMContrib += monthlyContribution;
      if (m % 12 === 0 || m === totalMonths) {
        endYContrib += annualContribution;
      }
    }

    balance += (endMContrib + endYContrib);
    totalPctContributions += (endMContrib + endYContrib);
    yearContributionAccumulator += (endMContrib + endYContrib);

    // Record monthly schedule
    const endOfMonthInterest = balance - startBal - (mContrib + yContrib + endMContrib + endYContrib);
    monthlySchedule.push({
      period: m,
      beginningBalance: Number(startBal.toFixed(2)),
      payment: Number((mContrib + yContrib + endMContrib + endYContrib).toFixed(2)),
      interest: Number(Math.max(0, endOfMonthInterest).toFixed(2)),
      principalPaid: 0,
      endingBalance: Number(balance.toFixed(2))
    });

    yearInterestAccumulator += Math.max(0, endOfMonthInterest);

    // Record yearly schedule
    if (m % 12 === 0 || m === totalMonths) {
      const yr = Math.ceil(m / 12);
      yearlySchedule.push({
        period: yr,
        beginningBalance: Number(yearStartBalance.toFixed(2)),
        payment: Number(yearContributionAccumulator.toFixed(2)),
        interest: Number(yearInterestAccumulator.toFixed(2)),
        principalPaid: 0,
        endingBalance: Number(balance.toFixed(2))
      });

      yearStartBalance = balance;
      yearInterestAccumulator = 0;
      yearContributionAccumulator = 0;
    }
  }

  const endingBalance = balance;
  const totalPrincipal = initialInvestment + totalPctContributions;
  const totalInterest = Math.max(0, endingBalance - totalPrincipal);
  const interestInitial = Math.max(0, initialInvestmentBalance - initialInvestment);
  const interestContributions = Math.max(0, totalInterest - interestInitial);

  // Discount end balance back by inflation rate
  const buyingPower = endingBalance / Math.pow(1 + inflationRate / 100, totalMonths / 12);

  return {
    endingBalance,
    totalPrincipal,
    totalContributions: totalPctContributions,
    totalInterest,
    interestInitial,
    interestContributions,
    buyingPower,
    yearlySchedule,
    monthlySchedule
  };
}

export interface MathDetails {
  primaryText: string;
  steps: string[];
}

export function getMathResultDetails(
  toolId: string,
  inputsState: Record<string, any>,
  calculatedOutput: number
): MathDetails {
  const steps: string[] = [];
  let primaryText = "";

  if (toolId === "basic_calculator") {
    const a = Number(inputsState["a"] ?? 10);
    const b = Number(inputsState["b"] ?? 5);
    const op = String(inputsState["op"] ?? "+").trim();
    primaryText = `${a} ${op} ${b} = ${calculatedOutput}`;
    steps.push(`1. Extracted values: a = ${a}, b = ${b}`);
    steps.push(`2. Operation selected: ${op}`);
    steps.push(`3. Result: ${a} ${op} ${b} = ${calculatedOutput}`);
  }
  else if (toolId === "percentage_calculator") {
    const valueA = Number(inputsState["value_a"] ?? 15);
    const valueB = Number(inputsState["value_b"] ?? 200);
    const mode = String(inputsState["mode"] ?? "What is X% of Y?");
    if (mode === "What is X% of Y?") {
      primaryText = `${valueA}% of ${valueB} is ${calculatedOutput.toFixed(2)}`;
      steps.push(`1. Convert percentage to fraction: ${valueA} / 100 = ${(valueA/100).toFixed(4)}`);
      steps.push(`2. Multiply by base value Y: ${(valueA/100).toFixed(4)} * ${valueB}`);
      steps.push(`3. Solution: ${calculatedOutput.toFixed(2)}`);
    } else if (mode === "X is what % of Y?") {
      primaryText = `${valueA} is ${calculatedOutput.toFixed(2)}% of ${valueB}`;
      steps.push(`1. Divide X by Y: ${valueA} / ${valueB} = ${(valueA / (valueB || 1)).toFixed(4)}`);
      steps.push(`2. Convert to percentage: ${(valueA / (valueB || 1)).toFixed(4)} * 100`);
      steps.push(`3. Solution: ${calculatedOutput.toFixed(2)}%`);
    } else {
      primaryText = `Change from ${valueA} to ${valueB} is ${calculatedOutput.toFixed(2)}%`;
      const diff = valueB - valueA;
      steps.push(`1. Calculate nominal difference: ${valueB} - ${valueA} = ${diff}`);
      steps.push(`2. Divide difference by start value X: ${diff} / ${valueA} = ${(diff / (valueA || 1)).toFixed(4)}`);
      steps.push(`3. Multiply by 100 to get percentage: ${(diff / (valueA || 1)).toFixed(4)} * 100`);
      steps.push(`4. Solution: ${calculatedOutput.toFixed(2)}%`);
    }
  }
  else if (toolId === "fraction_calculator") {
    const numA = Number(inputsState["num_a"] ?? 1);
    const denA = Number(inputsState["den_a"] ?? 2) || 1;
    const numB = Number(inputsState["num_b"] ?? 1);
    const denB = Number(inputsState["den_b"] ?? 3) || 1;
    const op = String(inputsState["op"] ?? "+").trim();

    let resNum = 0;
    let resDen = denA * denB;

    if (op === "+") {
      resNum = numA * denB + numB * denA;
    } else if (op === "−" || op === "-") {
      resNum = numA * denB - numB * denA;
    } else if (op === "×" || op === "*") {
      resNum = numA * numB;
      resDen = denA * denB;
    } else if (op === "÷" || op === "/") {
      resNum = numA * denB;
      resDen = denA * numB;
    }

    const gcd = (x: number, y: number): number => {
      x = Math.abs(x);
      y = Math.abs(y);
      while (y) {
        const t = y;
        y = x % y;
        x = t;
      }
      return x;
    };

    const divisor = gcd(resNum, resDen) || 1;
    const simpNum = resNum / divisor;
    const simpDen = resDen / divisor;

    primaryText = `(${numA}/${denA}) ${op} (${numB}/${denB}) = ${simpNum}/${simpDen} (≈ ${calculatedOutput.toFixed(4)})`;
    steps.push(`1. Rationalize fractions: Fraction A = ${numA}/${denA}, Fraction B = ${numB}/${denB}`);
    if (op === "+" || op === "−" || op === "-") {
      steps.push(`2. Find common denominator: ${denA} * ${denB} = ${denA * denB}`);
      steps.push(`3. Scale numerators: ${numA} * ${denB} = ${numA * denB}, ${numB} * ${denA} = ${numB * denA}`);
      steps.push(`4. Compute operation: ${numA * denB} ${op === "+" ? "+" : "-"} ${numB * denA} = ${resNum}`);
    } else if (op === "×" || op === "*") {
      steps.push(`2. Multiply numerators: ${numA} * ${numB} = ${resNum}`);
      steps.push(`3. Multiply denominators: ${denA} * ${denB} = ${resDen}`);
    } else {
      steps.push(`2. Multiply fraction A by the reciprocal of fraction B: (${numA}/${denA}) * (${denB}/${numB})`);
      steps.push(`3. Compute multiplication: Numerator = ${numA * denB}, Denominator = ${denA * numB}`);
    }
    steps.push(`5. Simplify result ${resNum}/${resDen} by dividing by greatest common divisor (${divisor}): ${simpNum}/${simpDen}`);
  }
  else if (toolId === "exponent_calculator") {
    const b = Number(inputsState["base_val"] ?? 2);
    const y = Number(inputsState["exp_val"] ?? 5);
    primaryText = `${b}^${y} = ${calculatedOutput}`;
    steps.push(`1. Identify base (x = ${b}) and exponent (y = ${y})`);
    if (Math.abs(y) <= 15 && Math.floor(y) === y && y > 0) {
      const parts = Array(y).fill(b).join(" × ");
      steps.push(`2. Expand multiplication sequence: ${parts}`);
    } else if (y < 0) {
      steps.push(`2. Negative exponent rule x^-y = 1 / x^y: 1 / (${b}^${Math.abs(y)})`);
    } else {
      steps.push(`2. Solve using log base conversion: exp(y * ln(x))`);
    }
    steps.push(`3. Result: ${calculatedOutput}`);
  }
  else if (toolId === "square_root_calculator") {
    const inputVal = Number(inputsState["sqrt_input"] ?? 18);
    let coeff = 1;
    let inside = inputVal;
    
    if (inputVal >= 0) {
      for (let i = Math.floor(Math.sqrt(inputVal)); i >= 2; i--) {
        if (inputVal % (i * i) === 0) {
          coeff = i;
          inside = inputVal / (i * i);
          break;
        }
      }
    }
    
    if (coeff > 1) {
      primaryText = `√${inputVal} = ${coeff}√${inside} ≈ ${calculatedOutput.toFixed(4)}`;
    } else {
      primaryText = `√${inputVal} ≈ ${calculatedOutput.toFixed(4)}`;
    }
    
    steps.push(`1. Find root value of radicand ${inputVal}`);
    if (coeff > 1) {
      steps.push(`2. Extract largest square factor: ${coeff * coeff} * ${inside} = ${inputVal}`);
      steps.push(`3. Pull out radical square: √(${coeff * coeff}) * √${inside} = ${coeff}√${inside}`);
    } else {
      steps.push(`2. Radicand has no perfect square factors greater than 1.`);
    }
    steps.push(`4. Decimal equivalent: ≈ ${calculatedOutput.toFixed(4)}`);
  }
  else if (toolId === "linear_equation_solver") {
    const a = Number(inputsState["linear_a"] ?? 2);
    const b = Number(inputsState["linear_b"] ?? 4);
    const c = Number(inputsState["linear_c"] ?? 12);
    primaryText = `x = ${calculatedOutput.toFixed(4)}`;
    steps.push(`1. Standard expression form: ${a}x + ${b} = ${c}`);
    steps.push(`2. Isolate linear variable term: ${a}x = ${c} - ${b} = ${c - b}`);
    steps.push(`3. Solve for linear x variable by dividing by a: x = ${c - b} / ${a}`);
    steps.push(`4. Calculated Solution: x = ${calculatedOutput}`);
  }
  else if (toolId === "quadratic_equation_solver") {
    const a = Number(inputsState["quad_a"] ?? 1);
    const b = Number(inputsState["quad_b"] ?? -5);
    const c = Number(inputsState["quad_c"] ?? 6);
    
    if (a === 0) {
      primaryText = `Linear fallback: x = ${(-c/b).toFixed(4)}`;
      steps.push("1. Quadrative coefficient 'a' is 0, resolving linear equation bx + c = 0");
      steps.push(`2. bx = -c => x = -(${c}) / ${b}`);
      steps.push(`3. Solution: x = ${-c/b}`);
    } else {
      const disc = b * b - 4 * a * c;
      steps.push(`1. Quadratic Formula: x = [-b ± √(b² - 4ac)] / 2a`);
      steps.push(`2. Compute discriminant (d = b² - 4ac): (${b})² - 4*(${a})*(${c}) = ${disc}`);
      if (disc > 0) {
        const r1 = (-b + Math.sqrt(disc)) / (2 * a);
        const r2 = (-b - Math.sqrt(disc)) / (2 * a);
        primaryText = `Roots: x₁ = ${r1.toFixed(4)}, x₂ = ${r2.toFixed(4)}`;
        steps.push(`3. Discriminant ${disc} > 0: Two Real Distinct Roots exist`);
        steps.push(`4. Root x₁: [-(${b}) + √${disc}] / 2*(${a}) = ${r1.toFixed(4)}`);
        steps.push(`5. Root x₂: [-(${b}) - √${disc}] / 2*(${a}) = ${r2.toFixed(4)}`);
      } else if (disc === 0) {
        const r = -b / (2 * a);
        primaryText = `Single Root: x = ${r.toFixed(4)}`;
        steps.push(`3. Discriminant ${disc} = 0: Single Repeated Real Root exists`);
        steps.push(`4. Root x: -(${b}) / (2 * ${a}) = ${r.toFixed(4)}`);
      } else {
        const real = -b / (2 * a);
        const imag = Math.sqrt(-disc) / (2 * a);
        primaryText = `Complex Roots: x = ${real.toFixed(3)} ± ${imag.toFixed(3)}i`;
        steps.push(`3. Discriminant ${disc} < 0: Two Conjugate Complex Roots exist`);
        steps.push(`4. Real component: -b / 2a = -(${b}) / 2*(${a}) = ${real.toFixed(3)}`);
        steps.push(`5. Imaginary component: √(-d) / 2a = √(${Math.abs(disc)}) / 2*(${a}) = ${imag.toFixed(3)}`);
      }
    }
  }
  else if (toolId === "function_value_calculator") {
    const expr = String(inputsState["fx_expr"] ?? "x^2 + 2*x + 1");
    const x = Number(inputsState["x_val"] ?? 3);
    primaryText = `f(${x}) = ${calculatedOutput}`;
    steps.push(`1. Target mathematical function representation: f(x) = ${expr}`);
    steps.push(`2. Replace x variables with coefficient value: ${x}`);
    steps.push(`3. Calculated evaluation: f(${x}) = ${calculatedOutput}`);
  }
  else if (toolId === "function_graph_calculator") {
    const expr = String(inputsState["graph_expr"] ?? "x^3 - 3*x");
    primaryText = `Graphing: f(x) = ${expr}`;
    steps.push(`1. Graphing expression: f(x) = ${expr}`);
    steps.push(`2. Calculates equidistant values across chosen coordinates domain.`);
    steps.push(`3. Watch instructions or standard slope variables calculated below.`);
  }
  else if (toolId === "mean_median_mode_calculator") {
    const dStr = String(inputsState["dataset_str"] ?? "4, 8, 15, 16, 23, 42");
    const nums = dStr.split(/[\s,]+/).map(Number).filter(n => !isNaN(n)).sort((a,b)=>a-b);
    if (nums.length === 0) {
      primaryText = "No dataset values found";
    } else {
      const mean = nums.reduce((s,v)=>s+v,0)/nums.length;
      let median = 0;
      const mid = Math.floor(nums.length/2);
      if (nums.length % 2 === 0) {
        median = (nums[mid-1] + nums[mid])/2;
      } else {
        median = nums[mid];
      }
      const freq: Record<number, number> = {};
      let maxFreq = 0;
      let modeVal = nums[0];
      nums.forEach(n => {
        freq[n] = (freq[n] || 0) + 1;
        if (freq[n] > maxFreq) {
          maxFreq = freq[n];
          modeVal = n;
        }
      });
      primaryText = `Mean: ${mean.toFixed(2)} | Median: ${median.toFixed(2)} | Mode: ${modeVal}`;
      steps.push(`1. Extracted and sorted sequence: [${nums.join(", ")}]`);
      steps.push(`2. Calculate Mean average: sum / size = ${nums.reduce((s,v)=>s+v,0)} / ${nums.length} = ${mean.toFixed(2)}`);
      steps.push(`3. Calculate Median threshold (midpoint element): ${median.toFixed(2)}`);
      steps.push(`4. Calculate Mode frequency (highest count element): ${modeVal} (${maxFreq} times)`);
    }
  }
  else if (toolId === "standard_deviation_calculator") {
    const dStr = String(inputsState["sd_dataset"] ?? "2, 4, 4, 4, 5, 5, 7, 9");
    const nums = dStr.split(/[\s,]+/).map(Number).filter(n => !isNaN(n));
    if (nums.length === 0) {
      primaryText = "No dataset values found";
    } else {
      const n = nums.length;
      const mean = nums.reduce((s, v) => s + v, 0) / n;
      const sumSqDiff = nums.reduce((s, v) => s + Math.pow(v - mean, 2), 0);
      const variance = sumSqDiff / n;
      const popSd = Math.sqrt(variance);
      const sampleSd = n > 1 ? Math.sqrt(sumSqDiff / (n - 1)) : popSd;

      primaryText = `σ = ${popSd.toFixed(3)} | σ² = ${variance.toFixed(3)}`;
      steps.push(`1. Calculate Mean of ${n} entries: ${mean.toFixed(3)}`);
      steps.push(`2. Calculate squared standard deviations from mean`);
      steps.push(`3. Population Variance (σ²): ${variance.toFixed(3)}`);
      steps.push(`4. Population Standard Deviation (σ): √Variance = ${popSd.toFixed(3)}`);
      if (n > 1) {
        steps.push(`5. Sample Standard Deviation (s): √(sum / (n - 1)) = ${sampleSd.toFixed(3)}`);
      }
    }
  }
  else if (toolId === "permutation_combination_calculator") {
    const n = Math.floor(Number(inputsState["n_val"] ?? 10));
    const r = Math.floor(Number(inputsState["r_val"] ?? 3));
    const fact = (num: number): number => {
      let res = 1;
      for (let i = 2; i <= num; i++) res *= i;
      return res;
    };
    if (n < 0 || r < 0 || r > n) {
      primaryText = "Invalid bounds (ensure 0 ≤ r ≤ n)";
    } else {
      const nPr = fact(n) / fact(n - r);
      const nCr = fact(n) / (fact(r) * fact(n - r));
      primaryText = `Combinations C(n, r) = ${nCr} | Permutations P(n, r) = ${nPr}`;
      steps.push(`1. Read bounds: n = ${n}, r = ${r}`);
      steps.push(`2. Combination Form: n! / (r! * (n-r)!) = ${n}! / (${r}! * ${n - r}!) = ${nCr}`);
      steps.push(`3. Permutation Form: n! / (n-r)! = ${n}! / ${n - r}! = ${nPr}`);
    }
  }
  else if (toolId === "logarithm_calculator") {
    const x = Number(inputsState["log_num"] ?? 100);
    const b = Number(inputsState["log_base"] ?? 10);
    primaryText = `log_${b}(${x}) ≈ ${calculatedOutput.toFixed(5)}`;
    steps.push(`1. Locate target argument x = ${x} and exponential base b = ${b}`);
    steps.push(`2. Log base conversion formula: log_b(x) = ln(x) / ln(b)`);
    steps.push(`3. Solution: ln(${x}) / ln(${b}) = ${(Math.log(x)).toFixed(4)} / ${(Math.log(b)).toFixed(4)} = ${calculatedOutput.toFixed(5)}`);
  }
  else if (toolId === "matrix_calculator") {
    const a11 = Number(inputsState["m_a11"] ?? 2);
    const a12 = Number(inputsState["m_a12"] ?? 3);
    const a21 = Number(inputsState["m_a21"] ?? 1);
    const a22 = Number(inputsState["m_a22"] ?? 4);
    const op = String(inputsState["matrix_op"] ?? "Determinant of A");

    if (op === "Determinant of A") {
      primaryText = `Det(A) = ${calculatedOutput}`;
      steps.push("1. Matrix A representation:\n  [ " + a11 + "   " + a12 + " ]\n  [ " + a21 + "   " + a22 + " ]");
      steps.push(`2. Determinant Formula: (a11 * a22) - (a12 * a21)`);
      steps.push(`3. Substitute bounds: (${a11} * ${a22}) - (${a12} * ${a21}) = ${a11 * a22} - ${a12 * a21} = ${calculatedOutput}`);
    } else if (op === "Multiply by 2") {
      primaryText = "2 * A Matrix Evaluated";
      steps.push(`1. Scale each bounds inside Matrix by 2: [ ${a11*2}  ${a12*2} ] / [ ${a21*2}  ${a22*2} ]`);
    } else if (op === "Transpose Matrix") {
      primaryText = "Aᵀ Transposed Matrix Evaluated";
      steps.push(`1. Transpose entries across principal diagonal: [ ${a11}  ${a21} ] / [ ${a12}  ${a22} ]`);
    }
  }
  else if (toolId === "ratio_proportion_calculator") {
    const a = Number(inputsState["ratio_a"] ?? 4);
    const b = Number(inputsState["ratio_b"] ?? 8);
    const c = Number(inputsState["ratio_c"] ?? 6);
    primaryText = `x = ${calculatedOutput.toFixed(4)}`;
    steps.push(`1. Proportion shape representation: ${a} : ${b} = ${c} : x`);
    steps.push(`2. Formulate cross-multiply: a * x = b * c`);
    steps.push(`3. Substitute parameters: ${a} * x = ${b} * ${c} = ${b * c}`);
    steps.push(`4. Solve for proportion solution x variable: x = ${b * c} / ${a}`);
    steps.push(`5. Calculated Outcome: x = ${calculatedOutput}`);
  }
  else if (toolId === "date_calculator") {
    const startDateStr = String(inputsState["start_date"] ?? "2026-07-01");
    const endDateStr = String(inputsState["end_date"] ?? "2026-12-31");

    const d1 = new Date(startDateStr);
    if (isNaN(d1.getTime())) {
      primaryText = "Invalid Start Date format";
    } else {
      const d2 = new Date(endDateStr);
      if (isNaN(d2.getTime())) {
        primaryText = "Invalid End Date format";
      } else {
        const totalDays = Math.round((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
        const yearsDiff = d2.getFullYear() - d1.getFullYear();
        let monthsDiff = d2.getMonth() - d1.getMonth();
        let daysDiff = d2.getDate() - d1.getDate();
        
        let totalMonths = yearsDiff * 12 + monthsDiff;
        if (daysDiff < 0) {
          totalMonths--;
          const prevMonthDate = new Date(d2.getFullYear(), d2.getMonth(), 0);
          daysDiff += prevMonthDate.getDate();
        }
        const y = Math.floor(totalMonths / 12);
        const m = totalMonths % 12;

        let breakdownStr = `${totalDays} days`;
        if (y > 0 || m > 0 || daysDiff > 0) {
          const parts: string[] = [];
          if (y > 0) parts.push(`${y} year${y > 1 ? "s" : ""}`);
          if (m > 0) parts.push(`${m} month${m > 1 ? "s" : ""}`);
          if (daysDiff > 0) parts.push(`${daysDiff} day${daysDiff > 1 ? "s" : ""}`);
          breakdownStr += ` (${parts.join(", ")})`;
        }

        primaryText = `Duration: ${breakdownStr}`;
      }
    }
  }

  return { primaryText, steps };
}
