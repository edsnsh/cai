import { CalculatorTool } from "../types";

export const PREDEFINED_CALCULATORS: CalculatorTool[] = [
  // ==================== FINANCE & LOAN CALCULATORS (11) ====================
  {
    id: "mortgage_calculator",
    tool_type: "mortgage",
    title: "Mortgage Calculator",
    description: "Analyze total mortgage costs, down payment percentages, interest rates, and loan terms.",
    inputs: [
      { id: "home_price", label: "Home Price", type: "slider", default: 0, prefix: "$", min: 0, max: 2000000, step: 5000 },
      { id: "down_payment", label: "Down Payment (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 95, step: 1 },
      { id: "interest_rate", label: "Annual Interest Rate (APR %)", type: "slider", default: 0, suffix: "%", min: 0, max: 15.0, step: 0.05 },
      { id: "term_months", label: "Loan Term (Months)", type: "slider", default: 0, suffix: " Months", min: 0, max: 480, step: 12 }
    ],
    formula: "(home_price * (1 - down_payment / 100)) * ((interest_rate/1200) * pow(1 + (interest_rate/1200), term_months)) / (pow(1 + (interest_rate/1200), term_months) - 1)",
    output_label: "Estimated Monthly Principal & Interest Payment",
    output_prefix: "$",
    chart_type: "line",
    insight: "Maximizing your down payment decreases the mortgage principal amount, which lowers lifetime interest expense."
  },
  {
    id: "loan_calculator",
    tool_type: "loan_calculator",
    title: "Loan Calculator",
    description: "Plan personal, auto, or consumer loans with custom terms, APR rates, and optional prepayment options.",
    inputs: [
      { id: "loan_amount", label: "Loan Amount", type: "slider", default: 0, prefix: "$", min: 0, max: 500000, step: 500 },
      { id: "interest_rate", label: "Annual Interest Rate (APR %)", type: "slider", default: 0, suffix: "%", min: 0, max: 30.0, step: 0.1 },
      { id: "term_months", label: "Loan Term (Months)", type: "slider", default: 0, suffix: " Months", min: 0, max: 120, step: 1 },
      { id: "extra_payment", label: "Optional Extra Monthly Payment", type: "slider", default: 0, prefix: "$", min: 0, max: 5000, step: 10 }
    ],
    formula: "loan_amount * ((interest_rate/1200) * pow(1 + (interest_rate/1200), term_months)) / (pow(1 + (interest_rate/1200), term_months) - 1)",
    output_label: "Base Monthly Principal & Interest Payment",
    output_prefix: "$",
    chart_type: "bar",
    insight: "Allocating extra payments directly to principal reduces both loan duration and overall interest costs."
  },
  {
    id: "payment_calculator",
    tool_type: "loan_calculator",
    title: "Payment Calculator",
    description: "Calculate exact recurring loan payments for any principal, interest rate, term, and payment frequency.",
    inputs: [
      { id: "principal", label: "Principal Loan Amount", type: "slider", default: 0, prefix: "$", min: 0, max: 500000, step: 500 },
      { id: "annual_rate", label: "Annual Interest Rate (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 30.0, step: 0.1 },
      { id: "term_months", label: "Loan Duration (Months)", type: "slider", default: 0, suffix: " Months", min: 0, max: 360, step: 1 },
      { id: "frequency", label: "Payment Frequency", type: "select", default: "Monthly", options: ["Monthly", "Bi-weekly", "Weekly"] }
    ],
    formula: "0",
    output_label: "Calculated Payment Per Period",
    output_prefix: "$",
    chart_type: "bar",
    insight: "Bi-weekly or weekly payment schedules accelerate principal reduction by applying payments more frequently throughout the year."
  },
  {
    id: "house_loan_calculator",
    tool_type: "mortgage",
    title: "House Loan Calculator",
    description: "Calculate total housing expenses including principal, interest, property taxes, home insurance, and HOA fees.",
    inputs: [
      { id: "house_price", label: "House Price", type: "slider", default: 0, prefix: "$", min: 0, max: 3000000, step: 10000 },
      { id: "down_payment_pct", label: "Down Payment (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 80, step: 1 },
      { id: "interest_rate", label: "Interest Rate (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 15.0, step: 0.1 },
      { id: "term_months", label: "Loan Term (Months)", type: "slider", default: 0, suffix: " Months", min: 0, max: 480, step: 12 },
      { id: "annual_tax", label: "Annual Property Tax ($)", type: "slider", default: 0, prefix: "$", min: 0, max: 30000, step: 100 },
      { id: "annual_insurance", label: "Annual Homeowners Insurance ($)", type: "slider", default: 0, prefix: "$", min: 0, max: 10000, step: 50 },
      { id: "monthly_hoa", label: "Monthly HOA / Maintenance ($)", type: "slider", default: 0, prefix: "$", min: 0, max: 2000, step: 25 }
    ],
    formula: "0",
    output_label: "Total Monthly House Payment (PITI + HOA)",
    output_prefix: "$",
    chart_type: "distribution",
    insight: "Total housing payments include Principal, Interest, Taxes, and Insurance (PITI). Lenders generally prefer PITI to be under 28% of gross monthly income."
  },
  {
    id: "car_loan_calculator",
    tool_type: "loan_calculator",
    title: "Car Loan Calculator",
    description: "Estimate monthly auto loan payments factoring in vehicle price, trade-in allowance, sales tax, and down payment.",
    inputs: [
      { id: "vehicle_price", label: "Vehicle Sticker Price", type: "slider", default: 0, prefix: "$", min: 0, max: 150000, step: 500 },
      { id: "down_payment", label: "Cash Down Payment", type: "slider", default: 0, prefix: "$", min: 0, max: 50000, step: 250 },
      { id: "trade_in_value", label: "Trade-in Value Allowance", type: "slider", default: 0, prefix: "$", min: 0, max: 50000, step: 250 },
      { id: "sales_tax_pct", label: "Sales Tax Rate (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 15, step: 0.25 },
      { id: "interest_rate", label: "Auto Loan APR (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 25, step: 0.1 },
      { id: "term_months", label: "Loan Term (Months)", type: "select", default: "60", options: ["24", "36", "48", "60", "72", "84"] }
    ],
    formula: "0",
    output_label: "Estimated Monthly Car Payment",
    output_prefix: "$",
    chart_type: "bar",
    insight: "Shorter auto loan terms (e.g., 48 or 60 months) save significant interest compared to extended 72 or 84-month terms."
  },
  {
    id: "tax_calculator",
    tool_type: "salary",
    title: "Tax Calculator",
    description: "Estimate effective federal and state income tax liability, deductions, and net take-home salary.",
    inputs: [
      { id: "gross_income", label: "Annual Gross Income", type: "slider", default: 0, prefix: "$", min: 0, max: 500000, step: 1000 },
      { id: "filing_status", label: "Filing Status", type: "select", default: "Single", options: ["Single", "Married Filing Jointly", "Head of Household"] },
      { id: "state_tax_rate", label: "State Income Tax Rate (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 13, step: 0.25 },
      { id: "pretax_deductions", label: "Annual Pre-Tax Deductions (401k/HSA)", type: "slider", default: 0, prefix: "$", min: 0, max: 30000, step: 500 }
    ],
    formula: "0",
    output_label: "Estimated Annual Net Take-Home Pay",
    output_prefix: "$",
    chart_type: "distribution",
    insight: "Pre-tax contributions to retirement plans like 401(k) or HSA lower your adjusted gross income, reducing immediate federal and state tax burdens."
  },
  {
    id: "interest_calculator",
    tool_type: "compound_interest",
    title: "Interest Calculator",
    description: "Calculate simple and compound interest accumulation on savings or investment accounts over time.",
    inputs: [
      { id: "initial_investment", label: "Initial Capital", type: "slider", default: 0, prefix: "$", min: 0, max: 500000, step: 500 },
      { id: "monthly_contribution", label: "Monthly Deposit Addition", type: "slider", default: 0, prefix: "$", min: 0, max: 10000, step: 25 },
      { id: "annual_rate", label: "Annual Interest Rate (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 30, step: 0.1 },
      { id: "term_months", label: "Investment Horizon (Months)", type: "slider", default: 0, suffix: " Months", min: 0, max: 480, step: 12 },
      { id: "compound_frequency", label: "Compound Frequency", type: "select", default: "Monthly", options: ["Monthly", "Quarterly", "Annually", "Daily"] }
    ],
    formula: "0",
    output_label: "Projected Ending Balance",
    output_prefix: "$",
    chart_type: "line",
    insight: "Compounding frequency determines how often earned interest generates its own interest. More frequent compounding yields slightly higher annual returns."
  },
  {
    id: "inflation_calculator",
    tool_type: "custom",
    title: "Inflation Calculator",
    description: "See the erosion of your cash reserves and buying power under a steady inflation rate over time.",
    inputs: [
      { id: "current_amount", label: "Current Cash Amount", type: "slider", default: 0, prefix: "$", min: 0, max: 10000000, step: 1000 },
      { id: "inflation_rate", label: "Average Annual Inflation (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 30.0, step: 0.1 },
      { id: "term_months", label: "Timeline (Months)", type: "slider", default: 0, suffix: " Months", min: 0, max: 480, step: 12 }
    ],
    formula: "current_amount / pow(1 + (inflation_rate/100), term_months / 12)",
    output_label: "Adjusted Future Buying Power",
    output_prefix: "$",
    chart_type: "bar",
    insight: "Uninvested cash depreciates steadily due to inflation. To maintain purchasing power, asset growth must meet or exceed the annual inflation rate."
  },
  {
    id: "investment_calculator",
    tool_type: "investment",
    title: "Invest Calculator",
    description: "Project long-term wealth growth from initial capital and recurring monthly portfolio contributions.",
    inputs: [
      { id: "principal", label: "Initial Portfolio Balance", type: "slider", default: 0, prefix: "$", min: 0, max: 1000000, step: 500 },
      { id: "monthly_contribution", label: "Monthly Investment Contribution", type: "slider", default: 0, prefix: "$", min: 0, max: 20000, step: 50 },
      { id: "annual_return", label: "Expected Annual Return (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 30, step: 0.25 },
      { id: "term_months", label: "Investment Horizon (Months)", type: "slider", default: 0, suffix: " Months", min: 0, max: 480, step: 12 }
    ],
    formula: "0",
    output_label: "Projected Future Portfolio Value",
    output_prefix: "$",
    chart_type: "line",
    insight: "Consistent monthly contributions over a multi-year horizon take advantage of dollar-cost averaging and compounding interest."
  },
  {
    id: "retirement_calculator",
    tool_type: "investment",
    title: "Retirement Calculator",
    description: "Determine whether your current savings rate will meet your target retirement nest egg and lifestyle goals.",
    inputs: [
      { id: "current_age", label: "Current Age", type: "slider", default: 0, suffix: " Years", min: 0, max: 70, step: 1 },
      { id: "retirement_age", label: "Target Retirement Age", type: "slider", default: 0, suffix: " Years", min: 0, max: 80, step: 1 },
      { id: "current_savings", label: "Existing Retirement Savings", type: "slider", default: 0, prefix: "$", min: 0, max: 2000000, step: 5000 },
      { id: "monthly_savings", label: "Monthly Retirement Addition", type: "slider", default: 0, prefix: "$", min: 0, max: 10000, step: 50 },
      { id: "investment_return", label: "Expected Investment Return (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 15, step: 0.25 },
      { id: "desired_monthly_income", label: "Desired Monthly Income in Retirement", type: "slider", default: 0, prefix: "$", min: 0, max: 30000, step: 250 }
    ],
    formula: "0",
    output_label: "Projected Nest Egg Balance at Retirement",
    output_prefix: "$",
    chart_type: "line",
    insight: "A standard safe withdrawal rate of 4% per year allows your nest egg to generate sustainable retirement income while preserving capital."
  },
  {
    id: "fifty_thirty_twenty_calculator",
    tool_type: "budget",
    title: "50/30/20 Calculator",
    description: "Break down your net monthly take-home income using the 50/30/20 rule: 50% Needs, 30% Wants, 20% Savings.",
    inputs: [
      { id: "income", label: "Monthly Take-Home Income", type: "slider", default: 0, prefix: "$", min: 0, max: 100000, step: 250 }
    ],
    formula: "income * 0.20",
    output_label: "Target Monthly Savings & Debt Paydown (20%)",
    output_prefix: "$",
    chart_type: "distribution",
    insight: "The 50/30/20 budgeting method allocates 50% of income to essential needs, 30% to discretionary wants, and at least 20% to savings and debt reduction."
  },

  // ==================== HEALTH & FITNESS CALCULATORS (8) ====================
  {
    id: "bmi_calculator",
    tool_type: "health",
    title: "BMI Calculator",
    description: "Calculate your Body Mass Index (BMI) to determine standard body weight status categories.",
    inputs: [
      { id: "weight", label: "Weight", type: "slider", default: 0, suffix: " kg", min: 0, max: 200, step: 1 },
      { id: "height", label: "Height", type: "slider", default: 0, suffix: " cm", min: 0, max: 250, step: 1 }
    ],
    formula: "weight / pow(height/100, 2)",
    output_label: "Calculated Body Mass Index (BMI)",
    chart_type: "bar",
    insight: "Standard BMI categories: Underweight (< 18.5), Normal weight (18.5 - 24.9), Overweight (25 - 29.9), Obesity (30+)."
  },
  {
    id: "body_fat_calculator",
    tool_type: "health",
    title: "Body Fat Calculator",
    description: "Estimate your body fat percentage using standard US Navy anthropometric circumference measurements.",
    inputs: [
      { id: "gender", label: "Biological Gender", type: "select", default: "Male", options: ["Male", "Female"] },
      { id: "waist", label: "Waist Circumference", type: "slider", default: 0, suffix: " cm", min: 0, max: 180, step: 1 },
      { id: "neck", label: "Neck Circumference", type: "slider", default: 0, suffix: " cm", min: 0, max: 80, step: 1 },
      { id: "height", label: "Height", type: "slider", default: 0, suffix: " cm", min: 0, max: 250, step: 1 },
      { id: "hip", label: "Hip Circumference (Female)", type: "slider", default: 0, suffix: " cm", min: 0, max: 180, step: 1 }
    ],
    formula: "0",
    output_label: "Estimated Body Fat Percentage",
    output_suffix: "%",
    chart_type: "distribution",
    insight: "Body fat percentage provides a clearer picture of health and fitness than body weight alone by separating lean mass from fat mass."
  },
  {
    id: "bmr_calculator",
    tool_type: "health",
    title: "BMR Calculator",
    description: "Calculate your Basal Metabolic Rate (BMR) representing energy expenditure at complete rest.",
    inputs: [
      { id: "gender", label: "Biological Gender", type: "select", default: "Male", options: ["Male", "Female"] },
      { id: "height", label: "Height", type: "slider", default: 0, suffix: " cm", min: 0, max: 250, step: 1 },
      { id: "weight", label: "Weight", type: "slider", default: 0, suffix: " kg", min: 0, max: 200, step: 1 },
      { id: "age", label: "Age", type: "slider", default: 0, suffix: " years", min: 0, max: 100, step: 1 }
    ],
    formula: "0",
    output_label: "Basal Metabolic Rate",
    output_suffix: " kcal/day",
    chart_type: "bar",
    insight: "BMR accounts for about 60-75% of daily calories burned, powering essential organs like your heart, brain, and lungs at rest."
  },
  {
    id: "carbohydrate_calculator",
    tool_type: "health",
    title: "Carbohydrate Calculator",
    description: "Determine optimal daily carbohydrate targets based on activity level, body weight, and nutrition strategy.",
    inputs: [
      { id: "daily_calories", label: "Daily Calorie Intake Target", type: "slider", default: 0, suffix: " kcal", min: 0, max: 5000, step: 50 },
      { id: "diet_goal", label: "Dietary Strategy", type: "select", default: "Balanced (50% Carbs)", options: ["Low-Carb (25% Carbs)", "Balanced (50% Carbs)", "High-Carb / Athlete (60% Carbs)", "Keto (5% Carbs)"] },
      { id: "body_weight", label: "Body Weight", type: "slider", default: 0, suffix: " kg", min: 0, max: 200, step: 1 }
    ],
    formula: "0",
    output_label: "Target Daily Carbohydrate Intake",
    output_suffix: " grams/day",
    chart_type: "bar",
    insight: "Carbohydrates provide 4 calories per gram and serve as the primary source of fuel for high-intensity physical activity."
  },
  {
    id: "protein_calculator",
    tool_type: "health",
    title: "Protein Calculator",
    description: "Calculate recommended daily protein intake based on body weight, activity level, and fitness goals.",
    inputs: [
      { id: "weight", label: "Body Weight", type: "slider", default: 0, suffix: " kg", min: 0, max: 200, step: 1 },
      { id: "activity_level", label: "Activity Level", type: "select", default: "Moderate Exercise (3-4x/wk)", options: ["Sedentary (Little/No exercise)", "Light Exercise (1-2x/wk)", "Moderate Exercise (3-4x/wk)", "Intense Weight Training (5-7x/wk)"] },
      { id: "goal", label: "Fitness Goal", type: "select", default: "Muscle Building", options: ["Maintenance", "Fat Loss / Cutting", "Muscle Building"] }
    ],
    formula: "0",
    output_label: "Recommended Daily Protein Intake",
    output_suffix: " grams/day",
    chart_type: "bar",
    insight: "Active individuals building muscle benefit from 1.6 to 2.2 grams of protein per kilogram of body weight daily."
  },
  {
    id: "calorie_calculator",
    tool_type: "health",
    title: "Calorie Calculator",
    description: "Estimate Total Daily Energy Expenditure (TDEE) and caloric targets for weight loss, maintenance, or muscle gain.",
    inputs: [
      { id: "gender", label: "Biological Gender", type: "select", default: "Male", options: ["Male", "Female"] },
      { id: "age", label: "Age", type: "slider", default: 0, suffix: " years", min: 0, max: 90, step: 1 },
      { id: "height", label: "Height", type: "slider", default: 0, suffix: " cm", min: 0, max: 250, step: 1 },
      { id: "weight", label: "Weight", type: "slider", default: 0, suffix: " kg", min: 0, max: 200, step: 1 },
      { id: "activity", label: "Daily Physical Activity", type: "select", default: "Moderate (3-5 days/wk)", options: ["Sedentary (Office job)", "Light (1-3 days/wk)", "Moderate (3-5 days/wk)", "Very Active (6-7 days/wk)"] },
      { id: "goal", label: "Weight Goal", type: "select", default: "Maintain Weight", options: ["Mild Weight Loss (-0.25 kg/wk)", "Weight Loss (-0.5 kg/wk)", "Maintain Weight", "Mild Weight Gain (+0.25 kg/wk)"] }
    ],
    formula: "0",
    output_label: "Target Daily Caloric Intake",
    output_suffix: " kcal/day",
    chart_type: "bar",
    insight: "Creating a moderate calorie deficit of 300-500 kcal per day promotes safe, sustainable fat loss of about 0.5 kg per week."
  },
  {
    id: "height_calculator",
    tool_type: "health",
    title: "Height Calculator",
    description: "Predict child adult height based on mid-parental formulas or convert height between metric and imperial units.",
    inputs: [
      { id: "father_height", label: "Father's Height", type: "slider", default: 0, suffix: " cm", min: 0, max: 220, step: 1 },
      { id: "mother_height", label: "Mother's Height", type: "slider", default: 0, suffix: " cm", min: 0, max: 220, step: 1 },
      { id: "child_gender", label: "Child Gender", type: "select", default: "Boy", options: ["Boy", "Girl"] }
    ],
    formula: "0",
    output_label: "Predicted Adult Height",
    output_suffix: " cm",
    chart_type: "bar",
    insight: "The mid-parental height formula estimates target adult height within a typical range of +/- 5 cm based on genetic potential."
  },
  {
    id: "weight_calculator",
    tool_type: "health",
    title: "Weight Calculator",
    description: "Calculate Ideal Body Weight (IBW) standards and projected timeline to reach target weight goals.",
    inputs: [
      { id: "gender", label: "Biological Gender", type: "select", default: "Male", options: ["Male", "Female"] },
      { id: "height", label: "Height", type: "slider", default: 0, suffix: " cm", min: 0, max: 230, step: 1 },
      { id: "current_weight", label: "Current Weight", type: "slider", default: 0, suffix: " kg", min: 0, max: 220, step: 1 },
      { id: "target_weight", label: "Target Weight Goal", type: "slider", default: 0, suffix: " kg", min: 0, max: 220, step: 1 },
      { id: "weekly_rate", label: "Weekly Progress Rate", type: "slider", default: 0, suffix: " kg / Week", min: 0, max: 1.5, step: 0.25 }
    ],
    formula: "0",
    output_label: "Ideal Body Weight Standard (Devine)",
    output_suffix: " kg",
    chart_type: "bar",
    insight: "Medical ideal body weight formulas provide helpful reference baselines. Individual body composition muscle mass varies widely."
  },

  // ==================== TIME, DATE & ASTROLOGY CALCULATORS (5) ====================
  {
    id: "time_calculator",
    tool_type: "date_difference",
    title: "Time Calculator",
    description: "Add, subtract, or total multiple time durations in hours, minutes, and seconds.",
    inputs: [
      { id: "hours_1", label: "Time 1 - Hours", type: "slider", default: 0, suffix: " Hours", min: 0, max: 100, step: 1 },
      { id: "mins_1", label: "Time 1 - Minutes", type: "slider", default: 0, suffix: " Minutes", min: 0, max: 59, step: 1 },
      { id: "secs_1", label: "Time 1 - Seconds", type: "slider", default: 0, suffix: " Seconds", min: 0, max: 59, step: 1 },
      { id: "operation", label: "Operation", type: "select", default: "Add (+)", options: ["Add (+)", "Subtract (-)"] },
      { id: "hours_2", label: "Time 2 - Hours", type: "slider", default: 0, suffix: " Hours", min: 0, max: 100, step: 1 },
      { id: "mins_2", label: "Time 2 - Minutes", type: "slider", default: 0, suffix: " Minutes", min: 0, max: 59, step: 1 },
      { id: "secs_2", label: "Time 2 - Seconds", type: "slider", default: 0, suffix: " Seconds", min: 0, max: 59, step: 1 }
    ],
    formula: "0",
    output_label: "Total Duration Outcome",
    chart_type: "none",
    insight: "Time duration math automatically handles sexagesimal conversions (60 seconds per minute, 60 minutes per hour)."
  },
  {
    id: "date_calculator",
    tool_type: "custom",
    title: "Date Calculator",
    description: "Calculate the exact duration in days, weeks, months, or years between two calendar dates.",
    inputs: [
      { id: "start_date", label: "Start Date", type: "date", default: "2026-01-01" },
      { id: "end_date", label: "End Date", type: "date", default: "2026-12-31" }
    ],
    formula: "0",
    output_label: "Exact Calendar Days Difference",
    chart_type: "none",
    insight: "Date computations utilize Gregorian calendar rules, precisely accounting for leap years and month length variations."
  },
  {
    id: "timecard_calculator",
    tool_type: "custom",
    title: "Timecard Calculator",
    description: "Calculate gross weekly pay, regular hours, overtime pay, and break deductions for payroll logging.",
    inputs: [
      { id: "hourly_rate", label: "Hourly Pay Rate", type: "slider", default: 0, prefix: "$", min: 0, max: 200, step: 0.5 },
      { id: "regular_hours", label: "Regular Weekly Hours Worked", type: "slider", default: 0, suffix: " Hours", min: 0, max: 60, step: 0.5 },
      { id: "overtime_hours", label: "Overtime Hours Worked", type: "slider", default: 0, suffix: " Hours", min: 0, max: 40, step: 0.5 },
      { id: "overtime_multiplier", label: "Overtime Rate Multiple", type: "select", default: "1.5x (Time & Half)", options: ["1.5x (Time & Half)", "2.0x (Double Time)"] },
      { id: "unpaid_break_mins", label: "Total Daily Unpaid Break", type: "slider", default: 0, suffix: " Minutes / Day", min: 0, max: 120, step: 15 }
    ],
    formula: "0",
    output_label: "Estimated Total Weekly Gross Earnings",
    output_prefix: "$",
    chart_type: "bar",
    insight: "Federal FLSA labor laws generally require overtime pay at 1.5 times regular pay rates for hours worked over 40 per workweek."
  },
  {
    id: "age_calculator",
    tool_type: "health",
    title: "Age Calculator",
    description: "Calculate your exact age in years, months, days, weeks, and total hours, along with next birthday countdown.",
    inputs: [
      { id: "birth_year", label: "Birth Year", type: "slider", default: 0, min: 0, max: 2026, step: 1 },
      { id: "birth_month", label: "Birth Month", type: "slider", default: 0, min: 0, max: 12, step: 1 },
      { id: "birth_day", label: "Birth Day", type: "slider", default: 0, min: 0, max: 31, step: 1 }
    ],
    formula: "2026 - birth_year",
    output_label: "Exact Current Age",
    output_suffix: " years old",
    chart_type: "bar",
    insight: "Reports precise biological age milestones, total Earth rotations lived, and exact days remaining until your next birthday."
  },

  // ==================== MATH & UTILITIES CALCULATORS ====================
  {
    id: "basic_calculator",
    tool_type: "math",
    title: "Basic Calculator",
    description: "Interactive desktop calculator for addition, subtraction, multiplication, division, and percentage operations.",
    inputs: [],
    formula: "0",
    output_label: "Calculated Result",
    chart_type: "none",
    insight: "Supports real-time arithmetic operations with immediate expression evaluation and tape log history."
  },
  {
    id: "scientific_calculator",
    tool_type: "math",
    title: "Scientific Calculator",
    description: "Full-featured scientific calculator supporting trigonometric functions, logarithms, exponents, roots, and mathematical constants.",
    inputs: [],
    formula: "0",
    output_label: "Scientific Function Output",
    chart_type: "none",
    insight: "Trigonometric functions accept angles in degrees/radians. Logarithmic functions compute base-10 and natural log values."
  },
  {
    id: "grade_calculator",
    tool_type: "custom",
    title: "Grade Calculator",
    description: "Calculate your current course average or determine the exact grade needed on your final exam to reach your target grade.",
    inputs: [
      { id: "current_grade", label: "Current Class Grade (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 100, step: 0.5 },
      { id: "target_grade", label: "Desired Overall Target Grade (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 100, step: 0.5 },
      { id: "final_weight", label: "Final Exam Weight (%)", type: "slider", default: 0, suffix: "%", min: 0, max: 60, step: 1 }
    ],
    formula: "0",
    output_label: "Minimum Score Needed on Final Exam",
    output_suffix: "%",
    chart_type: "bar",
    insight: "Formula: Required Score = (Target Grade - Current Grade * (1 - Final Weight)) / Final Weight."
  },
  {
    id: "speed_calculator",
    tool_type: "custom",
    title: "Speed Calculator",
    description: "Calculate speed, distance, or time, along with running pace estimates in km/h and mph.",
    inputs: [
      { id: "distance", label: "Distance", type: "slider", default: 0, suffix: " km", min: 0, max: 1000, step: 0.5 },
      { id: "time_hours", label: "Time - Hours", type: "slider", default: 0, suffix: " Hours", min: 0, max: 24, step: 1 },
      { id: "time_minutes", label: "Time - Minutes", type: "slider", default: 0, suffix: " Minutes", min: 0, max: 59, step: 1 },
      { id: "time_seconds", label: "Time - Seconds", type: "slider", default: 0, suffix: " Seconds", min: 0, max: 59, step: 1 }
    ],
    formula: "0",
    output_label: "Calculated Average Speed",
    output_suffix: " km/h",
    chart_type: "bar",
    insight: "Speed = Distance / Time. Also computes running pace per kilometer and per mile for athletic training."
  }
];

export function findMatchingPredefinedCalculator(query: string): CalculatorTool | null {
  const q = query.toLowerCase().trim();
  if (!q) return null;

  // Search by exact title or id match
  const exact = PREDEFINED_CALCULATORS.find(c => 
    c.id.toLowerCase() === q || 
    c.title.toLowerCase() === q ||
    c.id.replace(/_/g, " ") === q
  );
  if (exact) return exact;

  // Search by keyword matches
  if (q.includes("password") || q.includes("random")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "random_password_generator") || null;
  }
  if (q.includes("speed") || q.includes("pace") || q.includes("distance")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "speed_calculator") || null;
  }
  if (q.includes("grade") || q.includes("exam") || q.includes("gpa")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "grade_calculator") || null;
  }
  if (q.includes("birth chart") || q.includes("astrology") || q.includes("zodiac") || q.includes("rising sign")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "birth_chart_calculator") || null;
  }
  if (q.includes("timecard") || q.includes("paycheck") || q.includes("shift") || q.includes("work hours")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "timecard_calculator") || null;
  }
  if (q.includes("car loan") || q.includes("auto loan") || q.includes("vehicle price")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "car_loan_calculator") || null;
  }
  if (q.includes("house loan") || q.includes("home loan") || q.includes("piti")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "house_loan_calculator") || null;
  }
  if (q.includes("mortgage") || q.includes("home price")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "mortgage_calculator") || null;
  }
  if (q.includes("retirement") || q.includes("nest egg") || q.includes("401k")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "retirement_calculator") || null;
  }
  if (q.includes("invest") || q.includes("portfolio")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "investment_calculator") || null;
  }
  if (q.includes("payment")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "payment_calculator") || null;
  }
  if (q.includes("loan") || q.includes("borrow")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "loan_calculator") || null;
  }
  if (q.includes("tax") || q.includes("income tax") || q.includes("salary tax")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "tax_calculator") || null;
  }
  if (q.includes("interest") || q.includes("compound interest")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "interest_calculator") || null;
  }
  if (q.includes("inflation") || q.includes("buying power")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "inflation_calculator") || null;
  }
  if (q.includes("50/30/20") || q.includes("50 30 20") || q.includes("fifty")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "fifty_thirty_twenty_calculator") || null;
  }
  if (q.includes("time") && !q.includes("timecard")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "time_calculator") || null;
  }
  if (q.includes("date")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "date_calculator") || null;
  }
  if (q.includes("bmi") || q.includes("body mass")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "bmi_calculator") || null;
  }
  if (q.includes("body fat") || q.includes("fat percentage")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "body_fat_calculator") || null;
  }
  if (q.includes("bmr") || q.includes("basal metabolic")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "bmr_calculator") || null;
  }
  if (q.includes("carb") || q.includes("carbohydrate")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "carbohydrate_calculator") || null;
  }
  if (q.includes("protein")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "protein_calculator") || null;
  }
  if (q.includes("calorie") || q.includes("tdee")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "calorie_calculator") || null;
  }
  if (q.includes("height")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "height_calculator") || null;
  }
  if (q.includes("weight") && !q.includes("body fat")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "weight_calculator") || null;
  }
  if (q.includes("scientific")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "scientific_calculator") || null;
  }
  if (q.includes("basic") || q.includes("math") || q.includes("calculator")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "basic_calculator") || null;
  }
  if (q.includes("age")) {
    return PREDEFINED_CALCULATORS.find(c => c.id === "age_calculator") || null;
  }

  return PREDEFINED_CALCULATORS[0];
}
