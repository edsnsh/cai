export const DICT_EN = {
  // Hero
  title: "Stay Notified & Connected",
  description: "Enter your email address in the alert bar below to subscribe for instant updates and notifications.",
  placeholder: "Enter your email address (e.g. name@example.com)...",
  suggestionsTitle: "PRE-BUILT UTILITY & FINANCIAL CALCULATORS",
  // Common Buttons & Texts
  calculatedTitle: "Live Real-Time Outputs",
  calculatigTitle: "Analytical Calculations",
  share: "Share",
  copied: "Copied!",
  sliderHint: "Sliders are set to smart ranges. You can direct-type larger values into input boxes if needed.",
  solutionTitle: "Calculate Solution (=)",
  insightsTitle: "Analytical Insight Projection",
  emptyChart: "Dynamic visualization not available for this custom format.",
  stepByStepTitle: "Step-by-Step Solving Logic",
  footerTitle: "Bloomberg-Grade High Fidelity Multi-Tool System",
  clearSession: "Clear session & reset inputs",
  notMatchedAlert: "No exact formula matched. Feel free to refine below:",
  generatePDF: "Download PDF report containing formulas and step-by-step logs.",
  tapelogTitle: "Interactive Tapelog",
  calcActivePrefix: "custom",
  errorVal: "Error",
  providedInputs: "Provided Inputs",
  solvingFormula: "Solving Formula",
  mathStructure: "Mathematical Formula & Structure",
  operationDetails: "Operation Details",
};

export const DICT_TR = {
  // Hero
  title: "Haberdar Olun ve E-Posta Ekleyin",
  description: "Anında güncellemeler ve bildirimler almak için e-posta adresinizi aşağıdaki çubuğa girin.",
  placeholder: "E-posta adresinizi girin (örn. adiniz@ornek.com)...",
  suggestionsTitle: "HAZIR YARDIMCI VE FİNANSAL HESAPLAYICILAR",
  // Common Buttons & Texts
  calculatedTitle: "Canlı Hesaplama Sonuçları",
  calculatigTitle: "Analitik Hesaplamalar",
  share: "Paylaş",
  copied: "Kopyalandı!",
  sliderHint: "Sürgüler akıllı aralıklardadır. Dilerseniz kutulara doğrudan elle büyük değerler yazabilirsiniz.",
  solutionTitle: "Çözümü Hesapla (=)",
  insightsTitle: "Analitik Öngörü ve Analiz",
  emptyChart: "Bu özel biçim için dinamik grafik görselleştirme mevcut değil.",
  stepByStepTitle: "Adım Adım Çözüm Mantığı",
  footerTitle: "Profesyonel Bloomberg Seviyesinde Yüksek Kaliteli Çoklu Çözücü",
  clearSession: "Oturumu temizle ve sıfırla",
  notMatchedAlert: "Tam formül eşleşmesi bulunamadı. Lütfen detayları güncelleyin:",
  generatePDF: "Formülleri ve adım adım işlem loglarını içeren PDF raporunu indir.",
  tapelogTitle: "İnteraktif İşlem Geçmişi",
  calcActivePrefix: "özel",
  errorVal: "Hata",
  providedInputs: "Girdi Değerleri",
  solvingFormula: "Çözüm Formülü",
  mathStructure: "Matematiksel Formül ve Yapı",
  operationDetails: "İşlem Detayı",
};

export const DICT_ES = {
  // Hero
  title: "Manténgase Informado y Conectado",
  description: "Ingrese su dirección de correo electrónico en la barra para recibir actualizaciones y alertas instantáneas.",
  placeholder: "Ingrese su correo electrónico (ej. nombre@ejemplo.com)...",
  suggestionsTitle: "CALCULADORAS FINANCIERAS Y DE UTILIDADES PREPARADAS",
  // Common Buttons & Texts
  calculatedTitle: "Resultados en Vivo en Tiempo Real",
  calculatigTitle: "Cálculos Analíticos",
  share: "Compartir",
  copied: "¡Copiado!",
  sliderHint: "Los deslizadores están en rangos inteligentes. Puede escribir valores más grandes si lo desea.",
  solutionTitle: "Calcular Solución (=)",
  insightsTitle: "Proyección Analítica de Perspectivas",
  emptyChart: "La visualización dinámica no está disponible para este formato personalizado.",
  stepByStepTitle: "Lógica de Resolución Paso a Paso",
  footerTitle: "Bloomberg-Grade Sistema de Multitool de Alta Fidelidad",
  clearSession: "Limpiar sesión y restablecer entradas",
  notMatchedAlert: "Ninguna fórmula exacta coincide. Siéntase libre de refinar a continuación:",
  generatePDF: "Descargar informe PDF con fórmulas e historial paso a paso.",
  tapelogTitle: "Historial Interactivo de Operaciones",
  calcActivePrefix: "personalizado",
  errorVal: "Error",
  providedInputs: "Entradas Proporcionadas",
  solvingFormula: "Fórmula de Resolución",
  mathStructure: "Fórmula Matemática y Estructura",
  operationDetails: "Detalles de la Operación",
};

export const DICT_DE = {
  // Hero
  title: "Benachrichtigt & Verbunden Bleiben",
  description: "Geben Sie Ihre E-Mail-Adresse in die Leiste ein, um Updates und Benachrichtigungen zu erhalten.",
  placeholder: "Geben Sie Ihre E-Mail-Adresse ein (z. B. name@beispiel.de)...",
  suggestionsTitle: "VORGEFERTIGTE DIENSTLEISTUNGS- & FINANZRECHNER",
  // Common Buttons & Texts
  calculatedTitle: "Live-Ergebnisse in Echtzeit",
  calculatigTitle: "Analytische Berechnungen",
  share: "Teilen",
  copied: "Kopiert!",
  sliderHint: "Schieberegler sind auf intelligente Bereiche eingestellt. Sie können größere Werte manuell eingeben.",
  solutionTitle: "Lösung berechnen (=)",
  insightsTitle: "Analytische Einblicksprojektion",
  emptyChart: "Dynamische Visualisierung für dieses Format nicht verfügbar.",
  stepByStepTitle: "Schritt-für-Schritt-Lösungslogik",
  footerTitle: "Bloomberg-Klasse High-Fidelity Mehrzweck-Rechensystem",
  clearSession: "Sitzung löschen & Eingaben zurücksetzen",
  notMatchedAlert: "Keine exakte Formel gefunden. Bitte passen Sie die Angaben unten an:",
  generatePDF: "Laden Sie den PDF-Bericht mit Formeln und Protokollen herunter.",
  tapelogTitle: "Interaktives Berechnungsjournal",
  calcActivePrefix: "benutzerdefiniert",
  errorVal: "Fehler",
  providedInputs: "Bereitgestellte Eingaben",
  solvingFormula: "Lösungsformel",
  mathStructure: "Mathematische Formel & Struktur",
  operationDetails: "Vorgangsdetails",
};

export const DICT_FR = {
  // Hero
  title: "Demandez n'importe quoi. Calculez instantanément.",
  description: "Saisissez n'importe quelle requête ci-dessus pour générer votre concentrateur de calcul, ou explorez les outils ci-dessous.",
  placeholder: "Tapez votre question ici (ex: remboursement d'hypothèque)...",
  suggestionsTitle: "CALCULATRICES FINANCIÈRES ET PRATIQUES CONSTRUITES",
  // Common Buttons & Texts
  calculatedTitle: "Résultats en Direct et en Temps Réel",
  calculatigTitle: "Calculs Analytiques",
  share: "Partager",
  copied: "Copié !",
  sliderHint: "Les curseurs sont définis sur des plages intelligentes. Vous pouvez saisir directement de grandes valeurs.",
  solutionTitle: "Calculer la Solution (=)",
  insightsTitle: "Projection d'Analyses Analytiques",
  emptyChart: "Visualisation dynamique non disponible pour ce format personnalisé.",
  stepByStepTitle: "Logique de Résolution Étape par Étape",
  footerTitle: "Système multi-outils haute fidélité de niveau Bloomberg",
  clearSession: "Effacer la session et réinitialiser les entrées",
  notMatchedAlert: "Aucune formule exacte ne correspond. Affinez les détails ci-dessous :",
  generatePDF: "Télécharger le rapport PDF contenant les formules et l'historique.",
  tapelogTitle: "Journal de Calcul Interactif",
  calcActivePrefix: "personnalisé",
  errorVal: "Echec",
  providedInputs: "Entrées Fournies",
  solvingFormula: "Formule de Résolution",
  mathStructure: "Formule Mathématique & Structure",
  operationDetails: "Détails de l'Opération",
};

export const DICT_IT = {
  // Hero
  title: "Chiedi qualsiasi cosa. Calcola all'istante.",
  description: "Digita una query personalizzata sopra per generare il tuo hub di calcolo, o esplora gli strumenti di seguito.",
  placeholder: "Digita la tua domanda qui (es. ammortamento mutuo)...",
  suggestionsTitle: "CALCOLATRICI FINANZIARIE E DI UTILITÀ PRECOSTRUITE",
  // Common Buttons & Texts
  calculatedTitle: "Risultati in Tempo Reale",
  calculatigTitle: "Calcoli Analitici",
  share: "Condividi",
  copied: "Copiato!",
  sliderHint: "I cursori hanno intervalli intelligenti. Puoi digitare direttamente valori più grandi.",
  solutionTitle: "Calcola Soluzione (=)",
  insightsTitle: "Proiezione di Analisi Analitica",
  emptyChart: "Visualizzazione dinamica non disponibile per questo formato.",
  stepByStepTitle: "Logica di Risoluzione Passo-Passo",
  footerTitle: "Sistema Multi-Strumento ad Alta Fedeltà di Grado Bloomberg",
  clearSession: "Cancella sessione e azzera gli input",
  notMatchedAlert: "Nessuna formula corrisponde. Affina i valori di seguito:",
  generatePDF: "Scarica il report PDF contenente formule e registri passo-passo.",
  tapelogTitle: "Registro Interattivo dei Calcoli",
  calcActivePrefix: "personalizzato",
  errorVal: "Errore",
  providedInputs: "Input Forniti",
  solvingFormula: "Formula Risolutiva",
  mathStructure: "Formula Matematica e Struttura",
  operationDetails: "Dettagli Operazione",
};

export const GROUP_LABELS_TR: Record<string, string> = {
  "Finance": "Finans",
  "Mathematics": "Matematik",
  "Health": "Sağlık",
  "Others": "Diğerleri",
  "Mortgages & Housing": "Konut & Gayrimenkul Kredileri",
  "Vehicle & Consumer Loans": "Taşıt & Tüketici Kredileri",
  "Investments & Retirement": "Yatırım, Birikim & Emeklilik",
  "Tax & Budgeting": "Vergi & Bütçe Planlama",
  "General & Scientific Math": "Genel & Bilimsel Matematik",
  "Security Utilities": "Güvenlik Araçları",
  "Body Metrics": "Vücut Ölçümleri & Kilo",
  "Nutrition & Energy": "Beslenme & Enerji",
  "Time & Date": "Zaman & Tarih",
  "Astrology & Charts": "Astroloji & Doğum Haritası",
  "Discover Custom Calculator": "Özel Hesaplayıcı Oluşturun",
  "Use the search bar to find or generate customized calculators dynamically.": "Arama kutusuna dilediğinizi yazıp canlandırarak yeni hesaplayıcılar üretebilirsiniz."
};

export const GROUP_LABELS_ALL: Record<string, Record<string, string>> = {
  en: {
    "Finance": "Finance",
    "Mathematics": "Mathematics",
    "Health": "Health & Fitness",
    "Others": "Others",
    "Mortgages & Housing": "Mortgages & Housing",
    "Vehicle & Consumer Loans": "Vehicle & Consumer Loans",
    "Investments & Retirement": "Investments & Retirement",
    "Tax & Budgeting": "Tax & Budgeting",
    "General & Scientific Math": "General & Scientific Math",
    "Security Utilities": "Security Utilities",
    "Body Metrics": "Body Metrics",
    "Nutrition & Energy": "Nutrition & Energy",
    "Time & Date": "Time & Date",
    "Astrology & Charts": "Astrology & Birth Charts",
    "Discover Custom Calculator": "Discover Custom Calculator",
    "Use the search bar to find or generate customized calculators dynamically.": "Use the search bar to find or generate customized calculators dynamically."
  },
  tr: GROUP_LABELS_TR,
  es: {
    "Finance": "Finanzas",
    "Mathematics": "Matemáticas",
    "Health": "Salud",
    "Others": "Otros",
    "Mortgages & Housing": "Hipotecas y Vivienda",
    "Vehicle & Consumer Loans": "Préstamos de Vehículos y Consumo",
    "Investments & Retirement": "Inversiones y Jubilación",
    "Tax & Budgeting": "Impuestos y Presupuesto",
    "General & Scientific Math": "Matemática General y Científica",
    "Security Utilities": "Utilidades de Seguridad",
    "Body Metrics": "Métricas Corporales",
    "Nutrition & Energy": "Nutrición y Energía",
    "Time & Date": "Tiempo y Fecha",
    "Astrology & Charts": "Astrología y Cartas Astrales",
    "Discover Custom Calculator": "Descubra Calculadora Personalizada",
    "Use the search bar to find or generate customized calculators dynamically.": "Use el cuadro de búsqueda para generar calculadoras optimizadas dinámicamente."
  },
  de: {
    "Finance": "Finanzen",
    "Mathematics": "Mathematik",
    "Health": "Gesundheit",
    "Others": "Sonstige",
    "Mortgages & Housing": "Hypotheken & Wohnen",
    "Vehicle & Consumer Loans": "Fahrzeug- & Verbraucherkredite",
    "Investments & Retirement": "Investitionen & Ruhestand",
    "Tax & Budgeting": "Steuern & Budget",
    "General & Scientific Math": "Allgemeine & Wissenschaftliche Math",
    "Security Utilities": "Sicherheits-Tools",
    "Body Metrics": "Körpermaße",
    "Nutrition & Energy": "Ernährung & Energie",
    "Time & Date": "Zeit & Datum",
    "Astrology & Charts": "Astrologie & Horoskop",
    "Discover Custom Calculator": "Eigene Rechner entdecken",
    "Use the search bar to find or generate customized calculators dynamically.": "Nutzen Sie die Suchleiste, um Rechner dynamisch zu generieren."
  },
  fr: {
    "Finance": "Finances",
    "Mathematics": "Mathématiques",
    "Health": "Santé",
    "Others": "Autres",
    "Mortgages & Housing": "Hypothèques & Logement",
    "Vehicle & Consumer Loans": "Prêts Véhicules & Consommation",
    "Investments & Retirement": "Investissements & Retraite",
    "Tax & Budgeting": "Impôts & Budget",
    "General & Scientific Math": "Mathématiques Générales & Scientifiques",
    "Security Utilities": "Utilitaires de Sécurité",
    "Body Metrics": "Mesures Corporelles",
    "Nutrition & Energy": "Nutrition & Énergie",
    "Time & Date": "Temps & Date",
    "Astrology & Charts": "Astrologie & Thèmes Astraux",
    "Discover Custom Calculator": "Découvrir Calculatrice Personnalisée",
    "Use the search bar to find or generate customized calculators dynamically.": "Utilisez la barre de recherche pour générer des calculatrices dynamiquement."
  },
  it: {
    "Finance": "Finanza",
    "Mathematics": "Matematica",
    "Health": "Salute",
    "Others": "Altri",
    "Mortgages & Housing": "Mutui e Casa",
    "Vehicle & Consumer Loans": "Prestiti Auto e Consumo",
    "Investments & Retirement": "Investimenti e Pensione",
    "Tax & Budgeting": "Tasse e Budget",
    "General & Scientific Math": "Matematica Generale e Scientifica",
    "Security Utilities": "Utilità di Sicurezza",
    "Body Metrics": "Metriche Corporee",
    "Nutrition & Energy": "Nutrizione ed Energia",
    "Time & Date": "Tempo e Data",
    "Astrology & Charts": "Astrologia e Mappe",
    "Discover Custom Calculator": "Crea Calcolatrice Personalizzata",
    "Use the search bar to find or generate customized calculators dynamically.": "Usa la barra di ricerca per creare o trovare calcolatrici dinamiche."
  }
};

export const CALC_LOCALE_MAP: Record<string, { title: string; desc: string }> = {
  "Rent Calculator": {
    title: "Kira Ödeme Hesaplayıcı",
    desc: "Kira bütçenizi, depozito durumlarını ve gelire göre kira rasyosunu analiz edin."
  },
  "Mortgage Calculator": {
    title: "Konut Kredisi Hesaplayıcı",
    desc: "Aylık taksitleri, faiz oranlarını ve amortisman takvimini değerlendirin."
  },
  "Loan Calculator": {
    title: "Bireysel Kredi Ödeme Çözücü",
    desc: "Yıllık maliyet oranını, toplam faiz miktarını ve ödeme aşamalarını bulun."
  },
  "Compound Interest Calculator": {
    title: "Bileşik Faiz Hesaplayıcı",
    desc: "Gelecekteki birikim büyümesini, bileşik faiz sıklığını ve vade tutarlarını hesaplayın."
  },
  "ROI Calculator": {
    title: "Yatırım Getirisi (ROI) Çözücü",
    desc: "Yatırımlarınızın brüt ve net getiri oranlarını (ROI) anında değerlendirin."
  },
  "Salary & Take-Home Pay Calculator": {
    title: "Maaş ve Net Gelir Hesaplayıcı",
    desc: "Vergiler düşüldükten sonra cebinize kalacak gerçek net kazancı görün."
  },
  "VAT & Sales Tax Calculator": {
    title: "KDV ve Satış Vergisi Hesaplayıcı",
    desc: "Matrah, KDV dahil ve KDV hariç tutarları kolayca ayrıştırın."
  },
  "Discount & Savings Calculator": {
    title: "İndirim ve Tasarruf Hesaplayıcı",
    desc: "İndirim oranlarını, net kazancı ve tasarruf ettiğiniz tutarı görün."
  },
  "Budget Planner & Savings Rules": {
    title: "Bütçe Planlayıcı ve Tasarruf Kuralları",
    desc: "Gelir-gider dengenizi kurup tasarruf hedeflerine ulaşmanızı sağlayan kurallar."
  },
  "50/30/20 Budget Calculator": {
    title: "50/30/20 Bütçe Kuralı Çözücü",
    desc: "Gelirinizi %50 İhtiyaçlar, %30 İstekler ve %20 Birikim olarak paylaştırın."
  },
  "Credit Card Debt Payoff Tracker": {
    title: "Kredi Kartı Borç Kapatma Analizi",
    desc: "Kart asgari ödeme tuzaklarından kaçınarak borç bitiş tarihini öngörün."
  },
  "Inflation & Purchase Power Calculator": {
    title: "Enflasyon ve Alım Gücü Kaybı",
    desc: "Paranızın yıllar içindeki değer kaybını ve gelecekteki alım gücünü hesaplayın."
  },
  "Savings Goal & Growth Forecast": {
    title: "Tasarruf Hedefi ve Büyüme Öngörüsü",
    desc: "Hedeflediğiniz birikime ulaşmak için aylık ne kadar tasarruf etmeniz gerektiğini hesaplayın."
  },
  "Basic Calculator": {
    title: "Basit Matematik Hesap Makinesi",
    desc: "Dört işlem aritmetiğini (+, −, ×, ÷) anında uygulayın."
  },
  "Percentage Calculator": {
    title: "Yüzde Hesaplama Aracı",
    desc: "Yüzde değişimlerini, oranları ve artış/azalış miktarlarını bulun."
  },
  "Fraction Calculator": {
    title: "Kesir Hesaplama Çözücü",
    desc: "Kesirli sayıları toplayın, çıkarın, çarpın veya sadeleştirerek bölün."
  },
  "Exponent Calculator": {
    title: "Üslü Sayı Hesaplama",
    desc: "Bir tabanın dilediğiniz üst dereceden kuvvetini ve adım adım çarpanlarını bulun."
  },
  "Square Root Calculator": {
    title: "Kareköklü Sayı Hesaplayıcı",
    desc: "Karekök ve n. dereceden kök işlemlerini çözüm mantığıyla görün."
  },
  "Linear Equation Solver": {
    title: "Doğrusal Denklem Çözücü",
    desc: "ax + b = c şeklindeki tek bilinmeyenli doğrusal denklemleri çözün."
  },
  "Quadratic Equation Solver": {
    title: "İkinci Dereceden Denklem Çözücü",
    desc: "ax² + bx + c = 0 denkleminin diskriminant (Δ) ve reel köklerini bulun."
  },
  "Function Value Calculator": {
    title: "Fonksiyon Değeri Çözücü",
    desc: "Belirli bir x değeri için f(x) matematiksel fonksiyonunun değerini bulun."
  },
  "Function Graph Calculator": {
    title: "Fonksiyon Grafik Değerleyici",
    desc: "Matematiksel fonksiyon değerlerini ve adımlarını görüntüleyin."
  },
  "Mean / Median / Mode Calculator": {
    title: "Ortalama / Medyan / Mod Çözücü",
    desc: "Veri gruplarının aritmetik ortalama, medyan ortası, tepe değer mod özelliklerini bulun."
  },
  "Standard Deviation Calculator": {
    title: "Standart Sapma Hesaplayıcı",
    desc: "Varyans ve standart sapma değerleriyle veri serisinin dağılımını hesaplayın."
  },
  "Permutation / Combination Calculator": {
    title: "Permütasyon ve Kombinasyon Çözücü",
    desc: "n elemanlı bir kümenin r'li permütasyon P(n, r) ve kombinasyon C(n, r) değerlerini bulun."
  },
  "Logarithm Calculator": {
    title: "Logaritma Hesaplama Çözücü",
    desc: "Belirli tabanlarda sayıların logaritma değerini ve doğal logaritmasını (ln) hesaplayın."
  },
  "Matrix Calculator": {
    title: "Matris Çözücü",
    desc: "Matris determinantları ve matris işlemlerini yapın."
  },
  "Ratio / Proportion Calculator": {
    title: "Oran ve Orantı Hesaplayıcı",
    desc: "A/B = C/D orantısında bilinmeyen dördüncü değeri bulun."
  },
  "BMI Calculator": {
    title: "Vücut Kitle İndeksi (BMI) Ölçer",
    desc: "Boy kilonuza göre sağlıklı kilo aralığında olup olmadığınızı öğrenin."
  },
  "BMR Calculator": {
    title: "Bazal Metabolizma Hızı (BMR) Hesaplama",
    desc: "Hiç hareket etmeden günde yaktığınız temel kalori miktarını (BMR) öğrenin."
  },
  "TDEE Calculator": {
    title: "Toplam Günlük Enerji Harcaması (TDEE)",
    desc: "Aktivite seviyenize göre günlük harcadığınız toplam kalori miktarını hesaplayın."
  },
  "Ideal Weight Calculator": {
    title: "İdeal Kilo Hesaplatma",
    desc: "Farklı tıbbi formüllere göre olmanız gereken ideal sağlıklı hedef kiloyu bulun."
  },
  "Water Intake Calculator": {
    title: "Günlük Su Tüketim Hesaplayıcı",
    desc: "Kilonuz ve egzersiz durumunuza göre günlük içmeniz gereken su miktarını belirleyin."
  },
  "Calories Burned Calculator": {
    title: "Egzersiz Kalori Yakım Hesaplayıcı",
    desc: "Farklı spor ve aktivitelerde geçirdiğiniz sürede harcanan kalori miktarını bulun."
  }
};

export const CALC_LOCALE_MAP_ALL: Record<string, Record<string, { title: string; desc: string }>> = {
  tr: CALC_LOCALE_MAP,
  en: {
    "Rent Calculator": {
      title: "Rent Calculator",
      desc: "Analyze lease budgets, depositories, and rent-to-earnings affordability ratio."
    },
    "Mortgage Calculator": {
      title: "Mortgage Calculator",
      desc: "Evaluate monthly repayments, down payments, property taxes, and complete amortization."
    },
    "Loan Calculator": {
      title: "Personal Loan Payoff Solver",
      desc: "Analyze annual rate percentage, total overall interest compound, and month timelines."
    },
    "Compound Interest Calculator": {
      title: "Compound Interest Calculator",
      desc: "Forecast strategic future wealth accumulations with configurable interest compounds."
    }
  },
  es: {
    "Rent Calculator": {
      title: "Calculadora de Alquiler",
      desc: "Analice los presupuestos de alquiler, los depósitos y la relación de asequibilidad de los ingresos."
    },
    "Mortgage Calculator": {
      title: "Calculadora de Hipoteca",
      desc: "Evalúe los pagos mensuales, los impuestos a la propiedad y la amortización."
    },
    "Loan Calculator": {
      title: "Calculadora de Préstamo",
      desc: "Analice las tasas anuales de interés, costo total del préstamo y plazos."
    },
    "Compound Interest Calculator": {
      title: "Calculadora de Interés Compuesto",
      desc: "Prevea el crecimiento de ahorros con capitalización de intereses configurable."
    },
    "ROI Calculator": {
      title: "Calculadora de ROI",
      desc: "Evalúe el rendimiento de sus inversiones al instante."
    },
    "Salary & Take-Home Pay Calculator": {
      title: "Calculadora de Salario Neto",
      desc: "Vea su sueldo neto en efectivo aproximado después del impuesto."
    },
    "VAT & Sales Tax Calculator": {
      title: "Calculadora de IVA y Tasas",
      desc: "Calcule impuestos de ventas, base limpia e IVA con facilidad."
    },
    "Discount & Savings Calculator": {
      title: "Calculadora de Descuentos",
      desc: "Calcule el precio de venta final después de los descuentos."
    },
    "Budget Planner & Savings Rules": {
      title: "Plan de Presupuesto y Reglas",
      desc: "Establezca metas mensuales y realice un seguimiento de gastos."
    },
    "50/30/20 Budget Calculator": {
      title: "Calculadora de Presupuesto 50/30/20",
      desc: "Divida ingresos en 50% necesidades, 30% deseos y 20% ahorros."
    },
    "Credit Card Debt Payoff Tracker": {
      title: "Seguimiento de Deuda de Tarjeta",
      desc: "Calcule plazos para pagar su deuda y evite pagos mínimos."
    },
    "Inflation & Purchase Power Calculator": {
      title: "Calculadora de Inflación",
      desc: "Mida el poder adquisitivo cambiante de su dinero a lo largo de los años."
    },
    "Savings Goal & Growth Forecast": {
      title: "Pronóstico y Meta de Ahorro",
      desc: "Planifique su ahorro mensual necesario para su meta deseada."
    },
    "Basic Calculator": {
      title: "Calculadora Básica",
      desc: "Aritmética estándar (+, −, ×, ÷) para operaciones rápidas día a día."
    },
    "Percentage Calculator": {
      title: "Calculadora de Porcentaje",
      desc: "Resuelva cambios porcentuales, razones y proporciones."
    },
    "Fraction Calculator": {
      title: "Calculadora de Fracciones",
      desc: "Sume, reste, multiplique o divida fracciones comunes."
    },
    "Exponent Calculator": {
      title: "Calculadora de Exponentes",
      desc: "Calcule potencias exponenciales y visualice bases."
    },
    "Square Root Calculator": {
      title: "Calculadora de Raíz Cuadrada",
      desc: "Resuelva raíces cuadradas de números y raíces N."
    },
    "Linear Equation Solver": {
      title: "Resolvedor de Ecuación Lineal",
      desc: "Resuelva ecuaciones algebraicas de primer grado x."
    },
    "Quadratic Equation Solver": {
      title: "Resolvedor de Ecuación Cuadrática",
      desc: "Halle las raíces y discriminantes de modelos ax² + bx + c = 0."
    },
    "Function Value Calculator": {
      title: "Cálculo de Función Matemática",
      desc: "Sustituya variables y analice valores funcionales."
    },
    "Function Graph Calculator": {
      title: "Evaluador de Gráficos de Funciones",
      desc: "Visualice puntos y rangos matemáticos."
    },
    "Mean / Median / Mode Calculator": {
      title: "Media / Mediana / Moda",
      desc: "Análisis estadístico de conjuntos de muestras físicas."
    },
    "Standard Deviation Calculator": {
      title: "Calculadora de Desviación Estándar",
      desc: "Halle la varianza, el promedio y la dispersión estándar."
    },
    "Permutation / Combination Calculator": {
      title: "Permutaciones y Combinaciones",
      desc: "Calcule factoriales de permutaciones ordenadas n y combinaciones r."
    },
    "Logarithm Calculator": {
      title: "Calculadora de Logaritmos",
      desc: "Calcule logaritmos en base 10, e (ln) y bases N."
    },
    "Matrix Calculator": {
      title: "Calculadora de Matrices",
      desc: "Halle determinantes y haga operaciones matriciales."
    },
    "Ratio / Proportion Calculator": {
      title: "Calculadora de Razones",
      desc: "Resuelva proporciones equivalentes y razones."
    },
    "BMI Calculator": {
      title: "Calculadora de IMC",
      desc: "Calcule el índice de masa corporal e intervalos de salud."
    },
    "BMR Calculator": {
      title: "Tasa Metabólica Basal (BMR)",
      desc: "Calcule la energía básica quemada en reposo."
    },
    "TDEE Calculator": {
      title: "Gasto Energético Diario (TDEE)",
      desc: "Halle sus necesidades diarias de calorías según su nivel deportivo."
    },
    "Ideal Weight Calculator": {
      title: "Calculadora de Peso Ideal",
      desc: "Estime objetivos médicos recomendados de peso."
    },
    "Water Intake Calculator": {
      title: "Calculadora de Consumo de Agua",
      desc: "Determine litros óptimos diarios."
    },
    "Calories Burned Calculator": {
      title: "Calorías Quemadas por Actividad",
      desc: "Calcule la energía quemada por pasatiempo o deporte."
    }
  },
  de: {
    "Rent Calculator": {
      title: "Mietrechner",
      desc: "Analysieren Sie Ihr Mietbudget und Verhältnis von Miete zu Einkommen."
    },
    "Mortgage Calculator": {
      title: "Hypothekenrechner",
      desc: "Bewerten Sie monatliche Raten, Anzahlungen, Steuern und Tilgungspläne."
    },
    "Loan Calculator": {
      title: "Kreditrechner",
      desc: "Berechnen Sie jährliche Kreditzinsen, Gesamtkosten und Laufzeiten."
    },
    "Compound Interest Calculator": {
      title: "Zinseszinsrechner",
      desc: "Berechnen Sie das zukünftige Sparwachstum mit Zinseszins."
    },
    "ROI Calculator": {
      title: "Investitionsrendite (ROI)",
      desc: "Bestimmen Sie die Netto- und Bruttorenditen Ihrer Vermögenwerte."
    },
    "Salary & Take-Home Pay Calculator": {
      title: "Nettogehaltrechner",
      desc: "Berechnen Sie Ihr geschätztes reales Nettoeinkommen nach Abzug."
    },
    "VAT & Sales Tax Calculator": {
      title: "Mehrwertsteuer-Rechner",
      desc: "Ermitteln Sie Netto- und Bruttobeträge mit MwSt."
    },
    "Discount & Savings Calculator": {
      title: "Rabatt- und Sparrechner",
      desc: "Berechnen Sie den verbleibenden Preis mit Rabatt."
    },
    "Budget Planner & Savings Rules": {
      title: "Budgetplaner & Sparregeln",
      desc: "Definieren Sie Ausgabelimits und Sparziele."
    },
    "50/30/20 Budget Calculator": {
      title: "50/30/20 Budgetrechner",
      desc: "Teilen Sie Ihr Einkommen in 50% Bedürfnisse, 30% Wünsche, 20% Sparen."
    },
    "Credit Card Debt Payoff Tracker": {
      title: "Kreditkarten-Schuldenplaner",
      desc: "Berechnen Sie Fristen zur Schuldenfreiheit."
    },
    "Inflation & Purchase Power Calculator": {
      title: "Inflationsrechner",
      desc: "Messen Sie den echten Kaufkraftverlust Ihres Sparguthabens."
    },
    "Savings Goal & Growth Forecast": {
      title: "Sparziel- und Wachstumrechner",
      desc: "Ermitteln Sie Ihre monatliche Sparrate für Ihr Sparziel."
    },
    "Basic Calculator": {
      title: "Einfacher Rechner",
      desc: "Standardoperationen für alltägliche mathematische Aufgaben."
    },
    "Percentage Calculator": {
      title: "Prozentrechner",
      desc: "Berechnen Sie prozentuale Änderungen und Verhältnisse."
    },
    "Fraction Calculator": {
      title: "Bruchrechner",
      desc: "Brüche addieren, subtrahieren, multiplizieren oder dividieren."
    },
    "Exponent Calculator": {
      title: "Potenzrechner",
      desc: "Ermitteln Sie Potenzen und Basen."
    },
    "Square Root Calculator": {
      title: "Wurzelrechner",
      desc: "Berechnen Sie Quadratwurzeln und n-te Wurzeln."
    },
    "Linear Equation Solver": {
      title: "Linearer Gleichungslöser",
      desc: "Lösen Sie einfache algebraische Gleichungen ersten Grades."
    },
    "Quadratic Equation Solver": {
      title: "Quadratischer Gleichungslöser",
      desc: "Berechnen Sie Diskriminanten und reelle Wurzeln."
    },
    "Function Value Calculator": {
      title: "Funktionswert-Berechner",
      desc: "Bestimmen Sie y-Werte für beliebige x-Variablen."
    },
    "Function Graph Calculator": {
      title: "Funktionsgraph-Auswerter",
      desc: "Untersuchen Sie Wertebereiche und Punkte."
    },
    "Mean / Median / Mode Calculator": {
      title: "Mittelwert / Median / Modus",
      desc: "Statistische Kennzahlen für Ihre Datengruppe."
    },
    "Standard Deviation Calculator": {
      title: "Standardabweichungs-Berechner",
      desc: "Berechnen Sie Varianz, Durchschnitt und Abweichung."
    },
    "Permutation / Combination Calculator": {
      title: "Permutationsrechner",
      desc: "Fakultäten & Kombinationen berechnen."
    },
    "Logarithm Calculator": {
      title: "Logarithmusrechner",
      desc: "Logarithmen zur Basis 10, e (ln) und beliebigen Basen."
    },
    "Matrix Calculator": {
      title: "Matrix-Berechner",
      desc: "Berechnen Sie Determinanten und Matrixoperationen."
    },
    "Ratio / Proportion Calculator": {
      title: "Verhältnis-Rechner",
      desc: "Lösen Sie proportionale Verhältnisse auf."
    },
    "BMI Calculator": {
      title: "BMI-Rechner",
      desc: "Prüfen Sie Ihr Gewicht im Verhältnis zur Körpergröße."
    },
    "BMR Calculator": {
      title: "Grundumsatz-Rechner (BMR)",
      desc: "Kalorienbedarf im absoluten Ruhezustand."
    },
    "TDEE Calculator": {
      title: "Gesamtumsatz-Rechner (TDEE)",
      desc: "Täglicher Energieverbrauch mit Aktivitäten."
    },
    "Ideal Weight Calculator": {
      title: "Idealgewicht-Rechner",
      desc: "Wissenschaftliche Schätzungen für Ihr Idealgewicht."
    },
    "Water Intake Calculator": {
      title: "Wasserbedarfsrechner",
      desc: "Ermitteln Sie die optimale tägliche Trinkmenge in Litern."
    },
    "Calories Burned Calculator": {
      title: "Kalorienverbrauch-Rechner",
      desc: "Berechnen Sie den Verbrauch durch Sport & Freizeit."
    }
  },
  fr: {
    "Rent Calculator": {
      title: "Calculateur de Loyer",
      desc: "Analysez vos budgets de location et le coût par rapport au revenu."
    },
    "Mortgage Calculator": {
      title: "Calculateur d'Hypothèque",
      desc: "Évaluez les mensualités, les taxes foncières et l'amortissement complet."
    },
    "Loan Calculator": {
      title: "Calculateur de Prêt",
      desc: "Analysez les taux annuels, le coût total des intérêts et les échéances."
    },
    "Compound Interest Calculator": {
      title: "Calculateur d'Intérêts Composés",
      desc: "Projetez la croissance de votre épargne avec capitalisation."
    },
    "ROI Calculator": {
      title: "Calculateur de ROI",
      desc: "Évaluez le rendement financier brut et net de vos investissements."
    },
    "Salary & Take-Home Pay Calculator": {
      title: "Calculateur de Salaire Net",
      desc: "Visualisez votre salaire de poche réel estimé après impôt."
    },
    "VAT & Sales Tax Calculator": {
      title: "Calculateur de TVA",
      desc: "Calculez les montants HT, TTC et la taxe correspondante."
    },
    "Discount & Savings Calculator": {
      title: "Calculateur de Rabais et Épargne",
      desc: "Affichez les prix finaux et les économies réalisées."
    },
    "Budget Planner & Savings Rules": {
      title: "Planificateur de Budget",
      desc: "Gérez votre balance de revenus et fixez des objectifs."
    },
    "50/30/20 Budget Calculator": {
      title: "Calculateur de Budget 50/30/20",
      desc: "Répartissez vos revenus mensuels : 50% besoins, 30% envies, 20% épargne."
    },
    "Credit Card Debt Payoff Tracker": {
      title: "Suivi des Dettes de Carte",
      desc: "Estimez les délais de remboursement complet."
    },
    "Inflation & Purchase Power Calculator": {
      title: "Calculateur d'Inflation",
      desc: "Calculez le pouvoir d'achat de votre monnaie à travers les ans."
    },
    "Savings Goal & Growth Forecast": {
      title: "Prévisions d'Épargne",
      desc: "Calculez l'épargne nécessaire pour atteindre vos objectifs d'avenir."
    },
    "Basic Calculator": {
      title: "Calculatrice Basique",
      desc: "Opérations simples ordinaires pour calculs rapides de tous les jours."
    },
    "Percentage Calculator": {
      title: "Calculateur de Pourcentage",
      desc: "Résolvez les évolutions, taux de croissance et ratios."
    },
    "Fraction Calculator": {
      title: "Calculateur de Fractions",
      desc: "Ajoutez, soustrayez, multipliez ou divisez des fractions."
    },
    "Exponent Calculator": {
      title: "Calculateur d'Exposants",
      desc: "Résolvez des équations de puissances et exposants."
    },
    "Square Root Calculator": {
      title: "Calculateur de Raiz Carrée",
      desc: "Calculez les racines carrées et racines N."
    },
    "Linear Equation Solver": {
      title: "Résolution d'Équation Linéaire",
      desc: "Résolvez des équations algébriques simples de premier degré x."
    },
    "Quadratic Equation Solver": {
      title: "Résolution d'Équation Quadratique",
      desc: "Trouvez les racines de polynômes ax² + bx + c = 0."
    },
    "Function Value Calculator": {
      title: "Valeur de Fonction Mathématique",
      desc: "Évaluez des fonctions pour n'importe quelle variable x."
    },
    "Function Graph Calculator": {
      title: "Analyse de Graphes de Fonctions",
      desc: "Visualisez les coordonnées et points de calcul."
    },
    "Mean / Median / Mode Calculator": {
      title: "Moyenne / Médiane / Mode",
      desc: "Calculs de statistiques de base sur des échantillons."
    },
    "Standard Deviation Calculator": {
      title: "Calculateur d'Écart Word/Type",
      desc: "Calculez la variance, la moyenne et l'écart type."
    },
    "Permutation / Combination Calculator": {
      title: "Permutations et Combinaisons",
      desc: "Calculez les factorielles et combinaisons n et r."
    },
    "Logarithm Calculator": {
      title: "Calculateur de Logarithme",
      desc: "Calculez les log de base 10, base e (ln) ou N."
    },
    "Matrix Calculator": {
      title: "Calculateur de Matrices",
      desc: "Calculez les déterminants de matrices et opérations."
    },
    "Ratio / Proportion Calculator": {
      title: "Calculateur de Ratios",
      desc: "Résolvez des équivalences de ratios proportionnels."
    },
    "BMI Calculator": {
      title: "Calculateur d'IMC",
      desc: "Indice de masse corporelle selon le poids et taille."
    },
    "BMR Calculator": {
      title: "Métabolisme de Base (BMR)",
      desc: "Calculez l'énergie consommée par le corps au repos."
    },
    "TDEE Calculator": {
      title: "Dépense Énergétique Totale (TDEE)",
      desc: "Caloriques recommandés selon l'activité."
    },
    "Ideal Weight Calculator": {
      title: "Calculateur de Poids Idéal",
      desc: "Objectifs de poids idéaux ajustés."
    },
    "Water Intake Calculator": {
      title: "Consommation d'Eau Recommandée",
      desc: "Mesurez la quantité d'eau idéale journalière."
    },
    "Calories Burned Calculator": {
      title: "Calories Brûlées par Activité",
      desc: "Mesurez les calories consommées par le sport & les loisirs."
    }
  },
  it: {
    "Rent Calculator": {
      title: "Calcolatore di Affitto",
      desc: "Sviluppa i tuoi budget correnti per affitti e depositi."
    },
    "Mortgage Calculator": {
      title: "Calcolatore di Mutuo",
      desc: "Calcola rate mensili, versamento iniziale, tasse e ammortamento."
    },
    "Loan Calculator": {
      title: "Calcolatore di Prestito",
      desc: "Analizza tassi percentuali annui del prestito residuo."
    },
    "Compound Interest Calculator": {
      title: "Calcolatore Interessi Composti",
      desc: "Prevedi la crescita dei tuoi risparmi capitalizzati."
    },
    "ROI Calculator": {
      title: "Calculadora de ROI",
      desc: "Valuta le percentuali nette di ritorno sugli investimenti economici."
    },
    "Salary & Take-Home Pay Calculator": {
      title: "Calcolo Stipendio Netto",
      desc: "Visualizza lo stipendio effettivo rimasto dopo tasse nazionali."
    },
    "VAT & Sales Tax Calculator": {
      title: "Calcolatore di IVA",
      desc: "Deduci facilmente base imponibile, IVA inclusa e scorpori."
    },
    "Discount & Savings Calculator": {
      title: "Calcolatore Sconti e Risparmi",
      desc: "Trova il prezzo finale post sconti commerciali."
    },
    "Budget Planner & Savings Rules": {
      title: "Pianificazione Budget Mensile",
      desc: "Regola flussi di spesa e pianifica depositi sicuri."
    },
    "50/30/20 Budget Calculator": {
      title: "Calcolo Budget 50/30/20",
      desc: "Dividi entrate in 50% bisogni, 30% svaghi, 20% risparmio."
    },
    "Credit Card Debt Payoff Tracker": {
      title: "Estinzione Debito Carta Credito",
      desc: "Traccia scadenze libere da asfissia di tassi minimi."
    },
    "Inflation & Purchase Power Calculator": {
      title: "Calcolatore Inflazione",
      desc: "Valuta storicamente l'erosione del potere d'acquisto."
    },
    "Savings Goal & Growth Forecast": {
      title: "Previsioni Risparmi",
      desc: "Calcula i versamenti periodici necessari per completare obiettivi."
    },
    "Basic Calculator": {
      title: "Calcolatrice Semplice",
      desc: "Aritmetica quotidiana diretta (+, −, ×, ÷)."
    },
    "Percentage Calculator": {
      title: "Calcolo Percentuali",
      desc: "Calcola variazioni percentuali, tassi e incrementi rapidi."
    },
    "Fraction Calculator": {
      title: "Calcolo Frazioni",
      desc: "Somma, sottrai, moltiplica e dividi frazioni e decimali."
    },
    "Exponent Calculator": {
      title: "Calcolo Esponenti",
      desc: "Estrai potenze ed esponenti passo-passo."
    },
    "Square Root Calculator": {
      title: "Calcolo Radici",
      desc: "Trova radici quadrate e radici ennesime."
    },
    "Linear Equation Solver": {
      title: "Risolutore Equazioni Lineari",
      desc: "Risolvi equazioni algebriche di primo grado x."
    },
    "Quadratic Equation Solver": {
      title: "Risolutore Equazioni Secondo Grado",
      desc: "Estrai soluzioni e delta ax² + bx + c = 0."
    },
    "Function Value Calculator": {
      title: "Valori Funzione",
      desc: "Verifica l'output y a qualsiasi livello x della curva."
    },
    "Function Graph Calculator": {
      title: "Analizzatore Punti Grafici",
      desc: "Riconosce coordinate e punti di intersezione."
    },
    "Mean / Median / Mode Calculator": {
      title: "Media / Mediana / Moda",
      desc: "Statistiche descriptive generali di insiemi."
    },
    "Standard Deviation Calculator": {
      title: "Varianza e Deviazione Standard",
      desc: "Calcola la varianza geometrica e deviazione."
    },
    "Permutation / Combination Calculator": {
      title: "Permutazioni e Combinazioni",
      desc: "Fattoriali di calcolo combinatorio n e r."
    },
    "Logarithm Calculator": {
      title: "Calcolo Logaritmi",
      desc: "Valuta logaritmi in base 10, naturale ln o base N."
    },
    "Matrix Calculator": {
      title: "Calcolo Matrici",
      desc: "Operazioni con matrici e calcolo determinanti."
    },
    "Ratio / Proportion Calculator": {
      title: "Calcolatore Rapporti",
      desc: "Risolvi costanti di rapporto equivalenti."
    },
    "BMI Calculator": {
      title: "Calcolo dell'IMC",
      desc: "Calcola l'indice di massa grassa corporea."
    },
    "BMR Calculator": {
      title: "Calcolo BMR",
      desc: "Calcola il metabolismo biologico basale a riposo."
    },
    "TDEE Calculator": {
      title: "Calcolo del TDEE",
      desc: "Trova le calorie totali con attività sportiva."
    },
    "Ideal Weight Calculator": {
      title: "Calcolo del Peso Ideale",
      desc: "Verifica i pesi ideali medici raccomandati."
    },
    "Water Intake Calculator": {
      title: "Calcolatore Fabbisogno Idrico",
      desc: "Ottieni i litri quotidiani d'acqua necessari."
    },
    "Calories Burned Calculator": {
      title: "Consumo Calorie Attività",
      desc: "Calcola calorie consumate per sport ed hobby."
    }
  }
};
