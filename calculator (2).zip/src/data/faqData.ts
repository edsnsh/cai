import { CalculatorTool } from "../types";

export interface FaqItem {
  question: string;
  answer: string;
}

export const PREDEFINED_FAQS: Record<string, FaqItem[]> = {
  mortgage_calculator: [
    {
      question: "What is included in my estimated monthly mortgage payment?",
      answer: "Your estimated monthly mortgage payment consists primarily of Principal and Interest (P&I). Depending on your setup, it also factors in Property Taxes, Homeowners Insurance, Private Mortgage Insurance (PMI), and HOA fees."
    },
    {
      question: "How does my down payment percentage affect my mortgage cost?",
      answer: "A larger down payment reduces your total loan principal, lowering your monthly payments and total interest paid over time. Putting down 20% or more also eliminates the requirement for Private Mortgage Insurance (PMI)."
    },
    {
      question: "What is PMI (Private Mortgage Insurance) and when can I cancel it?",
      answer: "PMI is insurance that protects the lender if you default on the loan. It is usually required when down payment is under 20%. You can request PMI cancellation once your loan balance drops to 80% of original home value."
    },
    {
      question: "How does a 15-year mortgage compare to a 30-year mortgage?",
      answer: "A 15-year mortgage features higher monthly payments because the loan is repaid faster, but it comes with lower interest rates and saves substantial money in total interest compared to a 30-year mortgage."
    },
    {
      question: "Can I make extra payments to pay off my mortgage early?",
      answer: "Yes, most conventional mortgages have no prepayment penalties. Making additional principal payments reduces your remaining balance faster and significantly shortens your loan term."
    }
  ],

  investment_calculator: [
    {
      question: "How does compound interest accelerate wealth building over time?",
      answer: "Compound interest generates return earnings on both your initial principal and accumulated interest over time. Over multi-year horizons, this compounding effect creates exponential portfolio growth."
    },
    {
      question: "What annual return rate should I assume for long-term growth?",
      answer: "Historically, broad market stock indexes like the S&P 500 have averaged approximately 7% to 10% annual returns before inflation. Conservative portfolios typically average 3% to 5% annually."
    },
    {
      question: "Why are consistent monthly contributions so effective?",
      answer: "Regular monthly contributions continually expand your earning base and take advantage of dollar-cost averaging, smoothing out market volatility while accelerating overall wealth growth."
    },
    {
      question: "How does inflation impact my total investment return value?",
      answer: "Inflation erodes the purchasing power of money over time. To preserve real wealth, your target investment return rate should comfortably exceed average annual inflation."
    },
    {
      question: "What is the difference between simple interest and compound interest?",
      answer: "Simple interest is calculated solely on the original principal amount, whereas compound interest is calculated on both principal and accumulated earnings from previous periods."
    }
  ],

  loan_calculator: [
    {
      question: "How is my monthly loan payment calculated?",
      answer: "Monthly loan payments are computed using a standard amortization formula based on total loan principal, annual interest rate (APR), and loan duration in months."
    },
    {
      question: "What is the difference between interest rate and APR?",
      answer: "The interest rate refers to the direct borrowing cost, while APR (Annual Percentage Rate) includes loan fees and closing charges for a complete comparison."
    },
    {
      question: "Does paying extra towards principal reduce overall loan cost?",
      answer: "Yes! Any extra payment applied directly to your principal balance reduces future interest calculations, shortening your repayment term and saving money."
    },
    {
      question: "Are fixed-rate loans safer than variable-rate loans?",
      answer: "Fixed-rate loans lock in your interest rate and monthly payment for the entire loan duration, shielding you from rising market interest rates."
    },
    {
      question: "What factors influence the interest rate offered by lenders?",
      answer: "Lenders evaluate your credit score, debt-to-income ratio, employment history, loan amount, and repayment term duration when determining your interest rate."
    }
  ],

  debt_payoff_calculator: [
    {
      question: "What is the difference between the Debt Avalanche and Debt Snowball methods?",
      answer: "The Debt Avalanche method prioritizes paying off debts with the highest interest rate first to minimize interest cost. The Debt Snowball method focuses on smallest balances first to build psychological momentum."
    },
    {
      question: "Why does paying only minimum credit card balances take so long?",
      answer: "Minimum credit card payments mostly cover accruing monthly interest and only a small fraction of principal balance, causing debt to persist for years."
    },
    {
      question: "How can I lower my high credit card interest rates?",
      answer: "You can call your card issuer to request an APR reduction, transfer balances to a 0% APR card, or consolidate debt with a lower-interest personal loan."
    },
    {
      question: "Does debt consolidation hurt my credit score?",
      answer: "Consolidating debt may cause a temporary minor dip due to a hard credit inquiry, but making on-time payments and reducing credit utilization will boost your score long-term."
    },
    {
      question: "Should I pay off debt before investing?",
      answer: "High-interest debt (e.g. above 7%–8%) should generally be prioritized over investing, while low-interest fixed debt can often be paid alongside regular long-term investing."
    }
  ],

  fifty_thirty_twenty_calculator: [
    {
      question: "What is the 50/30/20 budgeting rule?",
      answer: "The 50/30/20 budget allocates 50% of your net income to Needs (housing, utilities, food), 30% to Wants (dining out, entertainment), and 20% to Savings & Debt Repayment."
    },
    {
      question: "Should I use gross income or net take-home pay for this budget?",
      answer: "Always use net take-home pay (your actual paycheck after tax withholdings and deductions) when applying the 50/30/20 budget guidelines."
    },
    {
      question: "What if my essential Needs exceed 50% of my income?",
      answer: "If housing or essential expenses push Needs above 50%, temporarily reduce your Wants allocation while keeping your savings target as close to 20% as possible."
    },
    {
      question: "Are minimum debt payments considered Needs or Savings?",
      answer: "Minimum required debt payments (like mortgage or student loan minimums) count as Needs, while extra principal payoff or retirement contributions count as Savings."
    },
    {
      question: "How often should I review my 50/30/20 budget breakdown?",
      answer: "Review your budget monthly or whenever income, fixed expenses, or life circumstances undergo major changes."
    }
  ],

  apr_calculator: [
    {
      question: "Why is the calculated APR higher than the nominal interest rate?",
      answer: "APR incorporates upfront loan fees, points, and closing costs spread over the duration of the loan, representing the true cost of borrowing."
    },
    {
      question: "How do upfront fees impact short-term vs long-term loans?",
      answer: "Upfront fees increase effective APR more sharply on short-term loans because the fee cost is distributed over fewer payment months."
    },
    {
      question: "What fees are typically included in an APR calculation?",
      answer: "APR generally includes origination fees, loan processing fees, points, and broker fees associated with obtaining the loan."
    },
    {
      question: "Can two loans with the same interest rate have different APRs?",
      answer: "Yes! If two loans have identical interest rates but different upfront closing fees, the loan with higher fees will have a higher APR."
    },
    {
      question: "Is APR the best metric for comparing loan offers?",
      answer: "Yes, APR is one of the most reliable standardized metrics because it combines both interest rates and mandatory loan fees into a single percentage."
    }
  ],

  stock_profit_calculator: [
    {
      question: "How are stock net profits calculated?",
      answer: "Net profit is calculated as (Selling Price − Buying Price) × Number of Shares, minus trading commissions and brokerage transaction fees."
    },
    {
      question: "How do transaction fees affect investment ROI?",
      answer: "Transaction commissions lower your return on investment (ROI). Trading larger position sizes or using fee-free brokerages mitigates fixed fee impact."
    },
    {
      question: "What is Return on Investment (ROI) in stock trading?",
      answer: "Stock ROI measures the percentage gain or loss relative to the total cost of buying the stock, including fees and commissions."
    },
    {
      question: "Does this calculator factor in capital gains taxes?",
      answer: "Basic net profit calculations exclude capital gains taxes, which depend on your tax bracket and whether the holding period was short-term or long-term."
    },
    {
      question: "What is the difference between realized and unrealized profit?",
      answer: "Realized profit occurs after you actually sell the stock position. Unrealized profit is paper gain on shares you currently hold."
    }
  ],

  dividend_yield_calculator: [
    {
      question: "How is annual dividend yield calculated?",
      answer: "Dividend Yield is calculated as (Annual Dividend Per Share ÷ Current Stock Price) × 100."
    },
    {
      question: "What is a healthy dividend yield range?",
      answer: "A healthy dividend yield generally falls between 2% and 5%. Extremely high yields (above 8%) may signal financial distress or unsustainable payout ratios."
    },
    {
      question: "What is dividend payout ratio?",
      answer: "The payout ratio measures the percentage of company net earnings paid out as dividends. Lower payout ratios suggest higher dividend safety."
    },
    {
      question: "How does dividend reinvestment (DRIP) accelerate portfolio growth?",
      answer: "Automatically reinvesting dividends buys additional company shares, compounding future dividend payouts exponentially over time."
    },
    {
      question: "How often do companies typically pay dividends?",
      answer: "Most dividend-paying companies pay quarterly, though some offer monthly or annual distribution schedules."
    }
  ],

  inflation_calculator: [
    {
      question: "How does inflation erode cash purchasing power?",
      answer: "Inflation increases the price level of goods and services over time, meaning a fixed sum of cash buys fewer goods in future years."
    },
    {
      question: "How can I protect my savings against inflation?",
      answer: "Holding yielding assets such as equities, broad index funds, real estate, or high-yield savings accounts helps wealth keep pace with inflation."
    },
    {
      question: "What is the CPI (Consumer Price Index)?",
      answer: "CPI is the benchmark economic metric tracking price changes for a basket of consumer goods and services over time to measure inflation."
    },
    {
      question: "What is the historic average inflation rate?",
      answer: "In developed economies like the United States, average long-term inflation historically averages around 2% to 3% annually."
    },
    {
      question: "What is real purchasing power?",
      answer: "Real purchasing power represents financial value adjusted for inflation, revealing what your money can actually buy relative to past years."
    }
  ],

  emergency_fund_calculator: [
    {
      question: "How many months of expenses should be in an emergency fund?",
      answer: "Financial advisors recommend keeping 3 to 6 months of essential living expenses in a liquid savings account to cushion against unexpected events."
    },
    {
      question: "Where should I keep my emergency fund?",
      answer: "Keep your emergency fund in a penalty-free, FDIC-insured High-Yield Savings Account (HYSA) so it earns interest while remaining liquid."
    },
    {
      question: "What expenses qualify as emergencies?",
      answer: "Valid emergencies include unexpected medical costs, urgent home or car repairs, or temporary job loss. Non-essential purchases do not qualify."
    },
    {
      question: "Should I invest my emergency fund in stocks?",
      answer: "No. Emergency funds should avoid stock market volatility so the full funds remain guaranteed and immediately accessible when needed."
    },
    {
      question: "How do I rebuild my emergency fund after using it?",
      answer: "Pause non-essential spending and redirect extra monthly income into your emergency savings account until the baseline balance is fully restored."
    }
  ],

  bmi_calculator: [
    {
      question: "What is Body Mass Index (BMI) and how is it categorized?",
      answer: "BMI is a height-to-weight ratio used to classify adult body weight into standard categories: Underweight (<18.5), Normal (18.5–24.9), Overweight (25–29.9), and Obese (30+)."
    },
    {
      question: "Does BMI measure muscle vs body fat percentage?",
      answer: "No. BMI does not differentiate between lean muscle and fat tissue. Muscular individuals may register a high BMI despite low body fat."
    },
    {
      question: "Is BMI accurate for older adults and seniors?",
      answer: "For older adults, slightly higher BMI ranges may sometimes be acceptable due to age-related shifts in muscle and bone density."
    },
    {
      question: "How is child or teenage BMI measured?",
      answer: "Child and teenage BMI uses age and gender percentiles rather than fixed adult BMI cutoffs."
    },
    {
      question: "What other health metrics complement BMI?",
      answer: "Waist-to-hip ratio, body fat percentage, and blood pressure provide a more comprehensive overview of overall cardiovascular health."
    }
  ],

  bmr_calculator: [
    {
      question: "What is Basal Metabolic Rate (BMR)?",
      answer: "BMR is the baseline number of calories your body burns at complete rest over 24 hours to keep vital organ functions operating."
    },
    {
      question: "How can I increase my daily BMR?",
      answer: "Increasing lean muscle tissue through strength training boosts BMR, because muscle consumes more resting energy than fat tissue."
    },
    {
      question: "What is the difference between BMR and TDEE?",
      answer: "BMR covers baseline calories burned at rest, while TDEE (Total Daily Energy Expenditure) includes calories burned through daily movement and exercise."
    },
    {
      question: "Why does BMR decrease with age?",
      answer: "Metabolic rates naturally slow with age due to gradual loss of muscle mass and hormonal changes, which can be counteracted with exercise."
    },
    {
      question: "Should I eat fewer calories than my BMR to lose weight?",
      answer: "Eating below your BMR is generally not recommended as it can cause metabolic slowdown and nutritional deficiencies."
    }
  ],

  calories_burned_calculator: [
    {
      question: "How does body weight affect workout calorie burn?",
      answer: "Moving heavier body mass requires more metabolic energy, so heavier individuals burn more calories performing the same activity."
    },
    {
      question: "What are MET values in exercise science?",
      answer: "MET (Metabolic Equivalent of Task) quantifies the energy cost of physical activities relative to quiet resting baseline."
    },
    {
      question: "Does cardio or weightlifting burn more calories?",
      answer: "High-intensity cardio burns more calories during the workout session, while weightlifting builds muscle that elevates long-term resting metabolism."
    },
    {
      question: "How accurate are calorie burn estimations?",
      answer: "Calculations provide reliable estimates based on average MET data, though individual genetics and fitness levels cause minor variance."
    },
    {
      question: "What is the afterburn effect (EPOC)?",
      answer: "EPOC (Excess Post-exercise Oxygen Consumption) refers to extra calories burned while your body recovers after intense workouts."
    }
  ],

  ideal_weight_calculator: [
    {
      question: "How is ideal body weight determined?",
      answer: "Ideal body weight formulas (such as Robinson and Devine) estimate healthy weight ranges based on height and biological gender."
    },
    {
      question: "Why do ideal weight formulas differ slightly?",
      answer: "Different medical researchers developed formulas using distinct populations and body frame baseline assumptions over time."
    },
    {
      question: "Should body frame size be factored into ideal weight?",
      answer: "Yes, individuals with small or large bone structures naturally fit comfortably near the lower or upper end of the healthy range."
    },
    {
      question: "Is ideal body weight a strict health rule?",
      answer: "No, ideal body weight serves as a general guide. Overall health depends more on body composition, physical fitness, and blood metrics."
    },
    {
      question: "How does gender affect ideal body weight calculations?",
      answer: "Men generally have higher bone density and lean muscle mass averages, resulting in higher estimated ideal weight baselines for the same height."
    }
  ],

  water_intake_calculator: [
    {
      question: "How much water should I drink each day?",
      answer: "A standard guideline is 2.5 to 3.5 Liters per day for adults, adjusting upward for intense exercise and warm weather."
    },
    {
      question: "Do coffee and tea count toward daily fluid intake?",
      answer: "Yes, caffeinated beverages contribute to daily hydration, though plain water remains the primary recommended source."
    },
    {
      question: "What are signs of mild dehydration?",
      answer: "Common signs of dehydration include dark urine, dry mouth, headache, fatigue, and reduced athletic performance."
    },
    {
      question: "How does exercise increase water requirements?",
      answer: "Physical activity causes sweat loss. Replenishing 0.5 to 1 Liter per hour of strenuous workout is recommended."
    },
    {
      question: "Is it possible to drink too much water?",
      answer: "Drinking extreme excess water in short periods can dilute blood sodium (hyponatremia), though it is rare under normal circumstances."
    }
  ],

  body_fat_calculator: [
    {
      question: "What is a healthy body fat percentage?",
      answer: "Healthy body fat levels range from 14%–20% for fit men and 21%–28% for fit women. Essential fat required for health is 2%–5% for men and 10%–13% for women."
    },
    {
      question: "How does body fat percentage differ from BMI?",
      answer: "Body fat percentage directly measures fat mass relative to total weight, whereas BMI only evaluates total weight relative to height."
    },
    {
      question: "Which measurement method is used by this calculator?",
      answer: "This calculator utilizes US Navy circumference formulas using waist, neck, and hip measurements to estimate body fat with high accuracy."
    },
    {
      question: "How can I accurately lower my body fat percentage?",
      answer: "Combine a modest calorie deficit with high-protein nutrition and resistance training to lose fat while preserving muscle mass."
    },
    {
      question: "Why do women naturally carry higher body fat percentages?",
      answer: "Women naturally carry essential biological body fat for reproductive health, hormonal regulation, and tissue protection."
    }
  ],

  age_calculator: [
    {
      question: "Does the age calculator account for leap years?",
      answer: "Yes, exact calendar age calculation factors in 366-day leap years to determine precise age down to years, months, and days."
    },
    {
      question: "How are total days and hours calculated?",
      answer: "Total elapsed time is computed by calculating the exact date difference against calendar month lengths and standard daily hours."
    },
    {
      question: "Can I calculate my age on a future specific date?",
      answer: "Yes! Simply select your target future date to see exactly how old you will be in years, months, and days on that day."
    },
    {
      question: "What is the day of the week feature?",
      answer: "The calculator reveals the exact day of the week (e.g., Monday, Sunday) on which you were born or any target date falls."
    },
    {
      question: "How are leap second adjustments handled?",
      answer: "Calendar date math uses standard Gregorian calendar rules, which cover leap year variations accurately for everyday use."
    }
  ],

  date_calculator: [
    {
      question: "How are total days calculated between dates?",
      answer: "Date difference computation uses Gregorian calendar math, accounting for varying month lengths and leap years to report exact elapsed days."
    },
    {
      question: "Does the calculation include or exclude the end date?",
      answer: "By default, date difference computes elapsed days between start and end. You can count both inclusive or exclusive depending on preference."
    },
    {
      question: "Can I add or subtract days from a start date?",
      answer: "Yes! You can specify a starting date and add or subtract a number of business or calendar days to determine the exact resulting date."
    },
    {
      question: "How do business day calculations work?",
      answer: "Business day options filter out weekends (Saturdays and Sundays) to count only official working days between two dates."
    },
    {
      question: "Is this calculator suitable for project deadline planning?",
      answer: "Yes, it is ideal for computing project milestones, lease durations, contract terms, and event countdowns."
    }
  ],

  basic_calculator: [
    {
      question: "Which operations are supported on this calculator?",
      answer: "The calculator supports arithmetic (+, −, ×, ÷), trigonometric functions (sin, cos, tan), logarithms, exponents, square roots, and percentages."
    },
    {
      question: "Does the calculator follow order of operations (PEMDAS)?",
      answer: "Yes, math expressions strictly observe standard mathematical order of operations (Parentheses, Exponents, Multiplication, Division, Addition, Subtraction)."
    },
    {
      question: "How can I copy calculation results to clipboard?",
      answer: "Click on the result display screen or use the copy button to instant copy numbers directly to your clipboard."
    },
    {
      question: "Does the calculator store calculation history?",
      answer: "Yes, recent calculations are saved in local history so you can review previous steps or reuse previous results."
    },
    {
      question: "Can I use keyboard shortcuts for fast input?",
      answer: "Yes, standard physical keyboard keys (0-9, +, -, *, /, Enter, Escape, Backspace) work seamlessly for quick input."
    }
  ],

  interest_calculator: [
    {
      question: "How does compounding frequency impact overall interest?",
      answer: "More frequent compounding intervals (daily or monthly versus annually) yield higher final balances because interest earns returns sooner."
    },
    {
      question: "What is the difference between simple interest and compound interest?",
      answer: "Simple interest pays returns strictly on the principal balance. Compound interest reinvests earned interest back into the generating balance."
    },
    {
      question: "What is nominal interest rate vs effective annual rate (EAR)?",
      answer: "Nominal interest rate is the stated annual percentage, while EAR accounts for intra-year compounding to reveal actual annual yield."
    },
    {
      question: "How does compounding work on savings accounts?",
      answer: "Most banks calculate interest daily on your balance and credit it monthly, compounding your growth continuously."
    },
    {
      question: "What is the Rule of 72 in interest calculations?",
      answer: "The Rule of 72 estimates how many years it takes to double your money by dividing 72 by the annual interest rate percentage."
    }
  ],

  loss_tracker: [
    {
      question: "How do small daily expenses accumulate over a full year?",
      answer: "Small daily expenses compound rapidly. For instance, a $10 daily expenditure amounts to $3,650 per year in uninvested capital."
    },
    {
      question: "Why is tracking minor recurring costs so important?",
      answer: "Minor subscription fees or habitual spending often go unnoticed but represent significant lost opportunity for wealth accumulation."
    },
    {
      question: "How does opportunity cost relate to financial losses?",
      answer: "Opportunity cost measures the interest or investment gains you could have earned if money lost or wasted was invested instead."
    },
    {
      question: "How can I reduce daily expense leaks?",
      answer: "Audit bank statements monthly, cancel unused subscriptions, cook meals at home, and automate savings transfers on payday."
    },
    {
      question: "How does inflation affect uninvested cash loss?",
      answer: "Uninvested cash loses purchasing power every year due to inflation, making active expense management and investing essential."
    }
  ]
};

// Helper to get or generate 5 FAQs for any tool
export function getFaqsForTool(tool: CalculatorTool): FaqItem[] {
  if (tool.id && PREDEFINED_FAQS[tool.id]) {
    return PREDEFINED_FAQS[tool.id];
  }

  // Fallback / dynamic generator for custom AI-generated tools (always 5 FAQs)
  const title = tool.title || "Calculator";
  return [
    {
      question: `How does the ${title} compute results?`,
      answer: `The ${title} processes inputs provided in real-time to compute accuracy according to standard mathematical formulas (${tool.formula || "formula"}).`
    },
    {
      question: `How can I customize or adjust the inputs for ${title}?`,
      answer: `You can drag slider controls or manually type custom values directly into input boxes to update calculations instantly.`
    },
    {
      question: `Can I download or share my ${title} calculations?`,
      answer: `Yes! Click the Share button to copy a direct shareable link or click the PDF button to download a complete printable analytical report.`
    },
    {
      question: `Is data entered in the ${title} stored securely?`,
      answer: `All calculations run directly in your browser or secure server session, ensuring private and accurate computations without exposing sensitive data.`
    },
    {
      question: `Can I use this ${title} on mobile devices?`,
      answer: `Yes, the ${title} is fully responsive and optimized for phones, tablets, and desktop displays.`
    }
  ];
}
