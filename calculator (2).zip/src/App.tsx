import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, 
  HelpCircle, 
  Sparkles, 
  RotateCcw, 
  TrendingUp, 
  ArrowRight,
  Sun,
  Moon,
  Info,
  Command,
  ArrowUpRight,
  BarChart2,
  Check,
  Share2,
  Download,
  Upload,
  Globe,
  Sliders,
  ChevronDown,
  Coins,
  Bell
} from "lucide-react";
import { DICT_EN, DICT_TR, DICT_ES, DICT_DE, DICT_FR, DICT_IT, CALC_LOCALE_MAP_ALL } from "./data/translations";
import { jsPDF } from "jspdf";
import { CalculatorTool } from "./types";
import { calculateFormula, generateProjections, formatValue, generateAmortizationSchedule, calculateInterestEarnings, getMathResultDetails } from "./utils";
import CustomChart from "./components/CustomChart";
import GhostPreviews from "./components/GhostPreviews";
import PaymentScheduleSection from "./components/PaymentScheduleSection";
import FaqSection from "./components/FaqSection";
import DataInputCard from "./components/DataInputCard";
import { findMatchingPredefinedCalculator, PREDEFINED_CALCULATORS } from "./data/predefinedCalcs";
import { 
  decodeCalculatorFromUrl, 
  encodeCalculatorToUrl, 
  saveSharedCalculator, 
  getSharedCalculator 
} from "./firebase";

// Selection suggest chips for quick onboarding
const SUGGESTIONS_ALL: Record<string, string[]> = {
  en: [
    "Subscribe for weekly financial alerts",
    "Get notified about new calculator updates",
    "Receive instant report summaries via email",
    "Join priority newsletter access",
    "Get custom market data insights"
  ],
  tr: [
    "Haftalık finans uyarıları için abone ol",
    "Yeni hesap makinesi güncellemelerinden haberdar ol",
    "E-posta ile anında rapor özeti al",
    "Öncelikli bülten erişimine katıl",
    "Özel piyasa verisi öngörüleri al"
  ],
  es: [
    "Suscribirse a alertas financieras semanales",
    "Recibir notificaciones de nuevas actualizaciones",
    "Recibir resúmenes de informes por correo",
    "Unirse al acceso prioritario del boletín",
    "Obtener perspectivas de mercado personalizadas"
  ],
  de: [
    "Für wöchentliche Finanzwarnungen abonnieren",
    "Über Rechner-Updates benachrichtigt werden",
    "Berichte per E-Mail erhalten",
    "Dem Newsletter-Prioritätszugriff beitreten",
    "Maßgeschneiderte Markteinblicke erhalten"
  ],
  fr: [
    "S'abonner aux alertes financières hebdomadaires",
    "Être notifié des mises à jour de calculateurs",
    "Recevoir des résumés par e-mail",
    "Rejoindre l'accès prioritaire à la newsletter",
    "Obtenir des aperçus de marché personnalisés"
  ],
  it: [
    "Iscriviti agli avvisi finanziari settimanali",
    "Ricevi notifiche sui nuovi aggiornamenti",
    "Ricevi riepiloghi via email",
    "Unisciti all'accesso prioritario alla newsletter",
    "Ottieni approfondimenti di mercato personalizzati"
  ]
};

export default function App() {
  const [query, setQuery] = useState("");
  const [confirmedQuery, setConfirmedQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTool, setActiveTool] = useState<CalculatorTool | null>(null);

  // Custom states for Mortgage start date calculation specs
  const [mortgageStartMonth, setMortgageStartMonth] = useState(6); // June
  const [mortgageStartYear, setMortgageStartYear] = useState(2026);
  const [schedulePeriodType, setSchedulePeriodType] = useState<"yearly" | "monthly">("yearly");

  const [copied, setCopied] = useState(false);

  // Check for shared calculators in URL parameter or pathname on mount
  useEffect(() => {
    const checkShares = async () => {
      // Parse query params first
      const params = new URLSearchParams(window.location.search);
      let shareCode = params.get("c") || params.get("code") || params.get("data");
      
      // If none found in params, parse from pathname
      if (!shareCode) {
        const pathParts = window.location.pathname.split("/");
        if (pathParts.length >= 3 && pathParts[1] === "c") {
          shareCode = pathParts[2];
        }
      }

      if (shareCode) {
        setIsLoading(true);
        try {
          // Attempt 1: check as base64 encoded direct payload
          let decodedTool = decodeCalculatorFromUrl(shareCode);
          if (decodedTool && decodedTool.title && decodedTool.formula) {
            setSanitizedActiveTool(decodedTool);
            setHasInteracted(true);
            setIsLoading(false);
            return;
          }

          // Attempt 2: treat as short code from Firestore/localStorage
          const fetchedTool = await getSharedCalculator(shareCode);
          if (fetchedTool && fetchedTool.title && fetchedTool.formula) {
            setSanitizedActiveTool(fetchedTool);
            setHasInteracted(true);
          }
        } catch (err) {
          console.error("Failed to load shared calculator:", err);
        } finally {
          setIsLoading(false);
        }
        return;
      }

      // If no share code, check if pathname corresponds to a predefined calculator ID (converting - to _)
      const rawPath = window.location.pathname.replace(/^\//, "").trim();
      const pathId = rawPath.replace(/-/g, "_");
      
      if (pathId) {
        const matchingCalc = PREDEFINED_CALCULATORS.find(c => c.id === pathId);
        if (matchingCalc) {
          setSanitizedActiveTool(matchingCalc);
          setHasInteracted(true);
        }
      }
    };
    checkShares();
  }, []);

  // Listen to popstate to handle browser Back / Forward buttons cleanly
  useEffect(() => {
    const handlePopState = () => {
      const rawPath = window.location.pathname.replace(/^\//, "").trim();
      const pathId = rawPath.replace(/-/g, "_");
      
      if (pathId) {
        const matchingCalc = PREDEFINED_CALCULATORS.find(c => c.id === pathId);
        if (matchingCalc) {
          setSanitizedActiveTool(matchingCalc);
          setHasInteracted(true);
        } else {
          setSanitizedActiveTool(null);
          setHasInteracted(false);
        }
      } else {
        setSanitizedActiveTool(null);
        setHasInteracted(false);
      }
    };

    window.addEventListener("popstate", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, []);

  // Sync state with browser URL path beautifully
  useEffect(() => {
    if (activeTool) {
      const isPredefined = PREDEFINED_CALCULATORS.some((c) => c.id === activeTool.id);
      if (isPredefined) {
        const pathSegment = activeTool.id.replace(/_/g, "-");
        if (window.location.pathname !== `/${pathSegment}`) {
          window.history.pushState(null, "", `/${pathSegment}`);
        }
      } else {
        if (window.location.pathname !== "/custom") {
          window.history.pushState(null, "", "/custom");
        }
      }
    } else {
      if (window.location.pathname !== "/") {
        window.history.pushState(null, "", "/");
      }
    }
  }, [activeTool]);

  const handleShareClick = async () => {
    if (!activeTool) return;
    setCopied(false);
    
    try {
      // Save shared calculator and fetch its 6-character shortcode
      const shortCode = await saveSharedCalculator(activeTool);
      const fullUrl = window.location.origin + window.location.pathname + `?c=${shortCode}`;
      
      await navigator.clipboard.writeText(fullUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to share", err);
      try {
        const base64 = encodeCalculatorToUrl(activeTool);
        const fallbackUrl = window.location.origin + window.location.pathname + `?c=${base64}`;
        await navigator.clipboard.writeText(fallbackUrl);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (clipErr) {
        // Fallback if writing fails
      }
    }
  };

  const handleDownloadPdf = async () => {
    if (!activeTool) return;

    try {
      const doc = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4"
      });

      let hasInter = false;

      // Try to load custom Inter Medium font dynamically on download
      try {
        const fontRes = await fetch("https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuI6fMZg.ttf");
        if (fontRes.ok) {
          const arrayBuffer = await fontRes.arrayBuffer();
          if (arrayBuffer) {
            const bytes = new Uint8Array(arrayBuffer);
            let binary = '';
            for (let i = 0; i < bytes.byteLength; i++) {
              binary += String.fromCharCode(bytes[i]);
            }
            const base64Font = btoa(binary);
            doc.addFileToVFS("Inter-Medium.ttf", base64Font);
            doc.addFont("Inter-Medium.ttf", "Inter", "normal");
            hasInter = true;
            console.log("Premium Inter font loaded successfully.");
          }
        }
      } catch (fontErr) {
        console.warn("Google Font Inter failed to load, falling back gracefully to system sans-serif:", fontErr);
      }

      const mainFont = hasInter ? "Inter" : "Helvetica";

      // Cover bar aesthetics
      doc.setFillColor(16, 185, 129); // Emerald-500
      doc.rect(0, 0, 210, 6, "F");

      // Title Section
      doc.setFont(mainFont, "bold");
      doc.setFontSize(20);
      doc.setTextColor(15, 23, 42); // slate-900
      const titleText = activeTool.title || "Calculator Report";
      doc.text(titleText, 15, 22);

      // Divider line
      doc.setDrawColor(226, 232, 240); // slate-200
      doc.setLineWidth(0.4);
      doc.line(15, 26, 195, 26);

      // Description text
      doc.setFont(mainFont, "normal");
      doc.setFontSize(10);
      doc.setTextColor(100, 116, 139); // slate-500
      const descriptionText = activeTool.description || "";
      const splitDesc = doc.splitTextToSize(descriptionText, 180);
      doc.text(splitDesc, 15, 32);

      let currentY = 32 + (splitDesc.length * 5) + 8;

      // Inputs section
      doc.setFont(mainFont, "bold");
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text("INPUT PARAMETERS", 15, currentY);
      
      doc.setDrawColor(203, 213, 225); // slate-300
      doc.setLineWidth(0.3);
      doc.line(15, currentY + 2, 195, currentY + 2);
      
      currentY += 8;
      doc.setFont(mainFont, "normal");
      doc.setFontSize(10);

      activeTool.inputs.forEach((input) => {
        const rawVal = inputsState[input.id] ?? input.default;
        const formattedVal = formatValue(rawVal, input.prefix || "", input.suffix || "");

        // Emerald bullet
        doc.setFillColor(16, 185, 129);
        doc.rect(15, currentY - 3, 1.8, 1.8, "F");

        doc.setFont(mainFont, "bold");
        doc.setTextColor(51, 65, 85); // slate-700
        doc.text(input.label, 20, currentY);

        doc.setFont(mainFont, "normal");
        doc.setTextColor(15, 23, 42);
        // Beautifully aligned at x=145 to prevent overlapping with long labels 
        doc.text(`:  ${formattedVal}`, 145, currentY);

        currentY += 7.5;
        if (currentY > 275) {
          doc.addPage();
          currentY = 20;
        }
      });

      // Result Section
      currentY += 4;
      if (currentY > 250) {
        doc.addPage();
        currentY = 20;
      }

      doc.setFont(mainFont, "bold");
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text("COMPUTED OUTCOME", 15, currentY);

      doc.setDrawColor(16, 185, 129); // emerald-500
      doc.setLineWidth(0.5);
      doc.line(15, currentY + 2, 195, currentY + 2);

      currentY += 8;

      // Beautiful custom left-bordered Highlight Card
      doc.setFillColor(248, 250, 252); // slate-50
      doc.rect(15, currentY, 180, 24, "F");
      
      doc.setFillColor(16, 185, 129); // Solid emerald-500 left indicator banner
      doc.rect(15, currentY, 1.8, 24, "F");

      doc.setDrawColor(226, 232, 240); // slate-200
      doc.setLineWidth(0.35);
      doc.rect(15, currentY, 180, 24, "D");

      doc.setFont(mainFont, "bold");
      doc.setFontSize(8.5);
      doc.setTextColor(100, 116, 139); // slate-505
      const outputLabel = (activeTool.output_label || "Calculated Outcome").toUpperCase();
      doc.text(outputLabel, 22, currentY + 7);

      const finalOutputText = activeTool.tool_type === "date_difference"
        ? getExactTimeDifferenceText(
            inputsState["start_day"] ?? 15,
            inputsState["start_month"] ?? 6,
            inputsState["start_year"] ?? 1994
          )
        : formatValue(calculatedOutput, activeTool.output_prefix || "", activeTool.output_suffix || "");

      doc.setFont(mainFont, "bold");
      doc.setFontSize(14);
      doc.setTextColor(16, 185, 129); // emerald-500
      doc.text(finalOutputText, 22, currentY + 16);

      currentY += 28; // Advance Y below results box gracefully

      // Draw interactive visual chart inside PDF if available
      if (projectionsData && projectionsData.length > 0 && activeTool.chart_type !== "none") {
        if (currentY + 68 > 275) {
          doc.addPage();
          currentY = 20;
        }

        doc.setFont(mainFont, "bold");
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text("VISUAL PROJECTIONS CHART", 15, currentY);

        doc.setDrawColor(16, 185, 129);
        doc.setLineWidth(0.3);
        doc.line(15, currentY + 2, 195, currentY + 2);

        currentY += 6;

        // Chart dimension config
        const chartLeft = 32;
        const chartRight = 190;
        const chartTop = currentY + 5;
        const chartHeight = 35;
        const chartBottom = chartTop + chartHeight;
        const chartWidth = chartRight - chartLeft;

        // Background card outline
        doc.setFillColor(252, 253, 254);
        doc.setDrawColor(241, 245, 249);
        doc.setLineWidth(0.3);
        doc.rect(15, currentY + 2, 180, 52, "FD");

        // Compute Y-scale mapping
        const allVals = projectionsData.flatMap(d => [d.value, d.secondaryValue ?? d.value]);
        const maxVal = Math.max(...allVals, 1) * 1.15; // 15% padding at top
        const minVal = 0;
        const valRange = maxVal - minVal;

        const getYCoord = (val: number) => {
          const ratio = (val - minVal) / valRange;
          return chartBottom - (ratio * chartHeight);
        };

        const getXCoord = (index: number, total: number) => {
          if (total <= 1) return chartLeft + chartWidth / 2;
          return chartLeft + (index / (total - 1)) * chartWidth;
        };

        // Draw 4 Horizontal Grid Lines & Y labels only for standard scale charts (not distribution)
        if (activeTool.chart_type !== "distribution") {
          doc.setFont(mainFont, "normal");
          doc.setFontSize(7);
          doc.setTextColor(148, 163, 184); // slate-400
          
          for (let i = 0; i <= 4; i++) {
            const gridVal = minVal + (valRange * (i / 4));
            const gridY = getYCoord(gridVal);
            
            doc.setDrawColor(241, 245, 249);
            doc.setLineWidth(0.25);
            doc.line(chartLeft, gridY, chartRight, gridY);

            // Format value string
            const labelValStr = formatValue(gridVal, activeTool.output_prefix || "", activeTool.output_suffix || "");
            const truncatedLabelVal = labelValStr.length > 10 ? labelValStr.substring(0, 8) + ".." : labelValStr;
            doc.text(truncatedLabelVal, chartLeft - 2, gridY + 1, { align: "right" });
          }
        }

        const isDistribution = activeTool.chart_type === "distribution";
        const isBarChart = activeTool.chart_type === "bar";

        if (isDistribution) {
          // Draw a magnificent horizontal distribution stacked segment bar
          const stripY = chartTop + 6;
          const stripH = 10;
          const stripLeft = chartLeft;
          const stripWidth = chartWidth;

          let currentX = stripLeft;
          const totalValSum = projectionsData.reduce((acc, d) => acc + d.value, 0) || 1;
          const colorsList = ["#10B981", "#34D399", "#059669", "#6EE7B7", "#A7F3D0"];

          projectionsData.forEach((point, idx) => {
            const percentage = (point.value / totalValSum);
            if (percentage <= 0) return;

            const segmentW = percentage * stripWidth;
            const sliceColorHex = colorsList[idx % colorsList.length];

            // Draw clean segment
            const r = parseInt(sliceColorHex.slice(1, 3), 16);
            const g = parseInt(sliceColorHex.slice(3, 5), 16);
            const b = parseInt(sliceColorHex.slice(5, 7), 16);

            doc.setFillColor(r, g, b);
            doc.rect(currentX, stripY, segmentW, stripH, "F");

            // Segment boundary divider line
            doc.setDrawColor(255, 255, 255);
            doc.setLineWidth(0.4);
            doc.line(currentX, stripY, currentX, stripY + stripH);

            currentX += segmentW;
          });

          // Draw legend items below the strip inside the background block
          let legendY = stripY + stripH + 8;
          projectionsData.forEach((point, idx) => {
            const percentage = (point.value / totalValSum) * 100;
            const sliceColorHex = colorsList[idx % colorsList.length];
            const r = parseInt(sliceColorHex.slice(1, 3), 16);
            const g = parseInt(sliceColorHex.slice(3, 5), 16);
            const b = parseInt(sliceColorHex.slice(5, 7), 16);

            // Color indicator block
            doc.setFillColor(r, g, b);
            doc.rect(chartLeft, legendY - 2.5, 3, 3, "F");

            // Option details label
            doc.setFont(mainFont, "bold");
            doc.setFontSize(8);
            doc.setTextColor(51, 65, 85);
            doc.text(`${point.label}`, chartLeft + 6, legendY);

            // Portion value detail
            doc.setFont(mainFont, "normal");
            doc.setFontSize(8);
            doc.setTextColor(100, 116, 139);
            const formattedVal = formatValue(point.value, activeTool.output_prefix || "", activeTool.output_suffix || "");
            doc.text(`:  ${formattedVal} (${percentage.toFixed(0)}%)`, chartLeft + 64, legendY);

            legendY += 6;
          });
        } else if (isBarChart) {
          // Draw Native Vector Bars
          const totalPoints = projectionsData.length;
          const totalGroupsWidth = chartWidth / totalPoints;
          const barSpacingRatio = 0.35; // 35% empty space
          const barWidth = totalGroupsWidth * (1 - barSpacingRatio);

          projectionsData.forEach((point, idx) => {
            const xCenter = chartLeft + (idx * totalGroupsWidth) + (totalGroupsWidth * barSpacingRatio / 2);
            
            // Primary value bar
            const yVal = getYCoord(point.value);
            const barH = chartBottom - yVal;
            
            if (point.secondaryValue !== undefined) {
              // Stacked/Split or double bars
              const halfBarW = barWidth / 2 - 0.5;
              
              // Bar 1 (Primary: Emerald)
              doc.setFillColor(16, 185, 129); // emerald
              doc.rect(xCenter, yVal, halfBarW, barH, "F");

              // Bar 2 (Secondary: Slate)
              const yVal2 = getYCoord(point.secondaryValue);
              const barH2 = chartBottom - yVal2;
              doc.setFillColor(100, 116, 139); // slate-500
              doc.rect(xCenter + halfBarW + 0.5, yVal2, halfBarW, barH2, "F");
            } else {
              // Single Bar
              doc.setFillColor(16, 185, 129); // emerald
              doc.rect(xCenter, yVal, barWidth, barH, "F");
            }

            // Draw Column label below (skip some on narrow screens if too crowded)
            if (totalPoints <= 12 || idx % Math.ceil(totalPoints / 8) === 0) {
              doc.setFont(mainFont, "normal");
              doc.setFontSize(7);
              doc.setTextColor(100, 116, 139);
              // Clean-up time indicators
              const cleanedLabel = point.label.replace("Year ", "Y").replace("Month ", "M").replace("Day ", "D");
              doc.text(cleanedLabel, xCenter + barWidth / 2, chartBottom + 4, { align: "center" });
            }
          });
        } else {
          // Draw Native Lines & Filled Area Curves
          const totalPoints = projectionsData.length;

          // Helper to draw a single line path
          const drawSeriesPath = (
            valueExtractor: (p: any) => number, 
            primaryColor: [number, number, number],
            isPrimarySeries: boolean
          ) => {
            // Draw smooth vertical alignment fills underneath
            if (isPrimarySeries) {
              for (let x = Math.ceil(chartLeft); x <= Math.floor(chartRight); x++) {
                const progress = (x - chartLeft) / chartWidth;
                const pointIndexFloat = progress * (totalPoints - 1);
                const lowerIdx = Math.floor(pointIndexFloat);
                const upperIdx = Math.min(lowerIdx + 1, totalPoints - 1);
                const weight = pointIndexFloat - lowerIdx;

                const val1 = valueExtractor(projectionsData[lowerIdx]);
                const val2 = valueExtractor(projectionsData[upperIdx]);
                const interpolatedVal = val1 * (1 - weight) + val2 * weight;
                const yVal = getYCoord(interpolatedVal);
                
                doc.setDrawColor(240, 253, 250); // Soft accent teal fill
                doc.setLineWidth(1);
                doc.line(x, yVal, x, chartBottom);
              }
            }

            // Draw thick line boundary
            doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
            doc.setLineWidth(0.8);
            for (let idx = 0; idx < totalPoints - 1; idx++) {
              const x1 = getXCoord(idx, totalPoints);
              const y1 = getYCoord(valueExtractor(projectionsData[idx]));
              const x2 = getXCoord(idx + 1, totalPoints);
              const y2 = getYCoord(valueExtractor(projectionsData[idx + 1]));
              doc.line(x1, y1, x2, y2);
            }

            // Draw interactive round marker dots
            projectionsData.forEach((point, idx) => {
              if (totalPoints <= 15 || idx % Math.ceil(totalPoints / 10) === 0 || idx === totalPoints - 1) {
                const px = getXCoord(idx, totalPoints);
                const py = getYCoord(valueExtractor(point));
                doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
                doc.circle(px, py, 0.9, "F");
              }
            });
          };

          // Draw Secondary series if present (e.g. cumulative savings or principal balance)
          const hasSecondary = projectionsData.some(d => d.secondaryValue !== undefined);
          if (hasSecondary) {
            drawSeriesPath(d => d.secondaryValue ?? 0, [100, 116, 139], false);
          }

          // Draw Primary series (Emerald)
          drawSeriesPath(d => d.value, [16, 185, 129], true);

          // Label Bottom X axis markers
          projectionsData.forEach((point, idx) => {
            if (totalPoints <= 12 || idx % Math.ceil(totalPoints / 8) === 0 || idx === totalPoints - 1) {
              const px = getXCoord(idx, totalPoints);
              doc.setFont(mainFont, "normal");
              doc.setFontSize(7);
              doc.setTextColor(100, 116, 139);
              const cleanedLabel = point.label.replace("Year ", "Y").replace("Month ", "M").replace("Day ", "D");
              doc.text(cleanedLabel, px, chartBottom + 4, { align: "center" });
            }
          });
        }

        // Draw Legend indicators if secondary series exist
        const hasSecondary = projectionsData.some(d => d.secondaryValue !== undefined);
        if (hasSecondary) {
          doc.setFont(mainFont, "bold");
          doc.setFontSize(7);
          
          // Primary label legend
          doc.setFillColor(16, 185, 129);
          doc.rect(chartLeft + 5, chartBottom + 8, 3, 2, "F");
          doc.setTextColor(51, 65, 85);
          doc.text(activeTool.output_label || "Outcome", chartLeft + 10, chartBottom + 9.8);

          // Secondary label legend
          const secondaryTitle = projectionsData.find(d => d.secondaryLabel)?.secondaryLabel || "Secondary Metric";
          doc.setFillColor(100, 116, 139);
          doc.rect(chartLeft + 80, chartBottom + 8, 3, 2, "F");
          doc.setTextColor(51, 65, 85);
          doc.text(secondaryTitle, chartLeft + 85, chartBottom + 9.8);
        }

        currentY += 62;
      }

      // Projection data table (if available) - Adam gibi, organize, kolonlu tablo taslağı
      if (projectionsData && projectionsData.length > 0) {
        if (currentY + 25 > 280) {
          doc.addPage();
          currentY = 20;
        }

        doc.setFont(mainFont, "bold");
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text("METRIC PROJECTIONS & DETAILS", 15, currentY);

        doc.setDrawColor(16, 185, 129); // Accent line
        doc.setLineWidth(0.40);
        doc.line(15, currentY + 2, 195, currentY + 2);

        currentY += 8;

        // Draw Beautiful Table Headers with columns
        const hasSec = projectionsData.some(d => d.secondaryValue !== undefined);
        doc.setFont(mainFont, "bold");
        doc.setFontSize(8);
        doc.setTextColor(100, 116, 139); // slate-500
        doc.text("PERIOD / LABEL", 18, currentY);
        
        if (hasSec) {
          doc.text("PRIMARY VALUE", 105, currentY);
          doc.text("CUMULATIVE VALUE", 145, currentY);
        } else {
          doc.text("CALCULATED VALUE", 140, currentY);
        }

        doc.setDrawColor(226, 232, 240); // slate-200
        doc.setLineWidth(0.35);
        doc.line(15, currentY + 2, 195, currentY + 2);

        currentY += 8;

        projectionsData.forEach((point) => {
          if (currentY > 275) {
            doc.addPage();
            currentY = 20;
            
            // Draw duplicate columns header on the newly added sheet
            doc.setFont(mainFont, "bold");
            doc.setFontSize(8);
            doc.setTextColor(100, 116, 139);
            doc.text("PERIOD / LABEL", 18, currentY);
            if (hasSec) {
              doc.text("PRIMARY VALUE", 105, currentY);
              doc.text("CUMULATIVE VALUE", 145, currentY);
            } else {
              doc.text("CALCULATED VALUE", 140, currentY);
            }
            doc.setDrawColor(226, 232, 240);
            doc.setLineWidth(0.35);
            doc.line(15, currentY + 2, 195, currentY + 2);
            currentY += 8;
          }

          doc.setFont(mainFont, "normal");
          doc.setFontSize(8.5);
          doc.setTextColor(51, 65, 85); // slate-700
          doc.text(point.label, 18, currentY);

          if (hasSec) {
            const formattedPrimary = formatValue(point.value, activeTool.output_prefix || "", activeTool.output_suffix || "");
            const formattedSec = formatValue(point.secondaryValue ?? 0, activeTool.output_prefix || "", activeTool.output_suffix || "");
            
            doc.setFont(mainFont, "bold");
            doc.setTextColor(15, 23, 42);
            doc.text(formattedPrimary, 105, currentY);
            doc.setFont(mainFont, "normal");
            doc.setTextColor(100, 116, 139);
            doc.text(formattedSec, 145, currentY);
          } else {
            const formattedPointVal = formatValue(point.value, activeTool.output_prefix || "", activeTool.output_suffix || "");
            doc.setFont(mainFont, "bold");
            doc.setTextColor(15, 23, 42);
            doc.text(formattedPointVal, 140, currentY);
          }

          // Row separation line
          doc.setDrawColor(241, 245, 249);
          doc.setLineWidth(0.20);
          doc.line(15, currentY + 2, 195, currentY + 2);

          currentY += 7.5;
        });
      }

      // PDF Amortization & Repayment Schedule (Yearly or Monthly intervals depending on schedulePeriodType)
      const sched = generateAmortizationSchedule(activeTool, inputsState);
      const activeRowsArr = schedulePeriodType === "yearly" ? (sched?.yearly || []) : (sched?.monthly || []);
      if (sched && activeRowsArr.length > 0) {
        if (currentY + 25 > 280) {
          doc.addPage();
          currentY = 20;
        }

        doc.setFont(mainFont, "bold");
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        const scheduleTitleText = schedulePeriodType === "yearly" 
          ? "ANNUAL PROGRESSION & AMORTIZATION" 
          : "MONTHLY PROGRESSION & AMORTIZATION";
        doc.text(scheduleTitleText, 15, currentY);

        doc.setDrawColor(16, 185, 129); // Accent line
        doc.setLineWidth(0.40);
        doc.line(15, currentY + 2, 195, currentY + 2);

        currentY += 8;

        // Draw schedule column headers
        const isLoan = ["mortgage", "debt_payoff"].includes(activeTool.tool_type);
        doc.setFont(mainFont, "bold");
        doc.setFontSize(7.5);
        doc.setTextColor(100, 116, 139); // slate-500
        
        const periodHeader = schedulePeriodType === "yearly" ? "YEAR" : "MONTH";
        doc.text(periodHeader, 18, currentY);
        doc.text("BEG. BALANCE", 40, currentY);
        doc.text(isLoan ? "PAYMENT" : "CONTRIBUTION", 75, currentY);
        doc.text(isLoan ? "INTEREST PAID" : "INTEREST EARNED", 110, currentY);
        if (isLoan) {
          doc.text("PRINCIPAL PAID", 145, currentY);
          doc.text("END. BALANCE", 175, currentY);
        } else {
          doc.text("END. BALANCE", 160, currentY);
        }

        doc.setDrawColor(226, 232, 240); // slate-200
        doc.setLineWidth(0.35);
        doc.line(15, currentY + 2, 195, currentY + 2);

        currentY += 8;

        const prefix = (activeTool.output_prefix && activeTool.output_prefix !== "$") ? activeTool.output_prefix : currency;
        const suffix = activeTool.output_suffix || "";

        activeRowsArr.forEach((row) => {
          if (currentY > 275) {
            doc.addPage();
            currentY = 20;
            
            // Draw duplicate headers on the new page
            doc.setFont(mainFont, "bold");
            doc.setFontSize(7.5);
            doc.setTextColor(100, 116, 139);
            
            doc.text(periodHeader, 18, currentY);
            doc.text("BEG. BALANCE", 40, currentY);
            doc.text(isLoan ? "PAYMENT" : "CONTRIBUTION", 75, currentY);
            doc.text(isLoan ? "INTEREST PAID" : "INTEREST EARNED", 110, currentY);
            if (isLoan) {
              doc.text("PRINCIPAL PAID", 145, currentY);
              doc.text("END. BALANCE", 175, currentY);
            } else {
              doc.text("END. BALANCE", 160, currentY);
            }

            doc.setDrawColor(226, 232, 240);
            doc.setLineWidth(0.35);
            doc.line(15, currentY + 2, 195, currentY + 2);
            currentY += 8;
          }

          doc.setFont(mainFont, "normal");
          doc.setFontSize(8);
          doc.setTextColor(51, 65, 85);

          doc.text(row.period.toString(), 18, currentY);
          doc.text(formatValue(row.beginningBalance, prefix, suffix), 40, currentY);
          doc.text(formatValue(row.payment, prefix, suffix), 75, currentY);
          doc.text(formatValue(row.interest, prefix, suffix), 110, currentY);
          if (isLoan) {
            doc.text(formatValue(row.principalPaid, prefix, suffix), 145, currentY);
            doc.text(formatValue(row.endingBalance, prefix, suffix), 175, currentY);
          } else {
            doc.text(formatValue(row.endingBalance, prefix, suffix), 160, currentY);
          }

          // Row separation line
          doc.setDrawColor(241, 245, 249);
          doc.setLineWidth(0.20);
          doc.line(15, currentY + 2, 195, currentY + 2);

          currentY += 7.5;
        });
      }

      // Add elegant Footer containing the active site extension/url watermark
      const pageCount = (doc as any).internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        
        // Horizontal footer division line
        doc.setDrawColor(241, 245, 249);
        doc.setLineWidth(0.3);
        doc.line(15, 282, 195, 282);

        // Get the actual dynamic domain of this deployment for direct site URL validation in footer
        const siteDomain = window.location.host || "wlth.studio";

        doc.setFont(mainFont, "bold");
        doc.setFontSize(8.5);
        doc.setTextColor(16, 185, 129); // emerald-500 logo style
        doc.text(`by ${siteDomain}`, 15, 287);

        doc.setFont(mainFont, "normal");
        doc.setFontSize(8);
        doc.setTextColor(148, 163, 184); // slate-400
        doc.text("Generated via Real-time Intelligent Calculation Hub. All rights reserved.", 42, 287);
        doc.text(`Page ${i} of ${pageCount}`, 180, 287);
      }

      const safeFileName = activeTool.title.toLowerCase().replace(/[^a-z0-9]+/g, "_");
      doc.save(`calculation_${safeFileName}.pdf`);
    } catch (pdfErr) {
      console.error("PDF download failed", pdfErr);
    }
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDownloadConfig = () => {
    if (!activeTool) return;
    const exportData = {
      calculator_id: activeTool.id || activeTool.tool_type,
      title: activeTool.title,
      exported_at: new Date().toISOString(),
      inputs: inputsState,
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    const safeFileName = activeTool.title.toLowerCase().replace(/[^a-z0-9]+/g, "_");
    downloadAnchor.setAttribute("download", `calc_config_${safeFileName}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportConfig = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && parsed.inputs) {
          setInputsState(prev => ({
            ...prev,
            ...parsed.inputs
          }));
        }
      } catch (err) {
        console.error("Failed to parse loaded config file:", err);
      }
    };
    reader.readAsText(file);
    // Reset file input target value so the same file selection can be triggered again if needed
    e.target.value = "";
  };

  const setSanitizedActiveTool = (tool: CalculatorTool | null) => {
    if (tool) {
      // If it is a predefined calculator, do not hijack it
      const isPredefined = PREDEFINED_CALCULATORS.some((c) => c.id === tool.id);
      if (!isPredefined) {
        const q = (tool.title || "").toLowerCase() + " " + (tool.description || "").toLowerCase() + " " + (tool.tool_type || "").toLowerCase();
        if (
          q.includes("50/30/20") ||
          q.includes("20/30/50") ||
          q.includes("50-30-20") ||
          q.includes("20-30-50") ||
          q.includes("splitter") ||
          q.includes("budget") ||
          q.includes("lifestyle")
        ) {
          const modifiedTool: CalculatorTool = {
            tool_type: "budget",
            title: "50/30/20 Smart Lifestyle Splitter",
            description: "Secure savings automatically while balancing your wants and needs",
            inputs: [
              {
                id: "income",
                label: "Monthly Net Take-Home Pay",
                type: "slider",
                default: 5000,
                prefix: "$",
                min: 0,
                max: 30000,
                step: 100
              }
            ],
            formula: "income * 0.20",
            output_label: "Target Monthly Automated Future Savings Portion (20%)",
            output_prefix: "$",
            chart_type: "bar",
            insight: "Automate financial transfers to split allocations straight from payday so you never struggle with willpower."
          };
          setActiveTool(modifiedTool);
          return;
        }
      }
    }
    setActiveTool(tool);
  };

  const [inputsState, setInputsState] = useState<Record<string, any>>({});
  const [hasInteracted, setHasInteracted] = useState(false);
  const [isWaveActive, setIsWaveActive] = useState(false);

  const [emailSubscribed, setEmailSubscribed] = useState(false);
  const [subscribedEmail, setSubscribedEmail] = useState("");
  const [emailError, setEmailError] = useState<string | null>(null);

  const handleEmailSubmit = (emailStr: string) => {
    if (!emailStr.trim() || !emailStr.includes("@") || !emailStr.includes(".")) {
      setEmailError("Please enter a valid email address / Lütfen geçerli bir e-posta adresi girin.");
      return;
    }
    setEmailError(null);
    setSubscribedEmail(emailStr);
    setEmailSubscribed(true);
    setHasInteracted(true);
    setQuery("");
    try {
      const existing = JSON.parse(localStorage.getItem("collected_emails") || "[]");
      if (!existing.includes(emailStr)) {
        existing.push(emailStr);
        localStorage.setItem("collected_emails", JSON.stringify(existing));
      }
    } catch (e) {}
  };

  // Basic Calculator Keypad State
  const [basicExpr, setBasicExpr] = useState("");
  const [basicResult, setBasicResult] = useState("");
  const [basicHistory, setBasicHistory] = useState<string[]>([]);

  // Scientific Calculator Keypad State
  const [sciExpr, setSciExpr] = useState("");
  const [sciResult, setSciResult] = useState("");
  const [sciHistory, setSciHistory] = useState<string[]>([]);
  const [sciAngleMode, setSciAngleMode] = useState<"deg" | "rad">("deg");
  const [sciInvMode, setSciInvMode] = useState(false);

  const safeEvalBasic = (expr: string): string => {
    try {
      if (!expr || expr.trim() === "") return "";
      let san = expr
        .replace(/×/g, "*")
        .replace(/÷/g, "/")
        .replace(/−/g, "-")
        .replace(/%/g, "*0.01");

      const fn = new Function(`return (${san})`);
      const val = fn();
      if (typeof val === "number" && !isNaN(val) && isFinite(val)) {
        const rounded = Number(val.toPrecision(12));
        return rounded.toString();
      }
      return "Error";
    } catch {
      return "Error";
    }
  };

  const safeEvalScientific = (expr: string, isDegMode = true): string => {
    try {
      if (!expr || expr.trim() === "") return "";
      let san = expr
        .replace(/×/g, "*")
        .replace(/÷/g, "/")
        .replace(/−/g, "-")
        .replace(/π/g, "Math.PI")
        .replace(/e(?![a-zA-Z0-9])/g, "Math.E")
        .replace(/(\d+(\.\d+)?)!/g, "fact($1)")
        .replace(/abs\(/g, "Math.abs(")
        .replace(/cbrt\(/g, "Math.cbrt(")
        .replace(/√\(/g, "Math.sqrt(")
        .replace(/sqrt\(/g, "Math.sqrt(")
        .replace(/log\(/g, "Math.log10(")
        .replace(/ln\(/g, "Math.log(")
        .replace(/\^/g, "**")
        .replace(/EXP/g, "*10**");

      if (isDegMode) {
        san = san
          .replace(/asin\(([^)]+)\)/g, "(Math.asin($1) * 180 / Math.PI)")
          .replace(/acos\(([^)]+)\)/g, "(Math.acos($1) * 180 / Math.PI)")
          .replace(/atan\(([^)]+)\)/g, "(Math.atan($1) * 180 / Math.PI)")
          .replace(/sin\(([^)]+)\)/g, "Math.sin(($1) * Math.PI / 180)")
          .replace(/cos\(([^)]+)\)/g, "Math.cos(($1) * Math.PI / 180)")
          .replace(/tan\(([^)]+)\)/g, "Math.tan(($1) * Math.PI / 180)");
      } else {
        san = san
          .replace(/asin\(/g, "Math.asin(")
          .replace(/acos\(/g, "Math.acos(")
          .replace(/atan\(/g, "Math.atan(")
          .replace(/sin\(/g, "Math.sin(")
          .replace(/cos\(/g, "Math.cos(")
          .replace(/tan\(/g, "Math.tan(");
      }

      const openCount = (san.match(/\(/g) || []).length;
      const closeCount = (san.match(/\)/g) || []).length;
      if (openCount > closeCount) {
        san += ")".repeat(openCount - closeCount);
      }

      const factFn = (n: number) => {
        if (n < 0 || !Number.isInteger(n)) return NaN;
        if (n === 0 || n === 1) return 1;
        let r = 1;
        for (let i = 2; i <= Math.min(n, 170); i++) r *= i;
        return r;
      };

      const fn = new Function("fact", `return (${san})`);
      const val = fn(factFn);
      if (typeof val === "number" && !isNaN(val) && isFinite(val)) {
        const rounded = Number(val.toPrecision(12));
        return rounded.toString();
      }
      if (val === Infinity || val === -Infinity) return "Infinity";
      return "Error";
    } catch {
      return "Error";
    }
  };

  // Day/Night Light mode state
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("wlth-theme");
      if (saved === "dark" || saved === "light") return saved;
      
      // Check device theme preference
      if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
        return "dark";
      }
      return "light";
    }
    return "dark";
  });

  useEffect(() => {
    document.documentElement.className = theme;
    localStorage.setItem("wlth-theme", theme);
  }, [theme]);

  // Language and Currency are fixed to English and USD ($)
  const lang = "en";
  const t = DICT_EN;
  const currency = "$";

  const INPUT_LABELS_LOCALIZED: Record<string, Record<string, string>> = {
    tr: {
      "Initial Investment": "Başlangıç Yatırımı",
      "Monthly Contribution": "Aylık Katkı Payı",
      "Annual % Interest": "Yıllık % Faiz Oranı",
      "Years to Save": "Tasarruf Süresi (Yıl)",
      "Compound Interval": "Bileşik Faiz Sıklığı",
      "Monthly Budget": "Aylık Bütçe",
      "Interest Rate (%)": "Yıllık Faiz Oranı (%)",
      "Annual Interest Rate (%)": "Yıllık Faiz Oranı (%)",
      "Loan Term (years)": "Vade (Yıl)",
      "Down Payment": "Peşinat Tutarı",
      "Down Payment ($)": "Peşinat Tutarı",
      "Home Price ($)": "Ev Değeri",
      "Property Tax (%)": "Yıllık Emlak Vergisi (%)",
      "Annual Property Tax (%)": "Yıllık Emlak Vergisi (%)",
      "Home Insurance ($/yr)": "Aylık Konut Sigortası",
      "Annual Home Insurance ($)": "Aylık Konut Sigortası",
      "PMI (%)": "Kredi Sigortası (PMI) (%)",
      "HOA Fees ($/mo)": "Aylık Aidat ve Giderler",
      "Monthly HOA Fees ($)": "Aylık Aidat ve Giderler",
      "Annual Salary": "Yıllık Brüt Maaş",
      "Annual Gross Salary ($)": "Yıllık Brüt Maaş",
      "Value A": "A Değeri",
      "Value B": "B Değeri",
      "Calculator Mode": "Yöntem / Varyasyon",
      "Operator": "Operatör",
      "weight": "Ağırlık (kg)",
      "height": "Boy (cm)",
      "age": "Yaş",
      "gender": "Cinsiyet",
      "activity": "Aktivite Seviyesi",
    },
    es: {
      "Initial Investment": "Inversión Inicial",
      "Monthly Contribution": "Contribución Mensual",
      "Annual % Interest": "Interés Anual %",
      "Years to Save": "Años para Ahorrar",
      "Compound Interval": "Intervalo de Composición",
      "Monthly Budget": "Presupuesto Mensual",
      "Interest Rate (%)": "Tasa de Interés (%)",
      "Annual Interest Rate (%)": "Tasa de Interés Anual (%)",
      "Loan Term (years)": "Plazo del Préstamo (Años)",
      "Down Payment": "Pago Inicial",
      "Down Payment ($)": "Pago Inicial",
      "Home Price ($)": "Precio de la Casa",
      "Property Tax (%)": "Impuesto a la Propiedad (%)",
      "Annual Property Tax (%)": "Impuesto a la Propiedad Anual (%)",
      "Home Insurance ($/yr)": "Seguro de Hogar ($/año)",
      "Annual Home Insurance ($)": "Seguro de Hogar Anual",
      "PMI (%)": "Seguro PMI (%)",
      "HOA Fees ($/mo)": "Tarifas de HOA",
      "Monthly HOA Fees ($)": "Tarifas de HOA Mensuales",
      "Annual Salary": "Salario Anual",
      "Annual Gross Salary ($)": "Salario Bruto Anual",
      "Value A": "Valor A",
      "Value B": "Valor B",
      "Calculator Mode": "Modo de Calculadora",
      "Operator": "Operador",
      "weight": "Peso (kg)",
      "height": "Altura (cm)",
      "age": "Edad",
      "gender": "Género",
      "activity": "Nivel de Actividad",
    },
    de: {
      "Initial Investment": "Anfangsinvestition",
      "Monthly Contribution": "Monatlicher Beitrag",
      "Annual % Interest": "Jährlicher Zins %",
      "Years to Save": "Jahre zum Sparen",
      "Compound Interval": "Zinseszinsintervall",
      "Monthly Budget": "Monatliches Budget",
      "Interest Rate (%)": "Zinssatz (%)",
      "Annual Interest Rate (%)": "Jährlicher Zinssatz (%)",
      "Loan Term (years)": "Kreditlaufzeit (Jahre)",
      "Down Payment": "Anzahlung",
      "Down Payment ($)": "Anzahlung",
      "Home Price ($)": "Hauspreis",
      "Property Tax (%)": "Grundsteuer (%)",
      "Annual Property Tax (%)": "Jährliche Grundsteuer (%)",
      "Home Insurance ($/yr)": "Hausversicherung ($/Jahr)",
      "Annual Home Insurance ($)": "Jährliche Hausversicherung",
      "PMI (%)": "PMI (%)",
      "HOA Fees ($/mo)": "HOA-Gebühren",
      "Monthly HOA Fees ($)": "Monatliche HOA-Gebühren",
      "Annual Salary": "Jahresgehalt",
      "Annual Gross Salary ($)": "Jährliches Bruttogehalt",
      "Value A": "Wert A",
      "Value B": "Wert B",
      "Calculator Mode": "Rechnermodus",
      "Operator": "Operator",
      "weight": "Gewicht (kg)",
      "height": "Größe (cm)",
      "age": "Alter",
      "gender": "Geschlecht",
      "activity": "Aktivitätslevel",
    },
    fr: {
      "Initial Investment": "Investissement Initial",
      "Monthly Contribution": "Contribution Mensuelle",
      "Annual % Interest": "Intérêt Annuel %",
      "Years to Save": "Années à Épargner",
      "Compound Interval": "Intervalle de Capitalisation",
      "Monthly Budget": "Budget Mensuel",
      "Interest Rate (%)": "Taux d'Intérêt (%)",
      "Annual Interest Rate (%)": "Taux d'Intérêt Annuel (%)",
      "Loan Term (years)": "Durée du Prêt (Ans)",
      "Down Payment": "Apport Personnel",
      "Down Payment ($)": "Apport Personnel",
      "Home Price ($)": "Prix de la Maison",
      "Property Tax (%)": "Taxe Foncière (%)",
      "Annual Property Tax (%)": "Taxe Foncière Annuelle (%)",
      "Home Insurance ($/yr)": "Assurance Habitation ($/an)",
      "Annual Home Insurance ($)": "Assurance Habitation Annuelle",
      "PMI (%)": "Assurance PMI (%)",
      "HOA Fees ($/mo)": "Frais de Copropriété",
      "Monthly HOA Fees ($)": "Frais de Copropriété Mensuels",
      "Annual Salary": "Salaire Annuel",
      "Annual Gross Salary ($)": "Salaire Brut Annuel",
      "Value A": "Valeur A",
      "Value B": "Valeur B",
      "Calculator Mode": "Mode Calculatrice",
      "Operator": "Opérateur",
      "weight": "Poids (kg)",
      "height": "Taille (cm)",
      "age": "Âge",
      "gender": "Genre",
      "activity": "Niveau d'Activité",
    },
    it: {
      "Initial Investment": "Investimento Iniziale",
      "Monthly Contribution": "Contributo Mensile",
      "Annual % Interest": "Interesse Annuo %",
      "Years to Save": "Anni da Risparmiare",
      "Compound Interval": "Intervallo di Capitalizzazione",
      "Monthly Budget": "Budget Mensile",
      "Interest Rate (%)": "Tasso di Interesse (%)",
      "Annual Interest Rate (%)": "Tasso di Interesse Annuo (%)",
      "Loan Term (years)": "Durata del Prestito (Anni)",
      "Down Payment": "Acconto Iniziale",
      "Down Payment ($)": "Acconto Iniziale",
      "Home Price ($)": "Prezzo Casa",
      "Property Tax (%)": "Imposta Fondiaria (%)",
      "Annual Property Tax (%)": "Imposta Fondiaria Annua (%)",
      "Home Insurance ($/yr)": "Assicurazione Casa ($/anno)",
      "Annual Home Insurance ($)": "Assicurazione Casa Annua",
      "PMI (%)": "PMI (%)",
      "HOA Fees ($/mo)": "Spese Condominiali",
      "Monthly HOA Fees ($)": "Spese Condominiali Mensili",
      "Annual Salary": "Stipendio Annuo",
      "Annual Gross Salary ($)": "Stipendio Lordo Annuo",
      "Value A": "Valore A",
      "Value B": "Valore B",
      "Calculator Mode": "Modalità Calcolatore",
      "Operator": "Operatore",
      "weight": "Peso (kg)",
      "height": "Altezza (cm)",
      "age": "Età",
      "gender": "Genere",
      "activity": "Livello di Attività",
    }
  };

  const OUTPUT_LABELS_LOCALIZED: Record<string, Record<string, string>> = {
    tr: {
      "Calculated Ending Balance": "Hesaplanan Dönem Sonu Bakiye",
      "Ending Balance": "Hesaplanan Dönem Sonu Bakiye",
      "Calculated Monthly Payment": "Hesaplanan Aylık Taksit",
      "Monthly Payment": "Hesaplanan Aylık Taksit",
      "Body Mass Index": "Vücut Kitle İndeksi (BMI)",
      "Calculated BMI": "Vücut Kitle İndeksi (BMI)",
      "Daily Water Intake": "Günlük Su Tüketimi",
      "Calories Burned": "Yakılan Kalori Miktarı"
    },
    es: {
      "Calculated Ending Balance": "Saldo Final Calculado",
      "Ending Balance": "Saldo Final",
      "Calculated Monthly Payment": "Pago Mensual Calculado",
      "Monthly Payment": "Pago Mensual",
      "Body Mass Index": "Índice de Masa Corporal (IMC)",
      "Calculated BMI": "IMC Calculado",
      "Daily Water Intake": "Consumo de Agua Diario",
      "Calories Burned": "Calorías Quemadas"
    },
    de: {
      "Calculated Ending Balance": "Berechneter Endbestand",
      "Ending Balance": "Endbestand",
      "Calculated Monthly Payment": "Berechnete monatliche Rate",
      "Monthly Payment": "Monatliche Rate",
      "Body Mass Index": "Body-Mass-Index (BMI)",
      "Calculated BMI": "Berechneter BMI",
      "Daily Water Intake": "Täglicher Wasserbedarf",
      "Calories Burned": "Verbrannte Kalorien"
    },
    fr: {
      "Calculated Ending Balance": "Solde Final Calculé",
      "Ending Balance": "Solde Final",
      "Calculated Monthly Payment": "Mensualité Calculée",
      "Monthly Payment": "Mensualité",
      "Body Mass Index": "Indice de Masse Corporelle (IMC)",
      "Calculated BMI": "IMC Calculé",
      "Daily Water Intake": "Consommation d'Eau Quotidienne",
      "Calories Burned": "Calories Brûlées"
    },
    it: {
      "Calculated Ending Balance": "Saldo Finale Calcolato",
      "Ending Balance": "Saldo Finale",
      "Calculated Monthly Payment": "Rata Mensile Calcolata",
      "Monthly Payment": "Rata Mensile",
      "Body Mass Index": "Indice di Massa Corporea (IMC)",
      "Calculated BMI": "IMC Calcolato",
      "Daily Water Intake": "Fabbisogno Idrico Giornaliero",
      "Calories Burned": "Calorie Bruciate"
    }
  };

  const getLocalizedTool = (tool: CalculatorTool): CalculatorTool => {
    const localized = CALC_LOCALE_MAP_ALL[lang]?.[tool.title];
    let title = tool.title;
    let description = tool.description;
    if (localized) {
      title = localized.title;
      description = localized.desc;
    }

    const localizedInputs = tool.inputs.map(input => {
      let label = input.label;
      const langLabels = INPUT_LABELS_LOCALIZED[lang];
      if (langLabels && langLabels[label]) {
        label = langLabels[label];
      } else if (langLabels && langLabels[input.id]) {
        label = langLabels[input.id];
      }
      
      // Inject the selected currency symbol into the label if necessary
      if (currency !== "$") {
        label = label.replace(/\$|\(USD\)/gi, currency);
      }

      let prefix = input.prefix;
      if (prefix === "$") {
        prefix = currency;
      }

      return { ...input, label, prefix };
    });

    let output_label = tool.output_label;
    const langOutputs = OUTPUT_LABELS_LOCALIZED[lang];
    if (langOutputs && langOutputs[output_label]) {
      output_label = langOutputs[output_label];
    }

    let output_prefix = tool.output_prefix;
    if (output_prefix === "$") {
      output_prefix = currency;
    }

    return {
      ...tool,
      title,
      description,
      inputs: localizedInputs,
      output_label,
      output_prefix
    };
  };

  const toggleTheme = () => {
    if (isWaveActive) return;
    setIsWaveActive(true);
    
    // Switch the theme halfway through the soft fade-in transition
    setTimeout(() => {
      setTheme((prev) => (prev === "dark" ? "light" : "dark"));
    }, 180);

    // Conclude transition and clear backdrop overlay
    setTimeout(() => {
      setIsWaveActive(false);
    }, 400);
  };

  // Sync inputs details into state whenever an active tool is loaded
  useEffect(() => {
    if (activeTool) {
      const initialState: Record<string, any> = {};
      activeTool.inputs.forEach((input) => {
        const isDatePart = input.id.includes("day") || input.id.includes("month") || input.id.includes("year");
        if (input.type === "select") {
          initialState[input.id] = input.default;
        } else if (input.type === "date" || isDatePart) {
          initialState[input.id] = input.default ?? "";
        } else {
          initialState[input.id] = 0;
        }
      });
      setInputsState(initialState);
    }
  }, [activeTool]);

  // Submit search query directly or using Gemini 2.5 Flash
  const handleSubmitPrompt = async (searchPrompt: string) => {
    if (!searchPrompt.trim()) return;
    setIsLoading(true);
    setError(null);
    setHasInteracted(true);

    // 1. Direct Predefined Match Lookups (Instant routing to avoid unnecessary LLM calls)
    const localMatch = findMatchingPredefinedCalculator(searchPrompt);
    if (localMatch) {
      setTimeout(() => {
        setSanitizedActiveTool(localMatch);
        setIsLoading(false);
      }, 300); // Small fluid transition effect
      return;
    }

    // 2. Fall back to AI Model for unique custom generation
    try {
      const response = await fetch("/api/parse-query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: searchPrompt }),
      });

      if (!response.ok) {
        throw new Error("Server responded with error status");
      }

      const toolData = await response.json();
      if (toolData && toolData.title && toolData.formula) {
        setSanitizedActiveTool(toolData);
      } else {
        throw new Error("Invalid tool definition returned");
      }
    } catch (err: any) {
      console.error("Failed to parse tool prompt, adopting smart template client-side fallback:", err);
      // Safe fallback to our premium mortgage analyzer
      const match = PREDEFINED_CALCULATORS[0];
      setSanitizedActiveTool({
        ...match,
        title: `${searchPrompt.charAt(0).toUpperCase() + searchPrompt.slice(1)} Estimator`,
        description: `Custom configured tool modeled after "${searchPrompt}"`
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleChipClick = (suggestion: string) => {
    setQuery(suggestion);
    setConfirmedQuery(suggestion);
    handleSubmitPrompt(suggestion);
  };

  const handleGhostSelect = (tool: CalculatorTool) => {
    setHasInteracted(true);
    setSanitizedActiveTool(tool);
  };

  const handleReset = () => {
    setSanitizedActiveTool(null);
    setQuery("");
    setConfirmedQuery("");
    setHasInteracted(false);
    setError(null);
  };

  // Live calculations
  const calculatedOutput = activeTool 
    ? (activeTool.id === "interest_calculator"
        ? calculateInterestEarnings(inputsState).endingBalance
        : calculateFormula(activeTool.formula, inputsState, activeTool.id))
    : 0;

  const projectionsData = activeTool 
    ? generateProjections(activeTool, inputsState) 
    : [];

  const localizedActiveTool = activeTool ? getLocalizedTool(activeTool) : null;

  // Dynamic Date Input grouping & helpers
  const datePrefixes = ["start", "end", "birth"];
  const activePrefixes = activeTool ? datePrefixes.filter(prefix => 
    activeTool.inputs.some(i => i.id === `${prefix}_day`) &&
    activeTool.inputs.some(i => i.id === `${prefix}_month`) &&
    activeTool.inputs.some(i => i.id === `${prefix}_year`)
  ) : [];

  const isGroupedInput = (inputId: string) => {
    if (!activeTool) return false;
    return activePrefixes.some(prefix => 
      inputId === `${prefix}_day` || 
      inputId === `${prefix}_month` || 
      inputId === `${prefix}_year`
    );
  };

  const monthsList = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const getExactTimeDifferenceText = (day: number, month: number, year: number): string => {
    if (!day || !month || !year) return "No date selected";
    
    const now = new Date(); // e.g. 2026-06-02
    const targetDate = new Date(year, month - 1, day);

    let isPast = true;
    let d1 = targetDate;
    let d2 = now;
    if (targetDate.getTime() > now.getTime()) {
      isPast = false;
      d1 = now;
      d2 = targetDate;
    }

    let years = d2.getFullYear() - d1.getFullYear();
    let months = d2.getMonth() - d1.getMonth();
    let days = d2.getDate() - d1.getDate();

    if (days < 0) {
      months--;
      const prevMonth = new Date(d2.getFullYear(), d2.getMonth(), 0);
      days += prevMonth.getDate();
    }
    if (months < 0) {
      years--;
      months += 12;
    }

    const parts: string[] = [];
    if (years > 0) parts.push(`${years} ${years === 1 ? "year" : "years"}`);
    if (months > 0) parts.push(`${months} ${months === 1 ? "month" : "months"}`);
    if (days > 0 || parts.length === 0) parts.push(`${days} ${days === 1 ? "day" : "days"}`);

    return parts.join(", ") + (isPast ? " elapsed" : " remaining");
  };

  // Theme-sensitive constant classes
  const isDark = theme === "dark";
  const rootBg = isDark ? "bg-[#121214] text-[#F3F4F6]" : "bg-[#F8FAFC] text-[#1E293B]";
  const headerBg = isDark ? "bg-[#18181C]/90 border-[#27272C]" : "bg-white/95 border-slate-200/80";
  const textTitle = isDark ? "text-white font-semibold" : "text-slate-900 font-medium";
  const textMuted = isDark ? "text-gray-400" : "text-slate-500";
  const cardBg = isDark ? "bg-[#1E1E22] border-[#2C2C35] shadow-[0_4px_30px_rgba(0,0,0,0.45)]" : "bg-white border-slate-200 shadow-sm";
  const boxBg = isDark ? "bg-[#25252A] border-[#2E2E36]" : "bg-slate-50 border-slate-200/80";
  const selectBg = isDark ? "bg-[#1E1E22] border-[#2E2E36] text-gray-200" : "bg-white border-slate-300 text-slate-800";
  const accentColor = isDark ? "#00FF87" : "#10B981"; // Electric green vs deep emerald
  const accentBorder = isDark ? "border-[#00FF87]/30" : "border-[#10B981]/30";
  
  return (
    <div className={`min-h-screen ${rootBg} font-sans selection:bg-emerald-500/20 selection:text-emerald-400 flex flex-col justify-between transition-colors duration-300 overflow-x-hidden w-full max-w-[100vw] relative`} id="wlth-app-root">
      
      {/* 1. Header Navigation Bar */}
      <header className={`border-b ${headerBg} backdrop-blur-md sticky top-0 z-50 px-5 py-3 flex justify-between items-center transition-colors duration-200`} id="nav-header">
        <div className="flex items-center gap-2 cursor-pointer" onClick={handleReset} id="logo-container">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-400 to-[#10B981] flex items-center justify-center shadow-md">
            <span className="text-[10px] font-black text-white tracking-tight font-mono">+−×÷</span>
          </div>
          <span className={`text-xl font-bold tracking-tight ${textTitle} font-sans flex items-center`}>
            c<span className="text-[#10B981] dark:text-[#00FF87] font-black">al</span>culator
          </span>
        </div>
        
        <div className="flex items-center gap-2 sm:gap-3">


          {/* Theme Switcher Button */}
          <button
            onClick={toggleTheme}
            className={`p-1.5 sm:p-2 rounded-xl border cursor-pointer ${
              isDark 
                ? "bg-[#25252A] border-[#2C2C35] text-[#00FF87] hover:bg-[#2B2B32]" 
                : "bg-white border-slate-200 text-[#10B981] hover:bg-slate-50 shadow-xs"
            } transition-all`}
            aria-label="Toggle Theme Mode"
            id="theme-toggler-btn"
          >
            {isDark ? (
              <Sun className="w-3.5 h-3.5" />
            ) : (
              <Moon className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </header>

      {/* 2. Main Content Canvas */}
      <main className="flex-grow flex flex-col px-4 md:px-8 py-8 items-center max-w-6xl mx-auto w-full relative z-10" id="main-canvas">
        
        {/* Hero Title Section with Ambient Animated Glow */}
        <motion.div 
          layout
          className="w-full text-center max-w-2xl mx-auto relative"
          animate={{ 
            marginBottom: hasInteracted ? "1.5rem" : "2.5rem",
            transformOrigin: "center top"
          }}
          transition={{ duration: 0.4, ease: "easeInOut" }}
          id="hero-header-box"
        >
          {/* Glowing Ambient Light Orbs behind the title (freely diffused, clipped horizontally at page edge) */}
          <div className="absolute inset-0 -top-16 -bottom-16 pointer-events-none flex items-center justify-center overflow-visible z-0 select-none">
            {/* Primary Pulsing & Drifting Glow Orb */}
            <motion.div
              className="absolute w-72 sm:w-80 md:w-96 h-36 sm:h-40 md:h-48 rounded-full filter blur-2xl md:blur-3xl pointer-events-none"
              animate={{
                x: [-60, 60, -45, 65, -50, 0],
                y: [-22, 18, -15, 20, -12, 0],
                scale: [0.85, 1.25, 0.9, 1.3, 0.95, 1.15, 0.85],
                opacity: [0.35, 0.85, 0.4, 0.95, 0.3, 0.75, 0.35],
              }}
              transition={{
                duration: 9,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              {/* Dark mode primary gradient layer */}
              <motion.div
                className="absolute inset-0 w-full h-full rounded-full bg-gradient-to-r from-[#00FF87]/40 via-emerald-400/35 to-cyan-400/30"
                initial={false}
                animate={{ opacity: isDark ? 1 : 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
              />
              {/* Light mode primary gradient layer */}
              <motion.div
                className="absolute inset-0 w-full h-full rounded-full bg-gradient-to-r from-emerald-400/40 via-teal-300/45 to-green-300/35"
                initial={false}
                animate={{ opacity: isDark ? 0 : 1 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
              />
            </motion.div>

            {/* Secondary Harmonic Shimmer Orb */}
            <motion.div
              className="absolute w-56 sm:w-64 md:w-80 h-28 sm:h-32 md:h-40 rounded-full filter blur-xl md:blur-2xl pointer-events-none"
              animate={{
                x: [55, -65, 45, -55, 60, 0],
                y: [18, -20, 15, -14, 18, 0],
                scale: [1.2, 0.85, 1.25, 0.9, 1.15, 0.95, 1.2],
                opacity: [0.25, 0.7, 0.3, 0.8, 0.25, 0.6, 0.25],
              }}
              transition={{
                duration: 11,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              {/* Dark mode secondary gradient layer */}
              <motion.div
                className="absolute inset-0 w-full h-full rounded-full bg-gradient-to-r from-cyan-400/30 via-[#00FF87]/35 to-emerald-500/25"
                initial={false}
                animate={{ opacity: isDark ? 1 : 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
              />
              {/* Light mode secondary gradient layer */}
              <motion.div
                className="absolute inset-0 w-full h-full rounded-full bg-gradient-to-r from-teal-300/35 via-emerald-400/30 to-lime-300/25"
                initial={false}
                animate={{ opacity: isDark ? 0 : 1 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
              />
            </motion.div>
          </div>

          <motion.h1 
            layout 
            className="text-3xl md:text-5xl font-extrabold tracking-tight mt-1 mb-2 bg-gradient-to-r from-emerald-500 to-green-500 dark:from-[#00FF87] dark:to-emerald-400 bg-clip-text text-transparent relative z-10 drop-shadow-xs"
            style={{ fontSize: hasInteracted ? "1.75rem" : undefined }}
            transition={{ duration: 0.3 }}
          >
            {t.title}
          </motion.h1>
          
          <motion.p 
            layout 
            className={`text-sm ${textMuted} max-w-md mx-auto leading-relaxed relative z-10`}
            style={{ display: hasInteracted ? "none" : "block" }}
          >
            {t.description}
          </motion.p>
        </motion.div>

        {/* 3. Central AI Prompter Bar */}
        <div className="w-full max-w-2xl mx-auto mb-6 relative z-30" id="search-inputs-area">
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              handleEmailSubmit(query);
            }}
            className="relative"
          >
            <div className="absolute left-5 top-1/2 -translate-y-1/2 text-emerald-500 dark:text-[#00FF87]">
              <Bell className="w-5 h-5" />
            </div>
            
            <input
              type="email"
              id="main-calculator-prompt-input"
              value={query}
              onChange={(e) => {
                const val = e.target.value;
                setQuery(val);
                if (emailError) setEmailError(null);
              }}
              placeholder={t.placeholder}
              className={`w-full pl-12 pr-16 py-4 rounded-full border focus:outline-none transition-all font-sans text-sm ${
                isDark 
                  ? "bg-[#1E1E22] text-gray-100 border-[#2C2C35] placeholder:text-gray-600 focus:border-[#00FF87] focus:ring-1 focus:ring-[#00FF87]"
                  : "bg-white text-slate-950 border-slate-250 placeholder:text-sky-950/30 focus:border-[#10B981] focus:ring-1 focus:ring-[#10B981] shadow-xs"
              }`}
            />

            <button
              type="submit"
              disabled={!query.trim()}
              className={`absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                isDark 
                  ? "bg-[#00FF87] text-black hover:opacity-90 disabled:bg-[#25252A] disabled:text-gray-750 shadow-md"
                  : "bg-[#10B981] text-white hover:opacity-95 disabled:bg-slate-200 disabled:text-slate-400 shadow-sm"
              }`}
              id="prompt-submit-btn"
            >
              <Bell className="w-4 h-4 stroke-[2.5]" />
            </button>
          </form>

          {emailError && (
            <p className="mt-2 text-center text-xs text-red-400 font-medium">{emailError}</p>
          )}

          {emailSubscribed && (
            <motion.div 
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className={`mt-3 p-3 rounded-2xl border text-xs text-center font-medium ${
                isDark ? "bg-emerald-950/30 border-emerald-500/30 text-emerald-300" : "bg-emerald-50 border-emerald-200 text-emerald-800"
              }`}
            >
              🎉 {subscribedEmail} başarıyla kaydedildi! 🔔 Bildirimler ve bülten aboneliği aktif edildi.
            </motion.div>
          )}

          {/* Quick interactive Suggestion Chips */}
          <AnimatePresence>
            {!hasInteracted && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 flex flex-wrap gap-1.5 justify-center"
                id="suggestion-chips-container"
              >
                {(SUGGESTIONS_ALL[lang] || SUGGESTIONS_ALL.en).map((rawSig, idx) => {
                  const s = currency !== "$" ? rawSig.replace(/\$/g, currency) : rawSig;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleChipClick(s)}
                      disabled={isLoading}
                      className={`text-[10.5px] font-sans font-medium tracking-wide border px-3.5 py-1.5 rounded-full transition-all focus:outline-none cursor-pointer ${
                        isDark
                          ? "bg-[#0E0E10] hover:bg-[#151518] border-neutral-850 hover:border-[#00FF87]/30 text-gray-400 hover:text-[#00FF87]"
                          : "bg-white hover:bg-slate-50 border-slate-200 text-slate-600 hover:text-[#10B981] shadow-xs"
                      }`}
                    >
                      {s}
                    </button>
                  );
                })}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* 4. Display Loading State / Error Messages */}
        <div className="w-full max-w-2xl mx-auto animate-fade-in">
          {isLoading && !activeTool && (
            <div className="flex flex-col items-center justify-center p-12 text-center" id="global-loading">
              <div className="relative mb-4">
                <div className={`w-12 h-12 rounded-full border-2 border-neutral-300 animate-spin border-t-[${accentColor}]`} />
                <Sparkles className="w-5 h-5 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse text-emerald-500" />
              </div>
              <p className="font-mono text-[10px] text-gray-500 uppercase tracking-widest animate-pulse">
                Generating Interactive Calculator... Please hold on...
              </p>
            </div>
          )}

          {error && (
            <div className="p-4 rounded-2xl bg-red-950/25 border border-red-900/30 text-red-400 text-xs flex gap-3 mb-6" id="error-alert">
              <HelpCircle className="w-5 h-5 flex-shrink-0 text-red-500 animate-pulse" />
              <div>{error}</div>
            </div>
          )}
        </div>

        {/* 5. Tool Card Display */}
        <AnimatePresence>
          {activeTool && (
            <motion.div
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              className="w-full max-w-6xl mx-auto relative z-20"
              id="active-tool-card-wrapper"
            >
              <div className={`${cardBg} rounded-3xl p-4 sm:p-6 md:p-8 relative border transition-all duration-200`} id="active-tool-card">
                
                {/* Accent Top Bar */}
                <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#10B981] to-transparent rounded-t-3xl" />

                {/* Card Title Box, Custom Category & Share Actions */}
                <div className="mb-6 flex flex-col sm:flex-row justify-between items-start gap-4 border-b border-gray-500/10 dark:border-neutral-800/20 pb-5">
                  <div className="text-left">
                    <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-[#050508] bg-[#00FF87] px-2.5 py-0.5 rounded-full inline-block shadow-[0_0_8px_rgba(0,255,135,0.2)]">
                      {localizedActiveTool?.tool_type === "compound_interest" ? t.calcActivePrefix : (localizedActiveTool?.tool_type?.replace("_", " ") || "util")}
                    </span>
                    <h2 className={`text-xl md:text-2xl font-black tracking-tight ${textTitle} mt-1.5`}>
                      {localizedActiveTool?.title}
                    </h2>
                    <p className={`text-xs ${textMuted} mt-1 leading-relaxed`}>
                      {localizedActiveTool?.description}
                    </p>
                  </div>

                  {/* Action Group: Share & Download PDF */}
                  <div className="flex flex-row items-center gap-2 self-end sm:self-start">
                    {/* Sleek, pulsing Share Button */}
                    <button
                      onClick={handleShareClick}
                      className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold font-mono tracking-wide uppercase rounded-xl border transition-all duration-200 cursor-pointer ${
                        copied 
                          ? "border-emerald-500 bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 shadow-[0_0_12px_rgba(16,185,129,0.2)]" 
                          : "border-[#00FF87]/30 bg-[#00FF87]/5 hover:bg-[#00FF87]/15 text-[#00FF87] shadow-[0_0_12px_rgba(0,255,135,0.06)] hover:shadow-[0_0_20px_rgba(0,255,135,0.15)]"
                      }`}
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                          <span>{t.copied}</span>
                        </>
                      ) : (
                        <>
                          <Share2 className="w-3.5 h-3.5" />
                          <span>{t.share}</span>
                        </>
                      )}
                    </button>

                    {/* Download PDF Button */}
                    <button
                      onClick={handleDownloadPdf}
                      className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold font-mono tracking-wide uppercase rounded-xl border border-sky-450/30 bg-sky-400/5 hover:bg-sky-400/15 text-sky-400 dark:text-sky-400 transition-all duration-200 shadow-[0_0_12px_rgba(14,165,233,0.06)] hover:shadow-[0_0_20px_rgba(14,165,233,0.15)] cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>PDF</span>
                    </button>
                  </div>
                </div>

                {/* Vertical Stack Layout (Inputs on top, Charts below) */}
                <div className="flex flex-col gap-8 w-full">
                  
                  {/* Top Column: Interactive Parameters & Calculated Value */}
                  <div className="w-full flex flex-col gap-6" id="calc-inputs-column">
                    <div className="flex flex-col gap-4 font-sans" id="tool-inputs-grid">
                      {activeTool.id === "basic_calculator" && (
                        <div className={`${boxBg} rounded-2xl p-5 flex flex-col border border-emerald-500/10 hover:border-emerald-500/20 transition-colors duration-250 gap-4 max-w-lg mx-auto w-full`} id="basic-keypad-card">
                          <div className="flex items-center justify-between">
                            <label className="text-[11px] uppercase font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold">
                              Basic Desktop Keypad
                            </label>
                            <span className="text-[10px] font-mono text-gray-500 font-semibold">Standard 4-Function</span>
                          </div>

                          {/* Display Screen */}
                          <div className="w-full rounded-xl bg-slate-950 border border-slate-800 dark:border-neutral-800 p-4 flex flex-col items-end gap-1 font-mono select-all min-h-[85px] justify-between shadow-inner">
                            <div className="text-[10px] text-gray-400 tracking-widest uppercase">Expression</div>
                            <div className="text-base font-bold text-gray-200 w-full text-right whitespace-nowrap overflow-x-auto scrollbar-none tracking-normal">
                              {basicExpr || "0"}
                            </div>
                            <div className="text-2xl font-black text-[#00FF87] tracking-tight">
                              {basicResult !== "" ? `= ${basicResult}` : ""}
                            </div>
                          </div>

                          {/* Keypad Grid (4 Columns) */}
                          <div className="grid grid-cols-4 gap-2 text-sm font-mono font-bold">
                            {/* Row 1 */}
                            <button 
                              onClick={() => { setBasicExpr(""); setBasicResult(""); }} 
                              className="p-3.5 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-red-500 dark:text-red-400 transition-all cursor-pointer active:scale-95 border border-red-500/20 font-extrabold"
                            >
                              AC
                            </button>
                            <button 
                              onClick={() => { if (basicExpr.length > 0) setBasicExpr(p => p.slice(0, -1)); }} 
                              className="p-3.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-500 dark:text-red-400 transition-all cursor-pointer active:scale-95 border border-red-500/20"
                            >
                              ⌫
                            </button>
                            <button 
                              onClick={() => setBasicExpr(p => p + "%")} 
                              className="p-3.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 transition-all cursor-pointer active:scale-95 border border-amber-500/20 font-extrabold"
                            >
                              %
                            </button>
                            <button 
                              onClick={() => setBasicExpr(p => p + "÷")} 
                              className="p-3.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-500 transition-all cursor-pointer active:scale-95 border border-amber-500/20 font-black text-base"
                            >
                              ÷
                            </button>

                            {/* Row 2 */}
                            <button onClick={() => setBasicExpr(p => p + "7")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>7</button>
                            <button onClick={() => setBasicExpr(p => p + "8")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>8</button>
                            <button onClick={() => setBasicExpr(p => p + "9")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>9</button>
                            <button onClick={() => setBasicExpr(p => p + "×")} className="p-3.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-500 transition-all cursor-pointer active:scale-95 border border-amber-500/20 font-black text-base">×</button>

                            {/* Row 3 */}
                            <button onClick={() => setBasicExpr(p => p + "4")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>4</button>
                            <button onClick={() => setBasicExpr(p => p + "5")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>5</button>
                            <button onClick={() => setBasicExpr(p => p + "6")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>6</button>
                            <button onClick={() => setBasicExpr(p => p + "−")} className="p-3.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-500 transition-all cursor-pointer active:scale-95 border border-amber-500/20 font-black text-base">−</button>

                            {/* Row 4 */}
                            <button onClick={() => setBasicExpr(p => p + "1")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>1</button>
                            <button onClick={() => setBasicExpr(p => p + "2")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>2</button>
                            <button onClick={() => setBasicExpr(p => p + "3")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>3</button>
                            <button onClick={() => setBasicExpr(p => p + "+")} className="p-3.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-500 transition-all cursor-pointer active:scale-95 border border-amber-500/20 font-black text-base">+</button>

                            {/* Row 5 */}
                            <button 
                              onClick={() => {
                                setBasicExpr(p => {
                                  if (!p || p === "0") return "-";
                                  if (p.startsWith("-(")) return p.slice(2, -1);
                                  if (p.startsWith("-")) return p.slice(1);
                                  return `-(${p})`;
                                });
                              }} 
                              className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-gray-300" : "bg-white border-slate-200 text-slate-700"}`}
                            >
                              ±
                            </button>
                            <button onClick={() => setBasicExpr(p => p + "0")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>0</button>
                            <button onClick={() => setBasicExpr(p => p + ".")} className={`p-3.5 rounded-xl border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-base ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>.</button>
                            <button 
                              onClick={() => {
                                const res = safeEvalBasic(basicExpr);
                                setBasicResult(res);
                                if (res !== "Error" && basicExpr !== "") {
                                  setBasicHistory(h => [`${basicExpr} = ${res}`, ...h.slice(0, 7)]);
                                }
                              }} 
                              className="p-3.5 rounded-xl bg-[#00FF87] hover:brightness-110 text-black font-black text-base transition-all cursor-pointer active:scale-95 shadow-[0_0_12px_rgba(0,255,135,0.2)]"
                            >
                              =
                            </button>
                          </div>

                          {/* Interactive Tapelog */}
                          {basicHistory.length > 0 && (
                            <div className="flex flex-col gap-1.5 mt-2 border-t border-slate-250 dark:border-neutral-800/65 pt-3">
                              <div className="flex items-center justify-between">
                                <span className="text-[10px] tracking-widest uppercase text-gray-500 font-bold font-mono">Calculation History</span>
                                <button onClick={() => setBasicHistory([])} className="text-[10px] text-red-400 hover:underline font-mono cursor-pointer">Clear</button>
                              </div>
                              <div className="flex flex-col gap-1.5 max-h-32 overflow-y-auto scrollbar-none font-mono text-xs">
                                {basicHistory.map((item, idx) => (
                                  <div 
                                    key={idx} 
                                    onClick={() => {
                                      const parts = item.split("=");
                                      if (parts.length > 1) {
                                        setBasicExpr(parts[1].trim());
                                        setBasicResult("");
                                      }
                                    }}
                                    className={`p-2 rounded-xl border flex justify-between items-center cursor-pointer transition-colors ${
                                      isDark ? "bg-[#25252A]/40 border-[#2E2E36] text-gray-400 hover:bg-[#25252A]" : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200/70"
                                    }`}
                                  >
                                    <span>{item.split("=")[0].trim()}</span>
                                    <span className="font-extrabold text-[#10B981] dark:text-[#00FF87]">= {item.split("=")[1].trim()}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {activeTool.id === "scientific_calculator" && (
                        <div className={`${boxBg} rounded-2xl p-5 flex flex-col border border-emerald-500/10 hover:border-emerald-500/20 transition-colors duration-250 gap-4 max-w-2xl mx-auto w-full`} id="scientific-keypad-card">
                          <div className="flex items-center justify-between flex-wrap gap-2">
                            <label className="text-[11px] uppercase font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold">
                              Full-Featured Scientific Keypad
                            </label>
                            
                            {/* Mode Switches: DEG/RAD & 2nd/INV */}
                            <div className="flex items-center gap-2">
                              <div className="flex rounded-lg p-0.5 border border-slate-700/50 bg-slate-900/60 text-[10px] font-mono font-bold">
                                <button 
                                  onClick={() => setSciAngleMode("deg")} 
                                  className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                                    sciAngleMode === "deg" ? "bg-emerald-500 text-black font-extrabold shadow-xs" : "text-gray-400 hover:text-white"
                                  }`}
                                >
                                  DEG
                                </button>
                                <button 
                                  onClick={() => setSciAngleMode("rad")} 
                                  className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                                    sciAngleMode === "rad" ? "bg-emerald-500 text-black font-extrabold shadow-xs" : "text-gray-400 hover:text-white"
                                  }`}
                                >
                                  RAD
                                </button>
                              </div>

                              <button 
                                onClick={() => setSciInvMode(p => !p)} 
                                className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold border transition-all cursor-pointer ${
                                  sciInvMode 
                                    ? "bg-[#00FF87] text-black border-[#00FF87] shadow-[0_0_8px_rgba(0,255,135,0.3)]" 
                                    : "border-slate-700/50 bg-slate-900/60 text-gray-400 hover:text-white"
                                }`}
                              >
                                2nd
                              </button>
                            </div>
                          </div>

                          {/* Display Screen */}
                          <div className="w-full rounded-xl bg-slate-950 border border-slate-800 dark:border-neutral-800 p-4 flex flex-col items-end gap-1 font-mono select-all min-h-[90px] justify-between shadow-inner">
                            <div className="flex justify-between items-center w-full">
                              <span className="text-[10px] text-emerald-400/80 font-mono tracking-wider font-semibold uppercase">
                                [{sciAngleMode.toUpperCase()}]{sciInvMode ? " [INV]" : ""}
                              </span>
                              <span className="text-[10px] text-gray-500 tracking-widest uppercase">Scientific Formula</span>
                            </div>
                            <div className="text-base font-bold text-gray-200 w-full text-right whitespace-nowrap overflow-x-auto scrollbar-none tracking-normal">
                              {sciExpr || "0"}
                            </div>
                            <div className="text-2xl font-black text-[#00FF87] tracking-tight">
                              {sciResult !== "" ? `= ${sciResult}` : ""}
                            </div>
                          </div>

                          {/* Keypad Grid (5 Columns) */}
                          <div className="grid grid-cols-5 gap-1.5 text-xs font-mono font-bold">
                            {/* Row 1: Parens, Percent, Backspace, Clear */}
                            <button onClick={() => setSciExpr(p => p + "(")} className="p-2.5 rounded-lg bg-slate-500/15 hover:bg-slate-500/25 text-gray-300 transition-all cursor-pointer active:scale-95 border border-slate-500/20">(</button>
                            <button onClick={() => setSciExpr(p => p + ")")} className="p-2.5 rounded-lg bg-slate-500/15 hover:bg-slate-500/25 text-gray-300 transition-all cursor-pointer active:scale-95 border border-slate-500/20">)</button>
                            <button onClick={() => setSciExpr(p => p + "%")} className="p-2.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 transition-all cursor-pointer active:scale-95 border border-amber-500/20 font-bold">%</button>
                            <button 
                              onClick={() => { if (sciExpr.length > 0) setSciExpr(p => p.slice(0, -1)); }} 
                              className="p-2.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-500 dark:text-red-400 transition-all cursor-pointer active:scale-95 border border-red-500/20"
                            >
                              ⌫
                            </button>
                            <button 
                              onClick={() => { setSciExpr(""); setSciResult(""); }} 
                              className="p-2.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-500 dark:text-red-400 transition-all cursor-pointer active:scale-95 border border-red-500/20 font-black"
                            >
                              AC
                            </button>

                            {/* Row 2: Trig functions, Pi, Divide */}
                            <button 
                              onClick={() => setSciExpr(p => p + (sciInvMode ? "asin(" : "sin("))} 
                              className={`p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border ${isDark ? "border-emerald-500/5" : "border-emerald-500/20"}`}
                            >
                              {sciInvMode ? "sin⁻¹" : "sin"}
                            </button>
                            <button 
                              onClick={() => setSciExpr(p => p + (sciInvMode ? "acos(" : "cos("))} 
                              className={`p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border ${isDark ? "border-emerald-500/5" : "border-emerald-500/20"}`}
                            >
                              {sciInvMode ? "cos⁻¹" : "cos"}
                            </button>
                            <button 
                              onClick={() => setSciExpr(p => p + (sciInvMode ? "atan(" : "tan("))} 
                              className={`p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border ${isDark ? "border-emerald-500/5" : "border-emerald-500/20"}`}
                            >
                              {sciInvMode ? "tan⁻¹" : "tan"}
                            </button>
                            <button onClick={() => setSciExpr(p => p + "π")} className="p-2.5 rounded-lg bg-slate-500/10 hover:bg-slate-500/20 text-gray-400 transition-all cursor-pointer active:scale-95 border border-slate-500/20">π</button>
                            <button onClick={() => setSciExpr(p => p + "÷")} className="p-2.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-500 transition-all cursor-pointer active:scale-95 border border-amber-500/20 font-black text-sm">÷</button>

                            {/* Row 3: Log / Powers, e, Multiply */}
                            <button onClick={() => setSciExpr(p => p + "ln(")} className={`p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border ${isDark ? "border-emerald-500/5" : "border-emerald-500/20"}`}>ln</button>
                            <button onClick={() => setSciExpr(p => p + "log(")} className={`p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border ${isDark ? "border-emerald-500/5" : "border-emerald-500/20"}`}>log</button>
                            <button onClick={() => setSciExpr(p => p + "^")} className={`p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border ${isDark ? "border-emerald-500/5" : "border-emerald-500/20"}`}>x^y</button>
                            <button onClick={() => setSciExpr(p => p + "e")} className="p-2.5 rounded-lg bg-slate-500/10 hover:bg-slate-500/20 text-gray-400 transition-all cursor-pointer active:scale-95 border border-slate-500/20">e</button>
                            <button onClick={() => setSciExpr(p => p + "×")} className="p-2.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-500 transition-all cursor-pointer active:scale-95 border border-amber-500/20 font-black text-sm">×</button>

                            {/* Row 4: Roots / Square & Numbers 7, 8, 9 */}
                            <button onClick={() => setSciExpr(p => p + "√(")} className="p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border border-emerald-500/20">√</button>
                            <button onClick={() => setSciExpr(p => p + "^2")} className="p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border border-emerald-500/20">x²</button>
                            <button onClick={() => setSciExpr(p => p + "7")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>7</button>
                            <button onClick={() => setSciExpr(p => p + "8")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>8</button>
                            <button onClick={() => setSciExpr(p => p + "9")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>9</button>

                            {/* Row 5: 1/x, Factorial & Numbers 4, 5, 6 */}
                            <button onClick={() => setSciExpr(p => p + "1/(")} className="p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border border-emerald-500/20">1/x</button>
                            <button onClick={() => setSciExpr(p => p + "!")} className="p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border border-emerald-500/20">x!</button>
                            <button onClick={() => setSciExpr(p => p + "4")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>4</button>
                            <button onClick={() => setSciExpr(p => p + "5")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>5</button>
                            <button onClick={() => setSciExpr(p => p + "6")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>6</button>

                            {/* Row 6: cbrt, EXP & Numbers 1, 2, 3 */}
                            <button onClick={() => setSciExpr(p => p + "cbrt(")} className="p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border border-emerald-500/20">∛</button>
                            <button onClick={() => setSciExpr(p => p + "EXP")} className="p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border border-emerald-500/20">EXP</button>
                            <button onClick={() => setSciExpr(p => p + "1")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>1</button>
                            <button onClick={() => setSciExpr(p => p + "2")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>2</button>
                            <button onClick={() => setSciExpr(p => p + "3")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>3</button>

                            {/* Row 7: abs, plus/minus, 0, dot, Minus */}
                            <button onClick={() => setSciExpr(p => p + "abs(")} className="p-2.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/25 text-[#00FF87] transition-all cursor-pointer active:scale-95 border border-emerald-500/20">|x|</button>
                            <button 
                              onClick={() => {
                                setSciExpr(p => {
                                  if (!p || p === "0") return "-";
                                  if (p.startsWith("-(")) return p.slice(2, -1);
                                  if (p.startsWith("-")) return p.slice(1);
                                  return `-(${p})`;
                                });
                              }} 
                              className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-gray-300" : "bg-white border-slate-200 text-slate-700"}`}
                            >
                              ±
                            </button>
                            <button onClick={() => setSciExpr(p => p + "0")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>0</button>
                            <button onClick={() => setSciExpr(p => p + ".")} className={`p-2.5 rounded-lg border hover:bg-slate-500/10 transition-all cursor-pointer active:scale-95 text-sm ${isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-white border-slate-200 text-slate-800"}`}>.</button>
                            <button onClick={() => setSciExpr(p => p + "−")} className="p-2.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-500 transition-all cursor-pointer active:scale-95 border border-amber-500/20 font-black text-sm">−</button>
                          </div>

                          {/* Bottom Operator row & Calculate Solution Button */}
                          <div className="flex gap-2 w-full mt-1 flex-col xs:flex-row">
                            <button 
                              onClick={() => setSciExpr(p => p + "+")} 
                              className="px-6 py-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 font-black font-mono text-base border border-amber-500/30 transition-all cursor-pointer active:scale-95 text-center"
                            >
                              +
                            </button>
                            <button 
                              onClick={() => {
                                const res = safeEvalScientific(sciExpr, sciAngleMode === "deg");
                                setSciResult(res);
                                if (res !== "Error" && sciExpr !== "") {
                                  setSciHistory(h => [`${sciExpr} = ${res}`, ...h.slice(0, 7)]);
                                }
                              }}
                              className="flex-1 py-3 text-xs rounded-xl bg-[#00FF87] hover:brightness-110 text-black font-extrabold uppercase font-mono tracking-wider active:scale-[0.98] transition-all cursor-pointer text-center shadow-[0_0_15px_rgba(0,255,135,0.25)]"
                            >
                              Calculate Solution (=)
                            </button>
                          </div>

                          {/* Interactive Tapelog */}
                          {sciHistory.length > 0 && (
                            <div className="flex flex-col gap-1.5 mt-2 border-t border-slate-250 dark:border-neutral-800/65 pt-3">
                              <div className="flex items-center justify-between">
                                <span className="text-[10px] tracking-widest uppercase text-gray-500 font-bold font-mono">Scientific Tape History</span>
                                <button onClick={() => setSciHistory([])} className="text-[10px] text-red-400 hover:underline font-mono cursor-pointer">Clear</button>
                              </div>
                              <div className="flex flex-col gap-1.5 max-h-32 overflow-y-auto scrollbar-none font-mono text-xs">
                                {sciHistory.map((item, idx) => (
                                  <div 
                                    key={idx} 
                                    onClick={() => {
                                      const parts = item.split("=");
                                      if (parts.length > 1) {
                                        setSciExpr(parts[1].trim());
                                        setSciResult("");
                                      }
                                    }}
                                    className={`p-2 rounded-xl border flex justify-between items-center cursor-pointer transition-colors ${
                                      isDark ? "bg-[#25252A]/40 border-[#2E2E36] text-gray-400 hover:bg-[#25252A]" : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200/70"
                                    }`}
                                  >
                                    <span>{item.split("=")[0].trim()}</span>
                                    <span className="font-extrabold text-[#10B981] dark:text-[#00FF87]">= {item.split("=")[1].trim()}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Unified Date Group Selectors (Side-By-Side horizontal dropdown arrays) */}
                      {activeTool.id !== "basic_calculator" && activeTool.id !== "scientific_calculator" && activePrefixes.map((prefix) => {
                        const dayInput = activeTool.inputs.find(i => i.id === `${prefix}_day`)!;
                        const monthInput = activeTool.inputs.find(i => i.id === `${prefix}_month`)!;
                        const yearInput = activeTool.inputs.find(i => i.id === `${prefix}_year`)!;

                        const currentDay = inputsState[`${prefix}_day`] ?? dayInput.default;
                        const currentMonth = inputsState[`${prefix}_month`] ?? monthInput.default;
                        const currentYear = inputsState[`${prefix}_year`] ?? yearInput.default;

                        const labelTitle = prefix === "start" ? "Target/Start Date" : prefix === "end" ? "End Date" : "Birth Date";

                        const daysArray = Array.from({ length: 31 }, (_, i) => i + 1);
                        const yearsArray = [];
                        const minY = yearInput.min ?? 1920;
                        const maxY = yearInput.max ?? 2050;
                        for (let y = minY; y <= maxY; y++) {
                          yearsArray.push(y);
                        }

                        return (
                          <div 
                            key={prefix} 
                            className={`${boxBg} rounded-2xl p-4 flex flex-col border hover:border-neutral-500 dark:hover:border-neutral-850 transition-colors duration-250`}
                          >
                            <label className="text-[10px] uppercase font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold mb-3">
                              {labelTitle}
                            </label>
                            
                            <div className="grid grid-cols-3 gap-3 flex-row">
                              {/* Day Dropdown */}
                              <div className="flex flex-col gap-1 text-left">
                                <span className="text-[9px] font-mono text-gray-400 font-bold uppercase">DAY</span>
                                <div className="relative">
                                  <select 
                                    value={currentDay}
                                    onChange={(e) => setInputsState(p => ({ ...p, [`${prefix}_day`]: Number(e.target.value) }))}
                                    className={`w-full ${selectBg} rounded-xl px-2.5 py-2 text-xs font-mono focus:ring-1 focus:ring-emerald-550 focus:outline-none appearance-none border`}
                                  >
                                    {daysArray.map(d => (
                                      <option key={d} value={d}>{d}</option>
                                    ))}
                                  </select>
                                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-[9px]">▼</div>
                                </div>
                              </div>

                              {/* Month Dropdown */}
                              <div className="flex flex-col gap-1 text-left">
                                <span className="text-[9px] font-mono text-gray-400 font-bold uppercase">MONTH</span>
                                <div className="relative">
                                  <select 
                                    value={currentMonth}
                                    onChange={(e) => setInputsState(p => ({ ...p, [`${prefix}_month`]: Number(e.target.value) }))}
                                    className={`w-full ${selectBg} rounded-xl px-2.5 py-2 text-xs font-mono focus:ring-1 focus:ring-emerald-550 focus:outline-none appearance-none border`}
                                  >
                                    {monthsList.map((m, idx) => (
                                      <option key={idx} value={idx + 1}>{m}</option>
                                    ))}
                                  </select>
                                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-[9px]">▼</div>
                                </div>
                              </div>

                              {/* Year Dropdown */}
                              <div className="flex flex-col gap-1 text-left">
                                <span className="text-[9px] font-mono text-gray-400 font-bold uppercase">YEAR</span>
                                <div className="relative">
                                  <select 
                                    value={currentYear}
                                    onChange={(e) => setInputsState(p => ({ ...p, [`${prefix}_year`]: Number(e.target.value) }))}
                                    className={`w-full ${selectBg} rounded-xl px-2.5 py-2 text-xs font-mono focus:ring-1 focus:ring-emerald-555 focus:outline-none appearance-none border`}
                                  >
                                    {yearsArray.map(y => (
                                      <option key={y} value={y}>{y}</option>
                                    ))}
                                  </select>
                                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-[9px]">▼</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}

                      {/* Render Non-Date fields */}
                      {activeTool.id !== "basic_calculator" && activeTool.id !== "scientific_calculator" && activeTool.inputs.filter(input => !isGroupedInput(input.id)).map((input) => {
                        const currentVal = inputsState[input.id] ?? input.default;
                        
                        // For date calculator, conditionally hide some inputs based on operation mode
                        if (activeTool.id === "date_calculator") {
                          const currentMode = String(inputsState["calc_mode"] ?? "Calculate Duration");
                          if (input.id === "end_date" && currentMode !== "Calculate Duration") {
                            return null;
                          }
                          if (input.id === "days_offset" && currentMode === "Calculate Duration") {
                            return null;
                          }
                        }

                        // Collapse sub-costs if include_costs is disabled
                        const subCostIds = ["property_taxes", "home_insurance", "pmi_insurance", "hoa_fee", "other_costs"];
                        if (activeTool.tool_type === "mortgage" && subCostIds.includes(input.id)) {
                          const includeCosts = Number(inputsState["include_costs"] ?? 0) === 1;
                          if (!includeCosts) return null;
                        }

                        // Render include_costs as a custom styled checkbox/toggle
                        if (input.id === "include_costs" && activeTool.tool_type === "mortgage") {
                          const isChecked = Number(currentVal) === 1;
                          return (
                            <div 
                              key={input.id} 
                              className={`p-4 rounded-xl flex items-center gap-3 border ${
                                isDark 
                                  ? "bg-[#1E1E22]/50 border-[#2C2C35] hover:border-[#2E2E36]" 
                                  : "bg-slate-50 border-slate-200 hover:border-slate-350 shadow-xs"
                              }`}
                            >
                              <label className="flex items-center gap-3 cursor-pointer select-none text-xs font-bold leading-none w-full">
                                <div className="relative">
                                  <input 
                                    type="checkbox" 
                                    checked={isChecked}
                                    onChange={(e) => {
                                      setInputsState(p => ({ ...p, [input.id]: e.target.checked ? 1 : 0 }));
                                    }}
                                    className="sr-only"
                                  />
                                  <div className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center transition-all duration-200 ${
                                    isChecked 
                                      ? "bg-[#10B981] border-[#10B981] shadow-[0_0_8px_rgba(16,185,129,0.35)]" 
                                      : "bg-transparent border-gray-400 dark:border-neutral-705"
                                  }`}>
                                    {isChecked && (
                                      <Check className="w-3.5 h-3.5 text-white stroke-[3.5]" />
                                    )}
                                  </div>
                                </div>
                                <span className={isDark ? "text-gray-300 font-mono text-[10px] font-bold tracking-wide uppercase" : "text-slate-800 font-mono text-[10px] font-bold tracking-wide uppercase"}>
                                  {input.label}
                                </span>
                              </label>
                            </div>
                          );
                        }

                        const isPercentSymbol = input.suffix === "%" || (input.prefix && input.prefix.includes("%")) || input.id.includes("rate") || input.id.includes("apr") || input.id.includes("tax") || input.label.toLowerCase().includes("yield");
                        const isMonthlyMoney = input.id.includes("monthly") || input.id.includes("payment") || input.id.includes("addition") || input.id.includes("rent") || input.label.toLowerCase().includes("monthly");

                        // Prioritize explicitly specified values from the tool's definition
                        let minSlider = input.min !== undefined ? Math.min(input.min, 0) : 0;
                        let maxSlider = input.max !== undefined ? input.max : 10000;
                        let stepValue = input.step !== undefined ? input.step : 100;

                        // Only apply default fallback overrides if no explicit range was defined
                        if (input.min === undefined || input.max === undefined) {
                          if (isPercentSymbol) {
                            minSlider = 0;
                            maxSlider = 40;
                            stepValue = 0.5;
                          } else if (isMonthlyMoney) {
                            minSlider = 0;
                            maxSlider = 10000;
                            stepValue = 50;
                          } else if (input.id.includes("years") || input.id.includes("term") || input.label.toLowerCase().includes("yıl") || input.label.toLowerCase().includes("duration")) {
                            minSlider = 0;
                            maxSlider = 55;
                            stepValue = 1;
                          }
                        }

                        // Bound slider visuals while allowing manual entries to exceed bounds intact!
                        const sliderValue = currentVal > maxSlider ? maxSlider : (currentVal < minSlider ? minSlider : currentVal);
                        
                        // Add nice subtle visual indent indentation style to subcost selectors
                        const isChild = activeTool.tool_type === "mortgage" && subCostIds.includes(input.id);

                        return (
                          <DataInputCard
                            key={input.id}
                            id={input.id}
                            // 1. Sol Üst (Label / Başlık): Parantezsiz temiz başlık (Örn: ANNUAL INTEREST RATE)
                            topLeftLabel={input.topLeftLabel}
                            label={input.label}
                            // 2. Sağ Üst (Badge / Etiket): Parantez içi etiket veya rozet (Örn: APR %)
                            topRightBadge={input.topRightBadge ?? input.badge}
                            // 3. Sol Alt (Input Value / Girdi Değeri): Kullanıcının girdiği sayı/değer (Örn: 0)
                            bottomLeftValue={currentVal}
                            value={currentVal}
                            // 4. Sağ Alt (Suffix / Birim): Varsayılan olarak boş
                            bottomRightSuffix={input.bottomRightSuffix}
                            suffix={input.suffix}
                            prefix={input.prefix}
                            type={input.type}
                            options={input.options}
                            min={minSlider}
                            max={maxSlider}
                            step={stepValue}
                            isDark={isDark}
                            isChild={isChild}
                            onChange={(val) => {
                              setInputsState(p => ({ ...p, [input.id]: val }));
                            }}
                          />
                        );
                      })}

                      {/* Start Date selectors for mortgage specifically */}
                      {activeTool.tool_type === "mortgage" && (
                        <div 
                          className={`${boxBg} rounded-2xl p-4 flex flex-col border hover:border-neutral-400 dark:hover:border-neutral-800 transition-colors duration-250`}
                          id="mortgage-startdate-custom-card"
                        >
                          <label className="text-[10px] uppercase font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold mb-3">
                            Start Date
                          </label>
                          
                          <div className="grid grid-cols-2 gap-3">
                            {/* Month Select */}
                            <div className="flex flex-col gap-1 text-left">
                              <span className="text-[9px] font-mono text-gray-400 font-bold uppercase">MONTH</span>
                              <div className="relative">
                                <select 
                                  value={mortgageStartMonth}
                                  onChange={(e) => setMortgageStartMonth(Number(e.target.value))}
                                  className={`w-full ${selectBg} rounded-xl px-2.5 py-2 text-xs font-mono focus:ring-1 focus:ring-emerald-550 focus:outline-none appearance-none border`}
                                >
                                  {monthsList.map((m, idx) => (
                                    <option key={idx} value={idx + 1}>{m}</option>
                                  ))}
                                </select>
                                <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-[9px]">▼</div>
                              </div>
                            </div>

                            {/* Year Select */}
                            <div className="flex flex-col gap-1 text-left">
                              <span className="text-[9px] font-mono text-gray-400 font-bold uppercase">YEAR</span>
                              <div className="relative">
                                <select 
                                  value={mortgageStartYear}
                                  onChange={(e) => setMortgageStartYear(Number(e.target.value))}
                                  className={`w-full ${selectBg} rounded-xl px-2.5 py-2 text-xs font-mono focus:ring-1 focus:ring-emerald-550 focus:outline-none appearance-none border`}
                                >
                                  {Array.from({ length: 30 }, (_, i) => 2024 + i).map((yr) => (
                                    <option key={yr} value={yr}>{yr}</option>
                                  ))}
                                </select>
                                <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-[9px]">▼</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Calculated Numerical Result display panel inside Left Column */}
                    {!(
                      activeTool.id === "basic_calculator" ||
                      activeTool.id === "scientific_calculator" ||
                      activeTool.id === "interest_calculator" ||
                      activeTool.tool_type === "compound_interest" ||
                      activeTool.tool_type === "investment" ||
                      activeTool.tool_type === "mortgage" ||
                      activeTool.tool_type === "loan_calculator" ||
                      activeTool.tool_type === "budget" ||
                      activeTool.id === "fifty_thirty_twenty_calculator" ||
                      activeTool.id?.includes("fifty_thirty_twenty") ||
                      activeTool.title?.includes("50/30/20")
                    ) && (
                      <div className={`p-5 ${isDark ? "bg-[#25252A] border-[#2E2E36]" : "bg-slate-50 border-slate-200/80"} border rounded-2xl relative overflow-hidden`} id="results-display-pnl">
                        <div className="absolute -bottom-8 -right-8 w-20 h-20 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

                        <div className="text-center md:text-left flex flex-col justify-between relative z-10 gap-3">
                          <div>
                            <span className="text-[9px] tracking-widest uppercase font-mono text-gray-500 font-extrabold block">
                              {activeTool.output_label || "Calculated Balance Outcome"}
                            </span>
                            <div className={`text-lg md:text-2xl font-black ${textTitle} mt-1.5 font-mono flex flex-wrap items-center justify-center md:justify-start tracking-tight leading-snug`}>
                              {activeTool.tool_type === "date_difference"
                                ? getExactTimeDifferenceText(
                                    inputsState["start_day"] ?? 15,
                                    inputsState["start_month"] ?? 6,
                                    inputsState["start_year"] ?? 1994
                                  )
                                : (activeTool.tool_type === "math" || activeTool.id === "date_calculator")
                                ? getMathResultDetails(activeTool.id, inputsState, calculatedOutput).primaryText
                                : activeTool.tool_type === "health"
                                ? (() => {
                                    if (activeTool.id === "bmi_calculator") {
                                      const bmi = calculatedOutput;
                                      let cat = "Normal weight";
                                      if (bmi < 18.5) cat = "Underweight";
                                      else if (bmi < 25) cat = "Normal weight";
                                      else if (bmi < 30) cat = "Overweight";
                                      else cat = "Obese";
                                      return `${bmi.toFixed(1)} (${cat})`;
                                    }
                                    if (activeTool.id === "bmr_calculator" || activeTool.id === "tdee_calculator") {
                                      return `${Math.round(calculatedOutput).toLocaleString()} kcal/day`;
                                    }
                                    if (activeTool.id === "ideal_weight_calculator") {
                                      return `${calculatedOutput.toFixed(1)} kg`;
                                    }
                                    if (activeTool.id === "water_intake_calculator") {
                                      return `${calculatedOutput.toFixed(2)} Liters`;
                                    }
                                    if (activeTool.id === "calories_burned_calculator") {
                                      return `${Math.round(calculatedOutput).toLocaleString()} kcal`;
                                    }
                                    return formatValue(calculatedOutput, activeTool.output_prefix || "", activeTool.output_suffix || "");
                                  })()
                                : formatValue(calculatedOutput, activeTool.output_prefix || "", activeTool.output_suffix || "")
                              }
                            </div>
                          </div>
                          
                          <div className={`self-start text-[9px] uppercase font-mono font-bold px-2.5 py-1 rounded-lg border flex gap-1.5 items-center tracking-wider ${
                            isDark ? "bg-[#1E1E22] border-[#2C2C35] text-gray-300" : "bg-white border-slate-200 text-slate-700 shadow-xs"
                          }`}>
                            <TrendingUp className="w-3.5 h-3.5 text-emerald-450" />
                            <span>Real-Time Computed</span>
                          </div>
                        </div>
                      </div>
                    )}

                  </div>

                  {/* Bottom Column: Side-by-Side Charts & Actionable AI Insights */}
                  <div className="w-full flex flex-col gap-6" id="calc-charts-column">
                    
                    {/* Live SVGs Chart Panel or Bento Time Statistics Grid */}
                    {activeTool.id === "interest_calculator" || activeTool.id === "investment_calculator" || activeTool.tool_type === "compound_interest" || activeTool.tool_type === "investment" ? (
                      (() => {
                        const results = calculateInterestEarnings(inputsState);
                        const initialInvestment = Number(inputsState["initial_investment"] ?? inputsState["principal"] ?? inputsState["current_savings"] ?? 0);
                        const termMonths = inputsState["term_months"] !== undefined
                          ? Number(inputsState["term_months"])
                          : (inputsState["years"] !== undefined ? Number(inputsState["years"]) * 12 : 60);

                        return (
                          <div className="w-full flex-grow flex flex-col gap-6" id="interest-premium-visual-pnl">
                            
                            {/* Line Chart */}
                            <div className="w-full" id="interest-chart-space">
                              <span className="text-[10px] font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold block uppercase mb-3">
                                Compounding Growth Curve over Time
                              </span>
                              <CustomChart 
                                data={projectionsData} 
                                chartType="line" 
                                theme={theme} 
                                outputPrefix={currency}
                              />
                            </div>

                            {/* Additional Summary Stats Grid matching user layout */}
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-3.5 animate-fade-in" id="interest-summary-stats-box">
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Initial Investment</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>{formatValue(initialInvestment, currency, "")}</span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Total Contributions</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>{formatValue(results.totalContributions, currency, "")}</span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Interest on Initial</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>{formatValue(results.interestInitial, currency, "")}</span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Interest on Contribs</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>{formatValue(results.interestContributions, currency, "")}</span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Compounding</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>{inputsState["compound_frequency"] ?? "Monthly"}</span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#10B981]/10 border-[#10B981]/30" : "bg-emerald-50 border-emerald-200"}`}>
                                <span className="text-[8px] font-mono text-emerald-600 dark:text-emerald-400 font-bold uppercase block leading-none mb-1">Ending Balance</span>
                                <span className="text-[#10B981] font-mono font-black text-sm block">{formatValue(results.endingBalance, currency, "")}</span>
                              </div>
                            </div>

                          </div>
                        );
                      })()
                    ) : activeTool.tool_type === "date_difference" ? (
                      <div className="w-full flex-grow flex flex-col justify-start" id="date-custom-statistics">
                        <span className="text-[10px] font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold block uppercase mb-4">
                          Time Metric Live Statistics Breakdowns
                        </span>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4" id="date-stats-grid">
                          {projectionsData.map((stat, idx) => (
                            <div 
                              key={idx} 
                              className={`p-5 rounded-2xl border flex flex-col justify-between transition-all duration-350 hover:scale-[1.02] hover:border-emerald-500/40 ${
                              isDark ? "bg-[#18181B] border-[#27272A] hover:bg-[#202024]" : "bg-white border-slate-200/95 hover:bg-slate-50 shadow-xs"
                            }`}
                            >
                              <div>
                                <span className="text-[9px] font-mono tracking-wider text-gray-400 block uppercase mb-1.5">{stat.label}</span>
                                <span className={`text-xl font-mono font-extrabold tracking-tight ${textTitle} block`}>
                                  {stat.value.toLocaleString()}
                                </span>
                              </div>
                              <div className="mt-4 pt-3 border-t border-dashed border-neutral-400/20">
                                <span className="text-[9px] font-mono text-gray-500 block uppercase mb-0.5">{stat.secondaryLabel}</span>
                                <span className="text-xs font-mono font-extrabold text-[#10B981]">
                                  {stat.secondaryValue?.toLocaleString() ?? 0}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : activeTool.tool_type === "mortgage" || activeTool.id === "mortgage_calculator" || activeTool.id === "house_loan_calculator" ? (
                      (() => {
                        const price = Number(inputsState["home_price"] ?? inputsState["price"] ?? inputsState["house_price"] ?? 400000);
                        const downPercent = Number(inputsState["down_payment"] ?? inputsState["down"] ?? inputsState["down_payment_pct"] ?? 20);
                        const termMonths = inputsState["term_months"] !== undefined
                          ? Number(inputsState["term_months"])
                          : (inputsState["years"] !== undefined ? Number(inputsState["years"]) * 12 : 360);
                        const totalMonths = Math.max(1, termMonths);
                        const rate = Number(inputsState["interest_rate"] ?? inputsState["rate"] ?? 6.576);

                        const loanAmount = price * (1 - downPercent / 100);
                        const downPaymentAmount = price * (downPercent / 100);
                        const monthlyRate = rate / 100 / 12;

                        const principalAndInterest =
                          monthlyRate === 0
                            ? loanAmount / totalMonths
                            : (loanAmount * (monthlyRate * Math.pow(1 + Math.max(monthlyRate, 0), totalMonths))) /
                              (Math.pow(1 + Math.max(monthlyRate, 0), totalMonths) - 1);

                        const totalPAndIPayments = principalAndInterest * totalMonths;
                        const totalInterestPaid = totalPAndIPayments - loanAmount;

                        return (
                          <div className="w-full flex-grow flex flex-col gap-6" id="mortgage-premium-visual-pnl">
                            
                            {/* Line Chart representation */}
                            <div className="w-full" id="mortgage-line-space">
                              <span className="text-[10px] font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold block uppercase mb-3">
                                Remaining Balance Over Time
                              </span>
                              <CustomChart 
                                data={projectionsData} 
                                chartType="line" 
                                theme={theme} 
                                outputPrefix={currency}
                              />
                            </div>

                            {/* Additional Summary Stats Grid matching user layout */}
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-3.5 animate-fade-in" id="mortgage-summary-stats-box">
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Home Price</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>{formatValue(price, currency, "")}</span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Down Payment</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>{formatValue(downPaymentAmount, currency, "")} ({downPercent}%)</span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Loan Principal</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>{formatValue(loanAmount, currency, "")}</span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Total Interest Paid</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>{formatValue(totalInterestPaid, currency, "")}</span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Loan Term</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>{totalMonths} Months</span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#10B981]/10 border-[#10B981]/30" : "bg-emerald-50 border-emerald-200"}`}>
                                <span className="text-[8px] font-mono text-emerald-600 dark:text-emerald-400 font-bold uppercase block leading-none mb-1">Monthly Payment</span>
                                <span className="text-[#10B981] font-mono font-black text-sm block">{formatValue(principalAndInterest, currency, "")}</span>
                              </div>
                            </div>

                          </div>
                        );
                      })()
                    ) : activeTool.tool_type === "loan_calculator" ? (
                      (() => {
                        const isAmortized = activeTool.id === "amortized_loan";
                        const isDeferred = activeTool.id === "deferred_loan";
                        const isBond = activeTool.id === "bond_loan";

                        // Get parameters safely
                        const loanAmt = Number(inputsState["loan_amount"] ?? inputsState["principal"] ?? inputsState["vehicle_price"] ?? inputsState["predetermined_amount"] ?? 100000);
                        const termMonths = inputsState["term_months"] !== undefined
                          ? Number(inputsState["term_months"])
                          : (inputsState["years"] !== undefined ? Number(inputsState["years"]) * 12 : 60);
                        const totalMonths = Math.max(1, termMonths);
                        const rate = Number(inputsState["interest_rate"] ?? inputsState["annual_rate"] ?? inputsState["rate"] ?? 6);
                        const periodicRate = rate / 100 / 12;

                        let principalAndInterest = 0;
                        let totalPayments = 0;
                        let totalInterestPaid = 0;

                        if (totalMonths > 0) {
                          principalAndInterest = periodicRate === 0
                            ? loanAmt / totalMonths
                            : (loanAmt * (periodicRate * Math.pow(1 + periodicRate, totalMonths))) /
                              (Math.pow(1 + periodicRate, totalMonths) - 1);
                          totalPayments = principalAndInterest * totalMonths;
                          totalInterestPaid = totalPayments - loanAmt;
                        }

                        return (
                          <div className="w-full flex-grow flex flex-col gap-6" id="loan-premium-visual-pnl">
                            
                            {/* Chart visual representation */}
                            <div className="w-full" id="loan-chart-space">
                              <span className="text-[10px] font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold block uppercase mb-3">
                                Loan Repayment & Amortization Projections
                              </span>
                              <CustomChart 
                                data={projectionsData} 
                                chartType={activeTool.chart_type === "distribution" ? "distribution" : "bar"} 
                                theme={theme} 
                                outputPrefix={currency}
                              />
                            </div>

                            {/* Additional Summary Stats Grid matching user layout */}
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-3.5 animate-fade-in" id="loan-summary-stats-box">
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">
                                  Loan Principal
                                </span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>
                                  {formatValue(loanAmt, currency, "")}
                                </span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Loan Duration Term</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>
                                  {totalMonths} Months
                                </span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Annual Interest Rate</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>
                                  {rate}% APR
                                </span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Total Interest</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>
                                  {formatValue(totalInterestPaid, currency, "")}
                                </span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                                <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Total Repayment Cost</span>
                                <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>
                                  {formatValue(totalPayments, currency, "")}
                                </span>
                              </div>
                              <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#10B981]/10 border-[#10B981]/30" : "bg-emerald-50 border-emerald-200"}`}>
                                <span className="text-[8px] font-mono text-emerald-600 dark:text-emerald-400 font-bold uppercase block leading-none mb-1">Monthly Payment</span>
                                <span className="text-[#10B981] font-mono font-black text-sm block">
                                  {formatValue(principalAndInterest, currency, "")}
                                </span>
                              </div>
                            </div>

                          </div>
                        );
                      })()
                    ) : activeTool.id === "loss_tracker" || inputsState["daily_loss"] !== undefined ? (
                      (() => {
                        const dailyLoss = Number(inputsState["daily_loss"] ?? 400);
                        const activeDays = Number(inputsState["active_days"] ?? 365);
                        const otherLossMonthly = Number(inputsState["other_loss"] ?? 0);

                        const totalWeeklyLoss = dailyLoss * 7 + (otherLossMonthly / 4.33);
                        const totalMonthlyLoss = dailyLoss * 30 + otherLossMonthly;
                        const totalYearlyLoss = (dailyLoss * activeDays) + (otherLossMonthly * 12);

                        return (
                          <div className="w-full flex-grow flex flex-col gap-6" id="loss-premium-visual-pnl">
                            
                            {/* Summary spotlight banner */}
                            <div className={`p-5 rounded-3xl border text-center md:text-left flex flex-col sm:flex-row justify-between items-center relative overflow-hidden ${
                              isDark ? "bg-[#10B981]/15 border-[#10B981]/25 text-[#00FF87]" : "bg-[#10B981]/10 border-[#10B981]/20 text-emerald-850"
                            }`}>
                              <div className="text-center sm:text-left">
                                <span className="text-[9px] tracking-widest font-mono font-bold uppercase block opacity-85">TOTAL MONTHLY PROJECTED LOSS</span>
                                <span className={`text-2xl md:text-3xl font-black font-mono block mt-1 ${isDark ? "text-[#00FF87]" : "text-emerald-900"}`}>
                                  {formatValue(totalMonthlyLoss, currency, "")}
                                </span>
                              </div>
                              <div className="text-center sm:text-right mt-3 sm:mt-0 font-mono text-[9px] uppercase opacity-90 border-t sm:border-t-0 sm:border-l border-neutral-400/20 pt-2 sm:pt-0 sm:pl-4">
                                <div className={isDark ? "text-gray-300" : "text-slate-700"}>Daily Leak: {formatValue(dailyLoss, currency, "")}</div>
                                {otherLossMonthly > 0 && <div className={`mt-0.5 ${isDark ? "text-gray-350" : "text-slate-700"}`}>Other Leaks: {formatValue(otherLossMonthly, currency, "")} / mo</div>}
                              </div>
                            </div>

                            {/* Donut chart splitting the metrics */}
                            <div className="w-full" id="loss-donut-space">
                              <span className="text-[10px] font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold block uppercase mb-3">
                                Loss Distribution
                              </span>
                              <CustomChart 
                                data={projectionsData} 
                                chartType="distribution" 
                                theme={theme} 
                                outputPrefix={currency}
                              />
                            </div>

                            {/* Summary breakdown matrix */}
                            <div className={`border rounded-3xl p-5 ${isDark ? "bg-[#09090B] border-[#1F1F22]" : "bg-white border-slate-200 shadow-xs"}`}>
                              <span className="text-[10px] font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold block uppercase mb-4">
                                Cumulative Projection Summary
                              </span>
                              <div className="overflow-x-auto">
                                <table className="w-full text-left font-mono text-[11px] border-collapse">
                                  <thead>
                                    <tr className={`border-b text-[9px] uppercase font-bold text-gray-500 ${isDark ? "border-[#1F1F22]" : "border-slate-100"}`}>
                                      <th className="pb-2">Timeframe</th>
                                      <th className="pb-2 text-right">Amount</th>
                                      <th className="pb-2 text-right font-bold pr-1">Projection</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-gray-500/10">
                                    <tr className={isDark ? "hover:bg-neutral-900/25" : "hover:bg-slate-50/50"}>
                                      <td className={`py-2.5 font-sans font-bold ${isDark ? "text-gray-300" : "text-slate-800"}`}>Daily Cost / Loss</td>
                                      <td className="py-2.5 text-right font-bold text-neutral-400">{formatValue(dailyLoss, currency, "")}</td>
                                      <td className="py-2.5 text-right font-bold text-neutral-400 pr-1">1x Base</td>
                                    </tr>
                                    <tr className={isDark ? "hover:bg-neutral-900/25" : "hover:bg-slate-50/50"}>
                                      <td className={`py-2.5 font-sans font-bold ${isDark ? "text-gray-300" : "text-slate-800"}`}>Weekly Cumulative</td>
                                      <td className="py-2.5 text-right font-bold text-neutral-400">{formatValue(totalWeeklyLoss, currency, "")}</td>
                                      <td className="py-2.5 text-right font-bold text-neutral-400 pr-1">7x Average</td>
                                    </tr>
                                    <tr className={isDark ? "hover:bg-neutral-900/25" : "hover:bg-slate-50/50"}>
                                      <td className={`py-2.5 font-sans font-bold ${isDark ? "text-gray-300" : "text-slate-800"}`}>Monthly Cumulative</td>
                                      <td className="py-2.5 text-right font-bold text-neutral-400">{formatValue(totalMonthlyLoss, currency, "")}</td>
                                      <td className="py-2.5 text-right font-bold text-neutral-400 pr-1">30x Cumulative</td>
                                    </tr>
                                    <tr className="border-t border-double border-gray-400/30">
                                      <td className={`py-3 font-sans font-extrabold ${isDark ? "text-[#10B981]" : "text-emerald-700"}`}>Yearly Projection</td>
                                      <td className={`py-3 text-right font-bold ${isDark ? "text-[#10B981]" : "text-emerald-700"}`}>{formatValue(totalYearlyLoss, currency, "")}</td>
                                      <td className={`py-3 text-right font-bold ${isDark ? "text-[#10B981]" : "text-emerald-700"}`}>{activeDays} Active Days</td>
                                    </tr>
                                  </tbody>
                                </table>
                              </div>
                            </div>

                          </div>
                        );
                      })()
                    ) : (activeTool.tool_type !== "math" && activeTool.tool_type !== "health" && activeTool.chart_type !== "none") ? (
                      <div className="w-full flex-grow flex flex-col gap-6" id="chart-display-container">
                        <div className="w-full">
                          <span className="text-[10px] font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold block uppercase mb-3">
                            {activeTool.title} Projections & Breakdown
                          </span>
                          <CustomChart 
                            data={projectionsData} 
                            chartType={activeTool.chart_type} 
                            theme={theme} 
                            outputPrefix={(!activeTool.output_prefix || activeTool.output_prefix === "$") ? currency : activeTool.output_prefix}
                            outputSuffix={activeTool.output_suffix}
                          />
                        </div>

                        {projectionsData && projectionsData.length > 1 && (
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-3.5 animate-fade-in" id="generic-summary-stats-box">
                            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                              <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Starting Baseline</span>
                              <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>
                                {formatValue(projectionsData[0]?.value ?? 0, activeTool.output_prefix ?? "", activeTool.output_suffix ?? "")}
                              </span>
                            </div>
                            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                              <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Peak Projected Value</span>
                              <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>
                                {formatValue(Math.max(...projectionsData.map(p => p.value)), activeTool.output_prefix ?? "", activeTool.output_suffix ?? "")}
                              </span>
                            </div>
                            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                              <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Net Projected Delta</span>
                              <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>
                                {formatValue((projectionsData[projectionsData.length - 1]?.value ?? 0) - (projectionsData[0]?.value ?? 0), activeTool.output_prefix ?? "", activeTool.output_suffix ?? "")}
                              </span>
                            </div>
                            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                              <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Data Points</span>
                              <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>
                                {projectionsData.length} Periods
                              </span>
                            </div>
                            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#18181B] border-[#27272A]" : "bg-slate-50 border-slate-200"}`}>
                              <span className="text-[8px] font-mono text-gray-500 uppercase block leading-none mb-1">Average Projected</span>
                              <span className={`font-mono font-extrabold text-sm block ${isDark ? "text-white" : "text-slate-800"}`}>
                                {formatValue(Math.round(projectionsData.reduce((acc, curr) => acc + curr.value, 0) / (projectionsData.length || 1)), activeTool.output_prefix ?? "", activeTool.output_suffix ?? "")}
                              </span>
                            </div>
                            <div className={`p-4 rounded-2xl border ${isDark ? "bg-[#10B981]/10 border-[#10B981]/30" : "bg-emerald-50 border-emerald-200"}`}>
                              <span className="text-[8px] font-mono text-emerald-600 dark:text-emerald-400 font-bold uppercase block leading-none mb-1">Target Output Value</span>
                              <span className="text-[#10B981] font-mono font-black text-sm block">
                                {formatValue(calculatedOutput, activeTool.output_prefix ?? "", activeTool.output_suffix ?? "")}
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      (activeTool.tool_type === "math" || activeTool.tool_type === "health") ? null : (
                        <div className={`p-8 border rounded-2xl border-dashed text-center ${
                          isDark ? "bg-[#1E1E22]/30 border-[#2C2C35] text-gray-500" : "bg-slate-50/50 border-slate-200 text-slate-400"
                        }`}>
                          <BarChart2 className="w-8 h-8 mx-auto mb-2 opacity-50" />
                          <p className="text-xs font-mono">Dynamic visualization not available for this custom format.</p>
                        </div>
                      )
                    )}

                    {/* Actionable Insights Panel */}
                    <div className={`p-4 ${isDark ? "bg-[#25252A] border-[#2E2E36]" : "bg-slate-50 border-slate-200/65"} border rounded-2xl text-xs flex gap-3 text-gray-400 font-sans`} id="insight-box-pnl">
                      <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center bg-emerald-500/10 text-emerald-500 rounded-xl self-start">
                        <Sparkles className="w-4 h-4 animate-pulse" />
                      </div>
                      <div>
                        <span className="font-bold font-mono text-[9px] uppercase tracking-wider block mb-0.5 text-emerald-500">
                          Analytical Insight Projection
                        </span>
                        <p className={`leading-relaxed text-xs ${isDark ? "text-gray-300" : "text-slate-700"}`}>
                          {activeTool.insight}
                        </p>
                      </div>
                    </div>



                    {/* Math Step-by-Step Solver Panel */}
                    {(activeTool.tool_type === "math" || activeTool.id === "date_calculator") && activeTool.id !== "basic_calculator" && activeTool.id !== "scientific_calculator" && (() => {
                      const mathDet = getMathResultDetails(activeTool.id, inputsState, calculatedOutput);
                      if (!mathDet.steps || !mathDet.steps.length) return null;
                      return (
                        <div className={`p-5 rounded-2xl border ${
                          isDark ? "bg-[#1E1E22]/50 border-[#2C2C35]" : "bg-emerald-50/20 border-emerald-100/70"
                        } flex flex-col gap-3.5`} id="math-steps-pnl">
                          <div className="flex items-center gap-2">
                            <div className="w-5 h-5 rounded-md bg-emerald-500/10 text-emerald-500 flex items-center justify-center font-bold text-[10px] font-mono leading-none">
                              ∑
                            </div>
                            <span className="font-bold font-mono text-[10px] uppercase tracking-wider text-emerald-600 block">
                              Step-by-Step Solving Logic
                            </span>
                          </div>
                          
                          <div className="flex flex-col gap-2.5 font-mono text-[11px] leading-relaxed">
                            {mathDet.steps.map((step, idx) => (
                              <div key={idx} className={`p-2.5 rounded-xl border ${
                                isDark ? "bg-[#25252A]/40 border-[#2E2E36] text-gray-300" : "bg-white border-emerald-100/40 text-slate-700"
                              } flex gap-2`}>
                                <div className="text-emerald-500 font-bold select-none">•</div>
                                <div className="whitespace-pre-line">{step}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })()}

                    {/* Custom Alert warnings (e.g. credit debt traps) */}
                    {activeTool.id === "credit_card_debt_calculator" && (() => {
                      const ccBal = Number(inputsState["debt_amount"] ?? 5000);
                      const ccApr = Number(inputsState["interest_rate"] ?? 24.9);
                      const ccPay = Number(inputsState["monthly_payment"] ?? 250);
                      const monthlyCCRate = ccApr / 1200;
                      const minPossiblePay = ccBal * monthlyCCRate;
                      
                      if (ccPay <= minPossiblePay) {
                        return (
                          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs text-center font-bold font-mono leading-relaxed animate-pulse">
                            High Interest Alert: Your monthly payment ({formatValue(ccPay, currency)}) is less than or equal to the monthly interest accrued ({formatValue(minPossiblePay, currency)}). At this rate, your debt will never be paid off and will keep growing compounding! Please increase your monthly payment.
                          </div>
                        );
                      }
                      return null;
                    })()}

                    {activeTool.tool_type === "debt_payoff" && activeTool.id !== "credit_card_debt_calculator" && (() => {
                      const ccBal = inputsState["debt_balance"] || inputsState["balance"] || 1000;
                      const ccApr = inputsState["apr"] || inputsState["rate"] || 22;
                      const ccPay = inputsState["payment"] || 50;
                      const monthlyCCRate = ccApr / 100 / 12;
                      const minPossiblePay = ccBal * monthlyCCRate;
                      
                      if (ccPay <= minPossiblePay) {
                        return (
                          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs text-center font-bold font-mono leading-relaxed animate-pulse">
                            High-Interest Debt Warning: Your monthly payment of {formatValue(ccPay, currency)} is lower than or equal to the accruing monthly interest of {formatValue(minPossiblePay, currency)}. Your balance will escalate indefinitely under this payment yield! Increase your monthly payment.
                          </div>
                        );
                      }
                      return null;
                    })()}

                  </div>

                </div>

                {/* Premium full-width horizontal Amortization/Paydown schedule en alta yatay */}
                {(() => {
                  const schedule = generateAmortizationSchedule(activeTool, inputsState);
                  if (!schedule) return null;
                  return (
                    <PaymentScheduleSection 
                      schedule={schedule} 
                      isDark={isDark} 
                      activeTool={activeTool} 
                      schedulePeriodType={schedulePeriodType}
                      setSchedulePeriodType={setSchedulePeriodType}
                    />
                  );
                })()}

                {/* FAQ section custom tailored for each calculator */}
                <FaqSection 
                  activeTool={activeTool} 
                  isDark={isDark} 
                  lang={lang} 
                />

              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 9. Direct Categorized Tree Catalogue View */}
        {!activeTool && (
          <div className="w-full mt-6" id="empty-state-ghost-container">
            <div className="text-center mb-6" id="catalog-title">
              <h3 className="text-xs font-sans font-bold text-slate-500 dark:text-gray-400 uppercase tracking-widest flex items-center justify-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
                {t.suggestionsTitle}
              </h3>
            </div>
            
            {/* Direct catalog with state selection filtering, passing matching search parameters */}
            <GhostPreviews 
              onSelectGhost={handleGhostSelect} 
              searchTerm={confirmedQuery} 
              theme={theme}
              lang={lang}
            />
          </div>
        )}

      </main>

      {/* 3. Global Footer credits */}
      <footer className={`text-center py-6 border-t ${isDark ? "border-stone-900" : "border-slate-200"} mt-12 px-4`} id="global-footer">
        <p className="text-[10px] text-gray-500 tracking-widest font-mono uppercase">
          © 2026 calculator • High-Precision Interactive Calculators & Analytical Visualizers.
        </p>
      </footer>

      {/* 4. Elegant, Soft Backdrop Fade & Blur Theme Transition (60 FPS fluid) */}
      <AnimatePresence>
        {isWaveActive && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25, ease: "easeInOut" }}
            style={{ willChange: "opacity" }}
            className={`fixed inset-0 z-[999999] pointer-events-none ${
              theme === "dark" ? "bg-black/35" : "bg-white/35"
            } backdrop-blur-xs`}
          />
        )}
      </AnimatePresence>

    </div>
  );
}
