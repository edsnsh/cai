import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { CalculatorTool } from "../types";
import { getFaqsForTool, FaqItem } from "../data/faqData";

interface FaqSectionProps {
  activeTool: CalculatorTool;
  isDark: boolean;
  lang?: string;
}

export default function FaqSection({ activeTool, isDark, lang = "en" }: FaqSectionProps) {
  // Fetch FAQs for current calculator (4-6 items)
  const faqs: FaqItem[] = getFaqsForTool(activeTool);

  // Expanded items state (first FAQ open by default)
  const [openIndices, setOpenIndices] = useState<number[]>([0]);

  const toggleItem = (index: number) => {
    setOpenIndices((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  const isTurkish = lang === "tr";

  return (
    <div
      className="w-full mt-12 transition-all duration-300 relative"
      id="faq-section-wrapper"
    >
      {/* 1. Header Section - Small Green Calculator Name & FAQ Title */}
      <div className="text-center mb-8">
        <span
          className="text-xs sm:text-sm font-mono font-bold text-emerald-500 dark:text-emerald-400 tracking-[0.2em] uppercase block mb-1.5"
          id="faq-eyebrow"
        >
          {activeTool.title ? activeTool.title : "CALCULATOR"}
        </span>

        <h3
          className={`text-2xl sm:text-3xl font-black tracking-tight font-sans uppercase ${
            isDark ? "text-white" : "text-slate-900"
          }`}
          id="faq-main-title"
        >
          {isTurkish ? "SSS" : "FAQ"}
        </h3>
      </div>

      {/* 2. Accordion List */}
      <div className={`flex flex-col border-t ${isDark ? "border-[#2C2C35]" : "border-slate-200"}`} id="faq-accordion-list">
        {faqs.map((faq, idx) => {
          const isOpen = openIndices.includes(idx);

          return (
            <div
              key={idx}
              className={`border-b transition-colors ${
                isDark ? "border-[#2C2C35]" : "border-slate-200"
              }`}
            >
              {/* Question Row */}
              <button
                onClick={() => toggleItem(idx)}
                className="w-full py-4 sm:py-5 flex items-center justify-between text-left group cursor-pointer focus:outline-none select-none gap-4"
                aria-expanded={isOpen}
              >
                <span
                  className={`text-sm sm:text-base font-bold font-sans transition-colors leading-snug ${
                    isDark
                      ? "text-gray-100 group-hover:text-emerald-400"
                      : "text-slate-800 group-hover:text-emerald-600"
                  }`}
                >
                  {faq.question}
                </span>

                {/* Plus / Minus Indicator Icon */}
                <div
                  className={`w-6 h-6 flex items-center justify-center text-lg font-mono font-bold flex-shrink-0 transition-transform ${
                    isDark ? "text-gray-300" : "text-slate-800"
                  }`}
                >
                  {isOpen ? "−" : "+"}
                </div>
              </button>

              {/* Answer Expansion Panel */}
              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.22, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <div className={`pb-5 pt-1 text-xs sm:text-sm leading-relaxed font-sans font-medium ${
                      isDark ? "text-gray-300" : "text-slate-600"
                    }`}>
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
}
