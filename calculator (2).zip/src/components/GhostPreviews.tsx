import React, { useState } from "react";
import { CalculatorTool } from "../types";
import { PREDEFINED_CALCULATORS } from "../data/predefinedCalcs";
import { 
  DollarSign, 
  Sparkles,
  Heart,
  Clock,
  Calculator
} from "lucide-react";
import { GROUP_LABELS_ALL, CALC_LOCALE_MAP_ALL } from "../data/translations";

interface GhostPreviewsProps {
  onSelectGhost: (tool: CalculatorTool) => void;
  searchTerm?: string;
  theme: "light" | "dark";
  lang?: "en" | "tr" | "es" | "de" | "fr" | "it";
}

const CALCULATOR_GROUPS = [
  {
    id: "finance",
    label: "Finance",
    icon: DollarSign,
    color: "text-emerald-500 border-emerald-500/20 bg-emerald-500/5",
    subgroups: [
      {
        title: "Mortgages & Housing",
        items: [
          "Mortgage Calculator",
          "House Loan Calculator"
        ]
      },
      {
        title: "Vehicle & Consumer Loans",
        items: [
          "Car Loan Calculator",
          "Loan Calculator",
          "Payment Calculator"
        ]
      },
      {
        title: "Investments & Retirement",
        items: [
          "Invest Calculator",
          "Interest Calculator",
          "Retirement Calculator",
          "Inflation Calculator"
        ]
      },
      {
        title: "Tax & Budgeting",
        items: [
          "Tax Calculator",
          "50/30/20 Calculator"
        ]
      }
    ]
  },
  {
    id: "math_utilities",
    label: "Mathematics",
    icon: Calculator,
    color: "text-blue-500 border-blue-500/20 bg-blue-500/5",
    subgroups: [
      {
        title: "General & Scientific Math",
        items: [
          "Basic Calculator",
          "Scientific Calculator",
          "Grade Calculator",
          "Speed Calculator"
        ]
      }
    ]
  },
  {
    id: "health_fitness",
    label: "Health",
    icon: Heart,
    color: "text-rose-500 border-rose-500/20 bg-rose-500/5",
    subgroups: [
      {
        title: "Body Metrics",
        items: [
          "BMI Calculator",
          "Body Fat Calculator",
          "Height Calculator",
          "Weight Calculator"
        ]
      },
      {
        title: "Nutrition & Energy",
        items: [
          "BMR Calculator",
          "Calorie Calculator",
          "Carbohydrate Calculator",
          "Protein Calculator"
        ]
      }
    ]
  },
  {
    id: "time_date",
    label: "Others",
    icon: Clock,
    color: "text-amber-500 border-amber-500/20 bg-amber-500/5",
    subgroups: [
      {
        title: "Time & Date",
        items: [
          "Time Calculator",
          "Date Calculator",
          "Timecard Calculator",
          "Age Calculator"
        ]
      }
    ]
  }
];

export default function GhostPreviews({ onSelectGhost, searchTerm = "", theme, lang = "en" }: GhostPreviewsProps) {
  const [filterText] = useState<string>("");

  const activeSearch = searchTerm || filterText;
  const isDark = theme === "dark";

  const handleItemClick = (itemName: string) => {
    // Dynamic match in PREDEFINED_CALCULATORS dataset
    const matchedTool = PREDEFINED_CALCULATORS.find((c) => 
      c.title.toLowerCase() === itemName.toLowerCase() ||
      c.id.toLowerCase() === itemName.toLowerCase().replace(/ /g, "_")
    );
    if (matchedTool) {
      onSelectGhost(matchedTool);
    }
  };

  const getTranslatedLabel = (enLabel: string) => {
    const groupMap = GROUP_LABELS_ALL[lang || "en"];
    if (groupMap && groupMap[enLabel]) {
      return groupMap[enLabel];
    }
    return enLabel;
  };

  const getTranslatedItem = (enItemName: string) => {
    const itemMap = CALC_LOCALE_MAP_ALL[lang || "en"];
    if (itemMap && itemMap[enItemName]) {
      return itemMap[enItemName].title;
    }
    return enItemName;
  };

  const renderSubgroupCard = (sub: { title: string; items: string[] }, key: number | string) => (
    <div 
      key={key} 
      className={`p-5 rounded-3xl border transition-all h-fit ${
        isDark 
          ? "bg-[#1E1E22]/50 border-[#2C2C35] hover:border-[#2E2E36]" 
          : "bg-white border-slate-200 hover:border-slate-350 shadow-xs hover:shadow-xs"
      }`}
    >
      <h4 className={`text-[11px] font-mono font-bold uppercase tracking-widest mb-3.5 border-b pb-2 ${
        isDark ? "text-gray-400 border-[#2E2E36]" : "text-slate-500 border-slate-200"
      }`}>
        {getTranslatedLabel(sub.title)}
      </h4>
      
      <div className="flex flex-wrap gap-1.5">
        {sub.items.map((item, itemIdx) => (
          <button
            key={itemIdx}
            onClick={() => handleItemClick(item)}
            className={`text-xs font-medium px-3 py-2 rounded-xl transition-all border ${
              isDark 
                ? "bg-[#25252A] border-[#2E2E36] text-gray-300 hover:border-[#00FF87]/60 hover:text-[#00FF87]" 
                : "bg-slate-50 border-slate-200 text-slate-700 hover:border-[#10B981] hover:text-[#10B981] hover:bg-white"
            }`}
          >
            {getTranslatedItem(item)}
          </button>
        ))}
      </div>
    </div>
  );

  const renderSingleGroupSection = (group: typeof CALCULATOR_GROUPS[0]) => {
    const matchedSubgroups = group.subgroups.map((sub) => {
      const matchedItems = sub.items.filter((item) => {
        const localizedItem = getTranslatedItem(item);
        return item.toLowerCase().includes(activeSearch.toLowerCase()) || 
               localizedItem.toLowerCase().includes(activeSearch.toLowerCase());
      });
      return { ...sub, items: matchedItems };
    }).filter((sub) => sub.items.length > 0);

    if (matchedSubgroups.length === 0) return null;

    const col1 = matchedSubgroups.filter((_, idx) => idx % 2 === 0);
    const col2 = matchedSubgroups.filter((_, idx) => idx % 2 === 1);

    return (
      <div key={group.id} className="mb-8 font-sans animate-fade-in" id={`catalog-group-${group.id}`}>
        {/* Group Title */}
        <div className="flex items-center gap-2 mb-4 justify-center md:justify-start" id="catalog-group-title">
          <span className={`px-3.5 py-1.5 rounded-full text-xs font-bold border flex items-center gap-2 ${
            isDark 
              ? "bg-[#25252A]/40 border-[#2C2C35] " + group.color
              : "bg-white border-slate-200 shadow-xs " + group.color
          }`}>
            <group.icon className="w-4 h-4" />
            {getTranslatedLabel(group.label)}
          </span>
          <span className={`h-[1px] flex-grow hidden md:block ${isDark ? "bg-[#2C2C35]" : "bg-slate-200"}`}></span>
        </div>

        {/* Masonry Columns of Sub-groups */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-start" id="catalog-subgroups-grid">
          <div className="flex flex-col gap-5">
            {col1.map((sub, sIdx) => renderSubgroupCard(sub, `col1-${sIdx}`))}
          </div>
          {col2.length > 0 && (
            <div className="flex flex-col gap-5">
              {col2.map((sub, sIdx) => renderSubgroupCard(sub, `col2-${sIdx}`))}
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderPairedGroupsRow = (leftGroup: typeof CALCULATOR_GROUPS[0], rightGroup: typeof CALCULATOR_GROUPS[0]) => {
    const leftMatched = leftGroup.subgroups.map((sub) => {
      const matchedItems = sub.items.filter((item) => {
        const localizedItem = getTranslatedItem(item);
        return item.toLowerCase().includes(activeSearch.toLowerCase()) || 
               localizedItem.toLowerCase().includes(activeSearch.toLowerCase());
      });
      return { ...sub, items: matchedItems };
    }).filter((sub) => sub.items.length > 0);

    const rightMatched = rightGroup.subgroups.map((sub) => {
      const matchedItems = sub.items.filter((item) => {
        const localizedItem = getTranslatedItem(item);
        return item.toLowerCase().includes(activeSearch.toLowerCase()) || 
               localizedItem.toLowerCase().includes(activeSearch.toLowerCase());
      });
      return { ...sub, items: matchedItems };
    }).filter((sub) => sub.items.length > 0);

    if (leftMatched.length === 0 && rightMatched.length === 0) return null;

    return (
      <div key={`${leftGroup.id}-${rightGroup.id}`} className="mb-8 font-sans animate-fade-in">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-start">
          {/* Left Column (e.g. Mathematics) */}
          {leftMatched.length > 0 ? (
            <div className="flex flex-col" id={`catalog-group-${leftGroup.id}`}>
              <div className="flex items-center gap-2 mb-4 justify-center md:justify-start">
                <span className={`px-3.5 py-1.5 rounded-full text-xs font-bold border flex items-center gap-2 ${
                  isDark 
                    ? "bg-[#25252A]/40 border-[#2C2C35] " + leftGroup.color
                    : "bg-white border-slate-200 shadow-xs " + leftGroup.color
                }`}>
                  <leftGroup.icon className="w-4 h-4" />
                  {getTranslatedLabel(leftGroup.label)}
                </span>
                <span className={`h-[1px] flex-grow hidden md:block ${isDark ? "bg-[#2C2C35]" : "bg-slate-200"}`}></span>
              </div>
              <div className="flex flex-col gap-5">
                {leftMatched.map((sub, sIdx) => renderSubgroupCard(sub, `left-${sIdx}`))}
              </div>
            </div>
          ) : <div />}

          {/* Right Column (e.g. Others) */}
          {rightMatched.length > 0 ? (
            <div className="flex flex-col" id={`catalog-group-${rightGroup.id}`}>
              <div className="flex items-center gap-2 mb-4 justify-center md:justify-start">
                <span className={`px-3.5 py-1.5 rounded-full text-xs font-bold border flex items-center gap-2 ${
                  isDark 
                    ? "bg-[#25252A]/40 border-[#2C2C35] " + rightGroup.color
                    : "bg-white border-slate-200 shadow-xs " + rightGroup.color
                }`}>
                  <rightGroup.icon className="w-4 h-4" />
                  {getTranslatedLabel(rightGroup.label)}
                </span>
                <span className={`h-[1px] flex-grow hidden md:block ${isDark ? "bg-[#2C2C35]" : "bg-slate-200"}`}></span>
              </div>
              <div className="flex flex-col gap-5">
                {rightMatched.map((sub, sIdx) => renderSubgroupCard(sub, `right-${sIdx}`))}
              </div>
            </div>
          ) : <div />}
        </div>
      </div>
    );
  };

  const financeGroup = CALCULATOR_GROUPS.find((g) => g.id === "finance");
  const mathGroup = CALCULATOR_GROUPS.find((g) => g.id === "math_utilities");
  const healthGroup = CALCULATOR_GROUPS.find((g) => g.id === "health_fitness");
  const othersGroup = CALCULATOR_GROUPS.find((g) => g.id === "time_date");

  return (
    <div className="w-full flex flex-col gap-6" id="calculator-catalog-root">
      
      <div className="w-full flex flex-col gap-8" id="catalog-lists-container">
        {financeGroup && renderSingleGroupSection(financeGroup)}
        {mathGroup && othersGroup && renderPairedGroupsRow(mathGroup, othersGroup)}
        {healthGroup && renderSingleGroupSection(healthGroup)}

        {/* Empty search fallback */}
        {activeSearch && CALCULATOR_GROUPS.every((g) => 
          g.subgroups.every((s) => s.items.filter((item) => {
            const localizedItem = getTranslatedItem(item);
            return item.toLowerCase().includes(activeSearch.toLowerCase()) || 
                   localizedItem.toLowerCase().includes(activeSearch.toLowerCase());
          }).length === 0)
        ) && (
          <div className={`text-center py-10 px-4 rounded-3xl border border-dashed ${
            isDark ? "bg-[#1E1E22]/30 border-[#2C2C35]" : "bg-slate-50 border-slate-250 text-slate-800"
          }`} id="catalog-empty-search">
            <Sparkles className={`w-8 h-8 mx-auto mb-3 animate-bounce ${isDark ? "text-[#00FF87]" : "text-[#10B981]"}`} />
            <h4 className="text-sm font-bold mb-1">{getTranslatedLabel("Discover Custom Calculator")}</h4>
            <p className={`text-xs max-w-sm mx-auto ${isDark ? "text-gray-400" : "text-slate-500"}`}>
              {getTranslatedLabel("Use the search bar to find or generate customized calculators dynamically.")}
            </p>
          </div>
        )}
      </div>

    </div>
  );
}
