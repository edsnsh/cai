import React from "react";
import { Check } from "lucide-react";

export interface DataInputCardProps {
  /** 1. Sol Üst (Label / Başlık): Kutunun üzerindeki ana başlık (Örn: ANNUAL INTEREST RATE) */
  label?: string;
  topLeftLabel?: string;

  /** 2. Sağ Üst (Badge / Etiket): Kutu üzerindeki sağdaki rozet içindeki dinamik özet/etiket (Örn: APR %, %, $, years) */
  badge?: string;
  topRightBadge?: string;

  /** 3. Sol Alt (Input Value / Girdi Değeri): Input kutusunun içindeki kullanıcının girdiği/seçtiği değer (Örn: 0) */
  value?: string | number;
  bottomLeftValue?: string | number;

  /** 4. Sağ Alt (Suffix / Birim): Input kutusunun içindeki sağda duran birim yazısı (Varsayılan: Boş) */
  suffix?: string;
  bottomRightSuffix?: string;

  /** İsteğe bağlı önek (Örn: $) */
  prefix?: string;

  /** Girdi tipi */
  type?: "number" | "slider" | "select" | "text" | "date" | "checkbox";

  /** Select tipi için seçenekler listesi */
  options?: string[];

  /** Sayısal sınırlar */
  min?: number;
  max?: number;
  step?: number;

  /** Görsel ve yerleşim durumları */
  id?: string;
  isDark?: boolean;
  isChild?: boolean;
  disabled?: boolean;
  className?: string;

  /** Değer değişim olayı */
  onChange?: (val: any) => void;
}

export function expandBadgeText(text: string): string {
  if (!text) return "";
  const trimmed = text.trim();

  // Dictionary for direct match replacements (case-insensitive)
  const map: Record<string, string> = {
    "hrs": "Hours",
    "hr": "Hours",
    "hours": "Hours",
    "hour": "Hours",
    "mins": "Minutes",
    "min": "Minutes",
    "minutes": "Minutes",
    "minute": "Minutes",
    "secs": "Seconds",
    "sec": "Seconds",
    "seconds": "Seconds",
    "second": "Seconds",
    "mo": "Months",
    "mos": "Months",
    "months": "Months",
    "month": "Months",
    "yrs": "Years",
    "yr": "Years",
    "years": "Years",
    "year": "Years",
    "wks": "Weeks",
    "wk": "Weeks",
    "weeks": "Weeks",
    "week": "Weeks",
    "days": "Days",
    "day": "Days",
    "mins/day": "Minutes / Day",
    "min/day": "Minutes / Day",
    "kg/wk": "Kilograms / Week",
    "times/yr": "Times / Year",
    "times/year": "Times / Year",
    "kcal": "Calories",
    "kcal/day": "Calories / Day",
    "cal": "Calories",
    "pct": "Percent",
    "pct %": "Percent (%)",
    "apr %": "APR %",
    "apr": "APR %",
    "apy %": "APY %",
    "apy": "APY",
    "cagr": "CAGR",
    "roi": "ROI",
    "bmi": "BMI",
    "g": "Grams",
    "lbs": "Pounds",
    "lb": "Pounds",
    "km/h": "km/h",
    "mph": "mph",
    "cm": "cm",
    "kg": "kg"
  };

  const lower = trimmed.toLowerCase();
  if (map[lower]) {
    return map[lower];
  }

  // Word-by-word replacement in compound expressions
  return trimmed
    .replace(/\bhrs\b/gi, "Hours")
    .replace(/\bhr\b/gi, "Hours")
    .replace(/\bmins\b/gi, "Minutes")
    .replace(/\bmin\b/gi, "Minutes")
    .replace(/\bsecs\b/gi, "Seconds")
    .replace(/\bsec\b/gi, "Seconds")
    .replace(/\bmos\b/gi, "Months")
    .replace(/\bmo\b/gi, "Months")
    .replace(/\byrs\b/gi, "Years")
    .replace(/\byr\b/gi, "Years")
    .replace(/\bwks\b/gi, "Weeks")
    .replace(/\bwk\b/gi, "Weeks")
    .replace(/\bpct\b/gi, "Percent");
}

export const DataInputCard: React.FC<DataInputCardProps> = ({
  label,
  topLeftLabel,
  badge,
  topRightBadge,
  value,
  bottomLeftValue,
  suffix,
  bottomRightSuffix,
  prefix,
  type = "number",
  options = ["10", "15", "20", "30"],
  min = 0,
  max = 10000000,
  step = 1,
  id,
  isDark = true,
  isChild = false,
  disabled = false,
  className = "",
  onChange,
}) => {
  // Parantez veya tire içindeki birim/etiketi ayıkla (Örn: "Annual Interest Rate (APR %)" -> "Annual Interest Rate" & "APR %")
  const rawLabel = label || "";
  const matchParentheses = rawLabel.match(/\(([^)]+)\)/);
  let extractedTag = matchParentheses ? matchParentheses[1].trim() : "";
  let cleanLabel = rawLabel.replace(/\s*\([^)]*\)/g, "").trim();

  // Parantez yoksa ama sonda " - Hours" gibi tire ayracı varsa ayıkla
  if (!extractedTag) {
    const dashMatch = cleanLabel.match(/^(.*?)\s*-\s*([A-Za-z0-9%$/]+)$/);
    if (dashMatch) {
      cleanLabel = dashMatch[1].trim();
      extractedTag = dashMatch[2].trim();
    }
  }

  // 1. Sol Üst Alan: Temiz Başlık / Label (Örn: ANNUAL INTEREST RATE)
  const displayLabel = topLeftLabel ?? (cleanLabel || rawLabel || "INPUT LABEL");

  // 2. Sağ Üst Alan: Badge / Rozet Etiketi (Kısaltmasız tam kelime Örn: APR %, Hours, Months, Years, %)
  const rawBadge =
    topRightBadge !== undefined
      ? topRightBadge
      : badge !== undefined
      ? badge
      : extractedTag
      ? extractedTag
      : suffix
      ? suffix.trim()
      : prefix
      ? prefix.trim()
      : "";

  const displayBadge = expandBadgeText(rawBadge);

  // 3. Sol Alt Alan: Değer / Input Value (Kullanıcının girdiği veri)
  const rawValue = bottomLeftValue !== undefined ? bottomLeftValue : (value !== undefined ? value : 0);
  const displayValue = rawValue === "" ? "" : rawValue;

  // 4. Sağ Alt Alan: Birim / Suffix (İstenildiği üzere varsayılan olarak BOŞ)
  const displaySuffix = bottomRightSuffix !== undefined ? bottomRightSuffix : "";

  const boxBg = isDark ? "bg-[#141417] border-[#222226]" : "bg-white border-slate-200 shadow-sm";
  const selectBg = isDark ? "bg-[#1E1E22] border-[#2C2C35] text-white" : "bg-slate-50 border-slate-200 text-slate-800";
  const textTitle = isDark ? "text-white" : "text-slate-900";

  // Checkbox varyantı
  if (type === "checkbox") {
    const isChecked = Number(displayValue) === 1 || displayValue === true || displayValue === "true";
    return (
      <div
        id={id ? `card-${id}` : undefined}
        style={{ marginLeft: isChild ? "16px" : "0px" }}
        className={`p-4 rounded-xl flex items-center gap-3 border transition-all duration-200 ${
          isDark
            ? "bg-[#1E1E22]/50 border-[#2C2C35] hover:border-[#2E2E36]"
            : "bg-slate-50 border-slate-200 hover:border-slate-300 shadow-xs"
        } ${isChild ? "border-dashed" : ""} ${className}`}
      >
        <label className="flex items-center gap-3 cursor-pointer select-none text-xs font-bold leading-none w-full">
          <div className="relative">
            <input
              type="checkbox"
              id={id ? `input-checkbox-${id}` : undefined}
              checked={isChecked}
              disabled={disabled}
              onChange={(e) => {
                onChange?.(e.target.checked ? 1 : 0);
              }}
              className="sr-only"
            />
            <div
              className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center transition-all duration-200 ${
                isChecked
                  ? "bg-[#10B981] border-[#10B981] shadow-[0_0_8px_rgba(16,185,129,0.35)]"
                  : "bg-transparent border-gray-400 dark:border-neutral-700"
              }`}
            >
              {isChecked && <Check className="w-3.5 h-3.5 text-white stroke-[3.5]" />}
            </div>
          </div>
          <span
            className={
              isDark
                ? "text-gray-300 font-mono text-[10px] font-bold tracking-wide uppercase"
                : "text-slate-800 font-mono text-[10px] font-bold tracking-wide uppercase"
            }
          >
            {displayLabel}
          </span>
        </label>
      </div>
    );
  }

  return (
    <div
      id={id ? `card-${id}` : undefined}
      style={{ marginLeft: isChild ? "16px" : "0px" }}
      className={`${boxBg} rounded-2xl p-4 flex flex-col justify-between border hover:border-neutral-500 dark:hover:border-neutral-700 transition-colors duration-250 ${
        isChild ? "border-dashed" : ""
      } ${className}`}
    >
      {/* Üst Satır: [Sol Üst: Label / Başlık] - [Sağ Üst: Dinamik Badge / Etiket] */}
      <div className="flex justify-between items-center mb-2 gap-2">
        {/* 1. Sol Üst: Label / Başlık */}
        <label
          htmlFor={id ? `input-${id}` : undefined}
          className="text-[9.5px] uppercase font-mono tracking-widest text-neutral-500 dark:text-gray-400 font-extrabold pr-2 truncate"
        >
          {isChild ? "• " : ""}
          {displayLabel}
        </label>

        {/* 2. Sağ Üst: Badge / Dinamik Özet Değer */}
        <span
          className={`text-[11px] font-black ${textTitle} font-mono bg-neutral-200/50 dark:bg-neutral-800/80 px-2 py-0.5 rounded-lg shrink-0 border border-black/5 dark:border-white/5`}
        >
          {displayBadge}
        </span>
      </div>

      {/* Alt Satır: [Sol Alt: Girdi Değeri / Input Value] - [Sağ Alt: Suffix / Birim] */}
      {type === "slider" || type === "number" ? (
        <div
          className={`relative mt-1 flex items-center border rounded-xl px-2.5 transition duration-200 ${
            isDark
              ? "bg-[#1E1E22] border-[#2C2C35] hover:border-neutral-700 focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500"
              : "bg-white border-slate-200 hover:border-slate-300 focus-within:border-emerald-600 focus-within:ring-1 focus-within:ring-emerald-500/20 shadow-xs"
          }`}
        >
          {prefix && (
            <span className="text-xs text-gray-400 font-semibold font-mono pr-1 select-none shrink-0">
              {prefix}
            </span>
          )}

          {/* 3. Sol Alt: Girdi Değeri */}
          <input
            id={id ? `input-${id}` : undefined}
            type="number"
            value={displayValue}
            min={min}
            max={max}
            step={step}
            disabled={disabled}
            onChange={(e) => {
              const val = e.target.value === "" ? "" : isNaN(Number(e.target.value)) ? 0 : Number(e.target.value);
              onChange?.(val);
            }}
            className={`w-full bg-transparent border-none py-2 text-xs focus:outline-none font-mono ${
              isDark ? "text-white" : "text-slate-800"
            }`}
          />

          {/* 4. Sağ Alt: Suffix / Birim */}
          {displaySuffix && (
            <span className="text-xs text-gray-400 font-mono pl-1 select-none shrink-0 opacity-80">
              {displaySuffix}
            </span>
          )}
        </div>
      ) : type === "select" ? (
        <div className="relative mt-1">
          {/* 3. Sol Alt & 4. Sağ Alt: Seçim kutusu ve sağındaki birim */}
          <select
            id={id ? `input-${id}` : undefined}
            value={displayValue}
            disabled={disabled}
            onChange={(e) => {
              const val = isNaN(Number(e.target.value)) ? e.target.value : Number(e.target.value);
              onChange?.(val);
            }}
            className={`w-full ${selectBg} rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none appearance-none border font-mono`}
          >
            {options.map((opt) => (
              <option key={opt} value={opt}>
                {opt} {displaySuffix ? displaySuffix.trim() : ""}
              </option>
            ))}
          </select>
          <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-[10px]">
            ▼
          </div>
        </div>
      ) : type === "date" ? (
        <div
          className={`relative mt-1 flex items-center border rounded-xl px-2.5 ${
            isDark ? "bg-[#1E1E22] border-[#2C2C35]" : "bg-white border-slate-200 shadow-xs"
          }`}
        >
          {/* 3. Sol Alt: Tarih Girdi Değeri */}
          <input
            id={id ? `input-${id}` : undefined}
            type="date"
            value={displayValue ? String(displayValue) : ""}
            disabled={disabled}
            onChange={(e) => {
              onChange?.(e.target.value);
            }}
            className={`w-full bg-transparent border-none py-2 text-xs focus:outline-none font-sans ${
              isDark ? "text-white" : "text-slate-800"
            }`}
          />
          {/* 4. Sağ Alt: Suffix / Birim */}
          {displaySuffix && (
            <span className="text-xs text-gray-400 font-mono pl-1 select-none shrink-0 opacity-80">
              {displaySuffix}
            </span>
          )}
        </div>
      ) : (
        /* Text varyantı */
        <div
          className={`relative mt-1 flex items-center border rounded-xl px-2.5 ${
            isDark ? "bg-[#1E1E22] border-[#2C2C35]" : "bg-white border-slate-200 shadow-xs"
          }`}
        >
          {prefix && (
            <span className="text-xs text-gray-400 font-semibold font-mono pr-1 select-none shrink-0">
              {prefix}
            </span>
          )}
          {/* 3. Sol Alt: Metin Girdi Değeri */}
          <input
            id={id ? `input-${id}` : undefined}
            type="text"
            value={displayValue}
            disabled={disabled}
            onChange={(e) => {
              onChange?.(e.target.value);
            }}
            className={`w-full bg-transparent border-none py-2 text-xs focus:outline-none font-mono ${
              isDark ? "text-white" : "text-slate-800"
            }`}
          />
          {/* 4. Sağ Alt: Suffix / Birim */}
          {displaySuffix && (
            <span className="text-xs text-gray-400 font-mono pl-1 select-none shrink-0 opacity-80">
              {displaySuffix}
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default DataInputCard;
