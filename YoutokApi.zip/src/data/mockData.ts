import { VideoMetadata } from '../types';

export const SAMPLE_VIDEOS: VideoMetadata[] = [
  {
    id: 'yt-4k-nature',
    title: 'Costa Rica in 4K 60fps HDR (Ultra HD) - Wildlife and Rainforests',
    platform: 'youtube',
    url: 'https://www.youtube.com/watch?v=LXb3EKWsInQ',
    thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
    duration: '05:42',
    author: 'Nature Relaxation 4K',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    views: '14.2M views',
    formats: [
      { id: 'f-4k', type: 'video', quality: '4K Ultra HD (2160p)', resolution: '2160p (3840x2160)', format: 'mp4', size: '482 MB', fps: 60, hasAudio: true },
      { id: 'f-2k', type: 'video', quality: '2K Quad HD', resolution: '1440p (2560x1440)', format: 'mp4', size: '264 MB', fps: 60, hasAudio: true },
      { id: 'f-1080', type: 'video', quality: '1080p Full HD', resolution: '1080p (1920x1080)', format: 'mp4', size: '138 MB', fps: 60, hasAudio: true },
      { id: 'f-720', type: 'video', quality: '720p HD', resolution: '720p (1280x720)', format: 'mp4', size: '64 MB', fps: 30, hasAudio: true },
      { id: 'f-480', type: 'video', quality: '480p SD', resolution: '480p (854x480)', format: 'mp4', size: '28 MB', fps: 30, hasAudio: true },
      { id: 'f-mp3-320', type: 'audio', quality: 'Ultra High Quality (Dubbed MP3)', bitrate: '320 kbps', format: 'mp3', size: '13.8 MB' },
      { id: 'f-mp3-192', type: 'audio', quality: 'Standard Quality Audio', bitrate: '192 kbps', format: 'mp3', size: '8.2 MB' },
      { id: 'f-m4a', type: 'audio', quality: 'Lossless AAC Audio', bitrate: '256 kbps', format: 'm4a', size: '10.5 MB' }
    ],
    subtitles: [
      { lang: 'en', label: 'English (Original Subtitles)' },
      { lang: 'es', label: 'Spanish' },
      { lang: 'fr', label: 'French' },
      { lang: 'de', label: 'German' }
    ]
  },
  {
    id: 'tt-viral-dance',
    title: 'Trending Shuffle Dance Tutorial #dance #viral #tutorial #trending',
    platform: 'tiktok',
    url: 'https://www.tiktok.com/@dancetrends/video/739182948192841',
    thumbnail: 'https://images.unsplash.com/photo-1547153760-18fc86324498?auto=format&fit=crop&w=800&q=80',
    duration: '00:45',
    author: '@dancetrends.official',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=120&q=80',
    views: '8.9M views',
    isTikTok: true,
    formats: [
      { id: 'tt-nowatermark-hd', type: 'video', quality: 'No Watermark HD (1080p)', resolution: '1080p (1080x1920)', format: 'mp4', size: '14.2 MB', watermarkFree: true, hasAudio: true },
      { id: 'tt-nowatermark-sd', type: 'video', quality: 'No Watermark SD (720p)', resolution: '720p (720x1280)', format: 'mp4', size: '8.4 MB', watermarkFree: true, hasAudio: true },
      { id: 'tt-watermark', type: 'video', quality: 'Original (With Watermark)', resolution: '1080p', format: 'mp4', size: '14.6 MB', watermarkFree: false, hasAudio: true },
      { id: 'tt-audio', type: 'audio', quality: 'Original TikTok Audio (MP3 320k)', bitrate: '320 kbps', format: 'mp3', size: '1.8 MB' }
    ]
  },
  {
    id: 'yt-shorts-cooking',
    title: 'Crispy Garlic Butter Smash Burger in 60 Seconds! 🍔🔥 #shorts #food',
    platform: 'youtube',
    url: 'https://www.youtube.com/shorts/k93pL2oW9xA',
    thumbnail: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80',
    duration: '00:58',
    author: 'Chef Reactions & Bites',
    authorAvatar: 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=120&q=80',
    views: '3.4M views',
    isShort: true,
    formats: [
      { id: 'f-s-1080', type: 'video', quality: 'Shorts 1080p Full HD (60fps)', resolution: '1080p', format: 'mp4', size: '18.5 MB', fps: 60, hasAudio: true },
      { id: 'f-s-720', type: 'video', quality: 'Shorts 720p HD', resolution: '720p', format: 'mp4', size: '9.2 MB', fps: 30, hasAudio: true },
      { id: 'f-s-mp3', type: 'audio', quality: 'Shorts Audio Only (MP3 320k)', bitrate: '320 kbps', format: 'mp3', size: '2.1 MB' }
    ]
  },
  {
    id: 'tt-acoustic-cover',
    title: 'Viral TikTok Sound & Acoustic Guitar Cover #music #tiktok #trending',
    platform: 'tiktok',
    url: 'https://www.tiktok.com/@soundhub/video/739182948199999',
    thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
    duration: '01:10',
    author: '@soundhub.viral',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    views: '4.2M views',
    isTikTok: true,
    formats: [
      { id: 'tt-hd-2', type: 'video', quality: 'No Watermark HD (1080p)', resolution: '1080p', format: 'mp4', size: '22.1 MB', watermarkFree: true, hasAudio: true },
      { id: 'tt-sd-2', type: 'video', quality: 'No Watermark SD (720p)', resolution: '720p', format: 'mp4', size: '11.4 MB', watermarkFree: true, hasAudio: true },
      { id: 'tt-audio-2', type: 'audio', quality: 'TikTok Sound Track (MP3 320kbps)', bitrate: '320 kbps', format: 'mp3', size: '2.8 MB' }
    ]
  }
];

export const FAQ_LIST = [
  {
    id: 'faq-1',
    question: 'Best YouTube & TikTok Downloader Online?',
    answer: '4K Video Downloader Plus is the best free online YouTube & TikTok video downloader. Download YouTube videos, YouTube Shorts, and TikTok videos without watermark in 4K and 1080p HD quality. Fast, free, and works on all devices in Europe.'
  },
  {
    id: 'faq-2',
    question: 'Download YouTube & TikTok 4K Videos?',
    answer: 'Yes, you can download YouTube & TikTok videos in 4K, 1080p and HD. Just paste the YouTube or TikTok link into 4K Video Downloader Plus and select your quality. We support full HD TikTok downloads without watermark and 4K YouTube downloads.'
  },
  {
    id: 'faq-3',
    question: 'How To Download TikTok & YouTube MP3?',
    answer: 'Use 4K Video Downloader Plus as a YouTube to MP3 and TikTok MP3 downloader. Paste any YouTube & TikTok link and choose MP3 or M4A format up to 320kbps. Instantly convert and download YouTube MP3 and TikTok sounds for offline listening.'
  },
  {
    id: 'faq-4',
    question: 'Is YouTube & TikTok Downloader Free?',
    answer: 'Yes, 100% free and unlimited. 4K Video Downloader Plus lets you download unlimited YouTube & TikTok videos, MP3s and images with no limit, no registration and no fees. The best free YouTube and TikTok downloader for European users.'
  },
  {
    id: 'faq-5',
    question: 'Need App For Video Downloading?',
    answer: 'No app or extension needed. 4K Video Downloader Plus is a web-based YouTube & TikTok downloader online. It works directly in your browser on Android, iPhone, Windows and Mac. No APK, no software, just paste and download.'
  },
  {
    id: 'faq-6',
    question: 'Is Downloader Safe And GDPR Compliant?',
    answer: 'Yes, completely safe and GDPR compliant for Europe. 4K Video Downloader Plus uses SSL encryption, collects no personal data, and never asks for your YouTube & TikTok login. Your downloads are anonymous and secure.'
  },
  {
    id: 'faq-7',
    question: 'Download Private TikTok & YouTube Videos?',
    answer: 'No, you cannot download private content. For privacy and copyright reasons, 4K Video Downloader Plus only works for public YouTube & TikTok videos. Private, friends-only or deleted YouTube and TikTok videos cannot be downloaded.'
  }
];
