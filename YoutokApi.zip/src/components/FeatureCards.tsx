import { Play, Music, Shield, Sparkles } from 'lucide-react';

export function FeatureCards() {
  const cards = [
    {
      id: 'feature-shorts',
      icon: <Play className="w-5 h-5 text-white fill-white stroke-[2.5]" />,
      title: 'Download YouTube & TikTok Videos & Shorts',
      description:
        'Easily save public videos from YouTube & TikTok in HD. Download YouTube videos, viral TikTok clips and YouTube Shorts in original 4K, 1080p Full HD and 60fps quality. The fastest free online YouTube & TikTok video downloader for all devices.'
    },
    {
      id: 'feature-dubbed',
      icon: <Music className="w-5 h-5 text-white stroke-[2.5]" />,
      title: 'YouTube & TikTok to MP3 Converter Online',
      description:
        'Convert and download audio from YouTube & TikTok in high quality. Save trending TikTok sounds, music and YouTube audio with multi-language support as 320kbps MP3 and M4A. Best free YouTube to MP3 and TikTok MP3 downloader for Europe.'
    },
    {
      id: 'feature-protected',
      icon: <Shield className="w-5 h-5 text-white stroke-[2.5]" />,
      title: 'Watermark-Free TikTok Video Downloader',
      description:
        'Download TikTok videos without watermark in full HD. Save your favorite viral TikTok clips in original quality with no logo. Our TikTok downloader without watermark is free, fast and works online without any app or login.'
    },
    {
      id: 'feature-smart-mode',
      icon: <Sparkles className="w-5 h-5 text-white stroke-[2.5]" />,
      title: 'Safe & Fast 4K Downloader for All Devices',
      description:
        '4K Video Downloader Plus is 100% safe, GDPR compliant and SSL secured. Download YouTube & TikTok videos in 4K, 1080p and MP3 format with zero tracking. Optimized for instant playback on Windows, macOS, Android and iOS.'
    }
  ];

  return (
    <section id="features-grid-section" className="w-full max-w-4xl mx-auto px-4 py-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {cards.map((card) => (
          <div
            key={card.id}
            id={card.id}
            className="group bg-white dark:bg-zinc-900 rounded-2xl p-5 sm:p-6 border border-slate-200/90 dark:border-zinc-800 shadow-md hover:shadow-xl hover:border-slate-300 dark:hover:border-zinc-700 transition-all duration-200 flex flex-col justify-start"
          >
            {/* Simple, Soft-cornered Bold Icon Badge */}
            <div className="w-10 h-10 rounded-xl bg-[#e50914] text-white flex items-center justify-center mb-4 shadow-md shadow-[#e50914]/25 group-hover:scale-105 transition-transform duration-200">
              {card.icon}
            </div>

            <h3 className="text-lg sm:text-xl font-inter-800 text-slate-900 dark:text-white tracking-tight leading-snug mb-2 group-hover:text-[#e50914] dark:group-hover:text-[#ef4444] transition-colors">
              {card.title}
            </h3>

            <p className="text-slate-600 dark:text-zinc-300 text-xs sm:text-sm leading-relaxed">
              {card.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
