import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { FAQ_LIST } from '../data/mockData';

export function FaqSection() {
  const [openId, setOpenId] = useState<string | null>(null);

  const toggle = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section id="faq-section" className="w-full max-w-5xl mx-auto px-4 pt-4 pb-16">
      <div className="w-full">
        {FAQ_LIST.map((faq) => {
          const isOpen = openId === faq.id;
          return (
            <div
              key={faq.id}
              className="border-b border-slate-200 dark:border-zinc-800 transition-colors"
            >
              <button
                type="button"
                id={`faq-btn-${faq.id}`}
                onClick={() => toggle(faq.id)}
                className="w-full py-4 text-left flex items-center justify-between gap-4 group cursor-pointer"
                aria-expanded={isOpen}
              >
                <span
                  className={`text-base sm:text-lg font-bold transition-colors duration-200 ${
                    isOpen
                      ? 'text-[#e50914] dark:text-[#ef4444]'
                      : 'text-slate-900 dark:text-zinc-100 group-hover:text-[#e50914] dark:group-hover:text-[#ef4444]'
                  }`}
                >
                  {faq.question}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-slate-400 group-hover:text-[#e50914] dark:group-hover:text-[#ef4444] shrink-0 transition-transform duration-300 ease-out ${
                    isOpen ? 'rotate-180 text-[#e50914] dark:text-[#ef4444]' : ''
                  }`}
                />
              </button>

              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    key={`content-${faq.id}`}
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ 
                      height: 'auto', 
                      opacity: 1,
                      transition: {
                        height: { duration: 0.28, ease: [0.16, 1, 0.3, 1] },
                        opacity: { duration: 0.22, delay: 0.05 }
                      }
                    }}
                    exit={{ 
                      height: 0, 
                      opacity: 0,
                      transition: {
                        height: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
                        opacity: { duration: 0.15 }
                      }
                    }}
                    className="overflow-hidden"
                  >
                    <div className="pb-5 pr-4 sm:pr-8 text-slate-600 dark:text-zinc-300 text-sm sm:text-base leading-relaxed">
                      <p>{faq.answer}</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </section>
  );
}
