import { useState, useEffect } from 'react';
import { Moon, Sun } from 'lucide-react';

interface HeaderProps {
  onScrollToHome: () => void;
  onScrollToHowToUse: () => void;
  onScrollToFaq: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  activeSection?: string;
}

export function Header({
  onScrollToHome,
  onScrollToHowToUse,
  onScrollToFaq,
  darkMode,
  onToggleDarkMode,
  activeSection = 'home'
}: HeaderProps) {
  const [currentSection, setCurrentSection] = useState(activeSection);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const howToUseEl = document.getElementById('process-banner-section');
      const faqEl = document.getElementById('faq-section');

      const faqOffset = faqEl ? faqEl.offsetTop - 200 : 99999;
      const howToUseOffset = howToUseEl ? howToUseEl.offsetTop - 200 : 99999;

      if (scrollY >= faqOffset) {
        setCurrentSection('faq');
      } else if (scrollY >= howToUseOffset) {
        setCurrentSection('help');
      } else {
        setCurrentSection('home');
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header id="main-header" className="sticky top-0 z-40 w-full pt-4 pb-3 px-4 backdrop-blur-md bg-white/90 dark:bg-[#18181b]/90 transition-colors duration-200 border-b border-slate-100 dark:border-zinc-800/80">
      <div className="max-w-6xl mx-auto flex items-center justify-between sm:justify-center relative">
        {/* Centered Nav: Home | Help | FAQ (Identical on both Desktop and Mobile emulator, active highlighted in red) */}
        <div className="flex items-center gap-5 sm:gap-8 md:gap-12 text-sm sm:text-base md:text-lg font-bold">
          <button
            id="nav-home-btn"
            onClick={() => {
              setCurrentSection('home');
              onScrollToHome();
            }}
            className={`transition-colors duration-150 py-1 px-2 rounded-lg cursor-pointer ${
              currentSection === 'home'
                ? 'text-[#e50914] dark:text-[#ef4444]'
                : 'text-[#1a1e29] dark:text-zinc-300 hover:text-[#e50914] dark:hover:text-[#ef4444]'
            }`}
          >
            Home
          </button>

          <button
            id="nav-help-btn"
            onClick={() => {
              setCurrentSection('help');
              onScrollToHowToUse();
            }}
            className={`transition-colors duration-150 py-1 px-2 rounded-lg cursor-pointer ${
              currentSection === 'help'
                ? 'text-[#e50914] dark:text-[#ef4444]'
                : 'text-[#1a1e29] dark:text-zinc-300 hover:text-[#e50914] dark:hover:text-[#ef4444]'
            }`}
          >
            Help
          </button>

          <button
            id="nav-faq-btn"
            onClick={() => {
              setCurrentSection('faq');
              onScrollToFaq();
            }}
            className={`transition-colors duration-150 py-1 px-2 rounded-lg cursor-pointer ${
              currentSection === 'faq'
                ? 'text-[#e50914] dark:text-[#ef4444]'
                : 'text-[#1a1e29] dark:text-zinc-300 hover:text-[#e50914] dark:hover:text-[#ef4444]'
            }`}
          >
            FAQ
          </button>
        </div>

        {/* Action icons right: Dark Mode Toggle */}
        <div className="sm:absolute sm:right-0 flex items-center gap-2">
          {/* Dark Mode Toggle: Compact, visible circle outline with smooth animated Sun / Moon transition */}
          <button
            id="dark-mode-toggle-btn"
            onClick={onToggleDarkMode}
            title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            aria-label="Toggle Dark Mode"
            className="w-8 h-8 sm:w-8 sm:h-8 rounded-full flex items-center justify-center bg-slate-100 hover:bg-slate-200/90 dark:bg-[#27272a] dark:hover:bg-[#323238] text-slate-700 dark:text-zinc-100 border border-slate-300 dark:border-zinc-700 shadow-xs transition-all duration-300 cursor-pointer active:scale-90 relative overflow-hidden group"
          >
            <div className="relative w-4 h-4 flex items-center justify-center">
              {/* Sun Icon (visible in Dark Mode, transforms smoothly when switching) */}
              <Sun 
                className={`w-4 h-4 absolute inset-0 text-amber-400 dark:text-zinc-100 stroke-[2.4] transition-all duration-400 cubic-bezier(0.16, 1, 0.3, 1) ${
                  darkMode 
                    ? 'opacity-100 scale-100 rotate-0' 
                    : 'opacity-0 scale-40 -rotate-90 pointer-events-none'
                }`} 
              />
              {/* Moon Icon (visible in Light Mode, transforms smoothly when switching) */}
              <Moon 
                className={`w-4 h-4 absolute inset-0 text-slate-700 stroke-[2.4] fill-slate-700/10 transition-all duration-400 cubic-bezier(0.16, 1, 0.3, 1) ${
                  darkMode 
                    ? 'opacity-0 scale-40 rotate-90 pointer-events-none' 
                    : 'opacity-100 scale-100 rotate-0'
                }`} 
              />
            </div>
          </button>
        </div>
      </div>
    </header>
  );
}
