import { X, HelpCircle, ShieldCheck } from 'lucide-react';

interface HelpModalProps {
  onClose: () => void;
}

export function HelpModal({ onClose }: HelpModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white dark:bg-zinc-900 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl border border-slate-100 dark:border-zinc-800 max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 border-b border-slate-100 dark:border-zinc-800 flex items-center justify-between bg-slate-50/70 dark:bg-zinc-900">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-[#e50914]" />
            <span className="font-inter-800 text-base text-slate-900 dark:text-white">How to Download Videos</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 dark:text-zinc-500 hover:text-slate-700 dark:hover:text-zinc-200 hover:bg-slate-200/60 dark:hover:bg-zinc-800 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5 text-sm text-slate-700 dark:text-zinc-300">
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-zinc-800/70 rounded-2xl">
              <div className="w-7 h-7 bg-[#e50914] text-white rounded-full flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                1
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white">Copy Video URL</h4>
                <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                  Open YouTube or TikTok and copy the link from the browser address bar or the &quot;Share&quot; menu.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-zinc-800/70 rounded-2xl">
              <div className="w-7 h-7 bg-[#e50914] text-white rounded-full flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                2
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white">Paste Link & Analyze</h4>
                <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                  Paste the link into the search box and click &quot;Download&quot;. Our engine instantly extracts all available 4K/1080p video &amp; MP3 audio streams.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-zinc-800/70 rounded-2xl">
              <div className="w-7 h-7 bg-[#e50914] text-white rounded-full flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                3
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white">Choose Quality & Save</h4>
                <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                  Select your desired resolution (4K, 1080p, TikTok No Watermark, or MP3 Audio) and click &quot;Download Now&quot;.
                </p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-red-50 dark:bg-red-950/40 rounded-2xl border border-red-100 dark:border-red-900/40 flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-[#e50914] shrink-0" />
            <p className="text-xs text-red-950 dark:text-red-200 font-bold">
              No registration or software installation required. 100% free, secure, and compatible with all mobile &amp; desktop browsers.
            </p>
          </div>
        </div>

        <div className="px-6 py-3 bg-slate-50 dark:bg-zinc-900 border-t border-slate-100 dark:border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-full bg-[#e50914] hover:bg-[#c90812] text-white font-bold text-xs cursor-pointer"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
}
