export function TikTokGuide() {
  return (
    <section id="tiktok-guide-section" className="w-full max-w-5xl mx-auto px-4 py-8">
      <div className="w-full rounded-3xl bg-gradient-to-br from-[#e50914] via-[#dc2626] to-[#7f1d1d] p-8 sm:p-12 text-white shadow-xl shadow-[#e50914]/20 relative overflow-hidden border border-red-500/20">
        {/* Decorative background glows */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

        {/* Title */}
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-inter-800 tracking-tight leading-snug mb-8 relative z-10">
          How to download YouTube & TikTok videos & MP4 without watermark?
        </h2>

        {/* 3 Step Stack */}
        <div className="space-y-6 relative z-10 max-w-4xl">
          {/* Step 1 */}
          <div className="relative pl-0 sm:pl-2">
            <div className="flex items-start gap-4 sm:gap-6">
              <span className="text-5xl sm:text-6xl md:text-7xl font-black text-white/35 leading-none select-none font-inter-800 shrink-0 -mt-1 sm:-mt-2 -mr-1 sm:-mr-2 transition-transform duration-200 hover:scale-105">
                1
              </span>
              <div className="relative z-10">
                <h3 className="text-lg sm:text-xl font-inter-800 mb-1.5 text-white">
                  Find a YouTube & TikTok Video
                </h3>
                <p className="text-white/90 text-sm sm:text-base leading-relaxed">
                  - Open the YouTube or TikTok app/website on your mobile device or desktop. Browse to find the video or Short you want to save. Play the video to confirm it is the clip you need.
                </p>
              </div>
            </div>
          </div>

          {/* Step 2 */}
          <div className="relative pl-0 sm:pl-2">
            <div className="flex items-start gap-4 sm:gap-6">
              <span className="text-5xl sm:text-6xl md:text-7xl font-black text-white/35 leading-none select-none font-inter-800 shrink-0 -mt-1 sm:-mt-2 -mr-1 sm:-mr-2 transition-transform duration-200 hover:scale-105">
                2
              </span>
              <div className="relative z-10">
                <h3 className="text-lg sm:text-xl font-inter-800 mb-1.5 text-white">
                  Copy the Link
                </h3>
                <p className="text-white/90 text-sm sm:text-base leading-relaxed">
                  - Tap the Share button located on YouTube or TikTok. Select &quot;Copy Link&quot; from the share menu. The URL will now be saved on your clipboard.
                </p>
              </div>
            </div>
          </div>

          {/* Step 3 */}
          <div className="relative pl-0 sm:pl-2">
            <div className="flex items-start gap-4 sm:gap-6">
              <span className="text-5xl sm:text-6xl md:text-7xl font-black text-white/35 leading-none select-none font-inter-800 shrink-0 -mt-1 sm:-mt-2 -mr-1 sm:-mr-2 transition-transform duration-200 hover:scale-105">
                3
              </span>
              <div className="relative z-10">
                <h3 className="text-lg sm:text-xl font-inter-800 mb-1.5 text-white">
                  Download YouTube & TikTok MP4
                </h3>
                <p className="text-white/90 text-sm sm:text-base leading-relaxed">
                  - Return to this downloader page and paste the link into the search box at the top. Click the Download icon to save the 4K / Full HD video or MP3 audio track without watermark.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
