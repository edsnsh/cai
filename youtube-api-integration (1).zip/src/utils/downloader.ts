import { VideoMetadata, DownloadItem } from '../types';
import { SAMPLE_VIDEOS } from '../data/mockData';

// Helper to simulate download file creation in browser
export function triggerFileDownload(title: string, format: string, quality: string) {
  // Create dummy blob with text content
  const cleanTitle = title.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 40);
  const fileName = `${cleanTitle}_${quality}.${format}`;
  const dummyContent = `[4K Video Downloader Plus]\n\nDownloaded File: ${fileName}\nFormat: ${format.toUpperCase()}\nQuality: ${quality}\nDate: ${new Date().toISOString()}\nStatus: Completed Verified Download\n`;
  
  const blob = new Blob([dummyContent], { type: format === 'mp3' ? 'audio/mpeg' : 'video/mp4' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.style.display = 'none';
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  
  setTimeout(() => {
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }, 2000);
}

// Parse input link and return simulated or matched video metadata
export async function parseVideoUrl(inputUrl: string): Promise<VideoMetadata> {
  const url = inputUrl.trim();

  // Simulate network parsing delay
  await new Promise((resolve) => setTimeout(resolve, 850));

  if (!url) {
    throw new Error('Please enter a valid video link.');
  }

  const lower = url.toLowerCase();

  // Check if matches our curated sample list
  const matchedSample = SAMPLE_VIDEOS.find(
    (s) => s.url.toLowerCase() === lower || lower.includes(s.id)
  );
  if (matchedSample) {
    return { ...matchedSample };
  }

  // Detect YouTube Shorts
  if (lower.includes('youtube.com/shorts') || lower.includes('youtu.be/shorts')) {
    return {
      id: `yt-short-${Date.now()}`,
      title: 'YouTube Shorts - Viral Trend Video Clip',
      platform: 'youtube',
      url,
      thumbnail: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80',
      duration: '00:45',
      author: 'Shorts Creator Official',
      views: '2.1M views',
      isShort: true,
      formats: [
        { id: 'ys-1080', type: 'video', quality: 'Shorts Full HD (1080x1920)', resolution: '1080p', format: 'mp4', size: '14.2 MB', fps: 60, hasAudio: true },
        { id: 'ys-720', type: 'video', quality: 'Shorts HD (720x1280)', resolution: '720p', format: 'mp4', size: '7.8 MB', fps: 30, hasAudio: true },
        { id: 'ys-mp3', type: 'audio', quality: 'Shorts Audio Only (MP3 320kbps)', bitrate: '320 kbps', format: 'mp3', size: '1.6 MB' }
      ]
    };
  }

  // Detect Standard YouTube
  if (lower.includes('youtube.com') || lower.includes('youtu.be')) {
    return {
      id: `yt-${Date.now()}`,
      title: 'YouTube 4K Ultra HD Video - High Frame Rate HDR Stream',
      platform: 'youtube',
      url,
      thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
      duration: '08:30',
      author: 'YouTube Premium Creator',
      views: '3.9M views',
      formats: [
        { id: 'y-4k', type: 'video', quality: '4K Ultra HD (2160p 60fps)', resolution: '2160p', format: 'mp4', size: '520 MB', fps: 60, hasAudio: true },
        { id: 'y-2k', type: 'video', quality: '2K Quad HD (1440p)', resolution: '1440p', format: 'mp4', size: '290 MB', fps: 60, hasAudio: true },
        { id: 'y-1080', type: 'video', quality: '1080p Full HD', resolution: '1080p', format: 'mp4', size: '145 MB', fps: 60, hasAudio: true },
        { id: 'y-720', type: 'video', quality: '720p HD', resolution: '720p', format: 'mp4', size: '72 MB', fps: 30, hasAudio: true },
        { id: 'y-480', type: 'video', quality: '480p SD', resolution: '480p', format: 'mp4', size: '34 MB', fps: 30, hasAudio: true },
        { id: 'y-mp3-320', type: 'audio', quality: 'Dubbed Audio Track (MP3 320k)', bitrate: '320 kbps', format: 'mp3', size: '19.4 MB' },
        { id: 'y-mp3-192', type: 'audio', quality: 'Standard Audio (MP3 192k)', bitrate: '192 kbps', format: 'mp3', size: '11.8 MB' },
        { id: 'y-m4a', type: 'audio', quality: 'Lossless AAC Audio (M4A)', bitrate: '256 kbps', format: 'm4a', size: '14.2 MB' }
      ],
      subtitles: [
        { lang: 'en', label: 'English' },
        { lang: 'es', label: 'Spanish' },
        { lang: 'fr', label: 'French' }
      ]
    };
  }

  // Fallback as YouTube stream
  return {
    id: `yt-stream-${Date.now()}`,
    title: 'YouTube Stream - 4K High Quality Download (' + (url.length > 25 ? url.slice(0, 25) + '...' : url) + ')',
    platform: 'youtube',
    url,
    thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
    duration: '04:20',
    author: 'YouTube Media Stream',
    views: '1.2M views',
    formats: [
      { id: 'g-4k', type: 'video', quality: '4K Ultra HD (2160p)', resolution: '2160p', format: 'mp4', size: '380 MB', fps: 60, hasAudio: true },
      { id: 'g-1080', type: 'video', quality: '1080p Full HD', resolution: '1080p', format: 'mp4', size: '95 MB', fps: 60, hasAudio: true },
      { id: 'g-720', type: 'video', quality: '720p HD', resolution: '720p', format: 'mp4', size: '48 MB', fps: 30, hasAudio: true },
      { id: 'g-mp3', type: 'audio', quality: 'Audio Only (MP3 320kbps)', bitrate: '320 kbps', format: 'mp3', size: '5.2 MB' }
    ]
  };
}

// Local storage management for history
const STORAGE_KEY = '4k_downloader_history_v2';

export function getDownloadHistory(): DownloadItem[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveDownloadHistory(item: DownloadItem): DownloadItem[] {
  try {
    const existing = getDownloadHistory();
    const filtered = existing.filter((i) => i.id !== item.id);
    const updated = [item, ...filtered].slice(0, 50); // Keep max 50
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch {
    return [];
  }
}

export function removeDownloadItem(id: string): DownloadItem[] {
  try {
    const existing = getDownloadHistory();
    const updated = existing.filter((i) => i.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch {
    return [];
  }
}

export function clearDownloadHistory(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}
