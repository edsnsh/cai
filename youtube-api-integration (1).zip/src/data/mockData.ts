import { VideoMetadata } from '../types';

export const SAMPLE_VIDEOS: VideoMetadata[] = [
  {
    id: 'yt-4k-nature',
    title: 'Costa Rica in 4K 60fps HDR (Ultra HD) - Wildlife and Rainforests',
    platform: 'youtube',
    url: 'https://www.youtube.com/watch?v=LXb3EKWsInQ',
    thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
    duration: '05:42',
    author: 'Nature Relaxation 4K',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    views: '14.2M views',
    formats: [
      { id: 'f-4k', type: 'video', quality: '4K Ultra HD (2160p)', resolution: '2160p (3840x2160)', format: 'mp4', size: '482 MB', fps: 60, hasAudio: true },
      { id: 'f-2k', type: 'video', quality: '2K Quad HD', resolution: '1440p (2560x1440)', format: 'mp4', size: '264 MB', fps: 60, hasAudio: true },
      { id: 'f-1080', type: 'video', quality: '1080p Full HD', resolution: '1080p (1920x1080)', format: 'mp4', size: '138 MB', fps: 60, hasAudio: true },
      { id: 'f-720', type: 'video', quality: '720p HD', resolution: '720p (1280x720)', format: 'mp4', size: '64 MB', fps: 30, hasAudio: true },
      { id: 'f-480', type: 'video', quality: '480p SD', resolution: '480p (854x480)', format: 'mp4', size: '28 MB', fps: 30, hasAudio: true },
      { id: 'f-mp3-320', type: 'audio', quality: 'Ultra High Quality (Dubbed MP3)', bitrate: '320 kbps', format: 'mp3', size: '13.8 MB' },
      { id: 'f-mp3-192', type: 'audio', quality: 'Standard Quality Audio', bitrate: '192 kbps', format: 'mp3', size: '8.2 MB' },
      { id: 'f-m4a', type: 'audio', quality: 'Lossless AAC Audio', bitrate: '256 kbps', format: 'm4a', size: '10.5 MB' }
    ],
    subtitles: [
      { lang: 'en', label: 'English (Original Subtitles)' },
      { lang: 'es', label: 'Spanish' },
      { lang: 'fr', label: 'French' },
      { lang: 'de', label: 'German' }
    ]
  },
  {
    id: 'yt-4k-tokyo',
    title: 'Tokyo in 4K HDR 60fps - Cinematic Night Walk & City Sounds',
    platform: 'youtube',
    url: 'https://www.youtube.com/watch?v=V-_O7nl0Ii0',
    thumbnail: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=800&q=80',
    duration: '12:30',
    author: 'Tokyo Explorer 4K',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    views: '9.4M views',
    formats: [
      { id: 'f-tokyo-4k', type: 'video', quality: '4K Ultra HD (2160p)', resolution: '2160p (3840x2160)', format: 'mp4', size: '610 MB', fps: 60, hasAudio: true },
      { id: 'f-tokyo-1080', type: 'video', quality: '1080p Full HD', resolution: '1080p (1920x1080)', format: 'mp4', size: '175 MB', fps: 60, hasAudio: true },
      { id: 'f-tokyo-720', type: 'video', quality: '720p HD', resolution: '720p (1280x720)', format: 'mp4', size: '82 MB', fps: 30, hasAudio: true },
      { id: 'f-tokyo-mp3', type: 'audio', quality: 'Original Ambient Soundtrack (MP3)', bitrate: '320 kbps', format: 'mp3', size: '18.2 MB' }
    ]
  },
  {
    id: 'yt-shorts-cooking',
    title: 'Crispy Garlic Butter Smash Burger in 60 Seconds! 🍔🔥 #shorts #food',
    platform: 'youtube',
    url: 'https://www.youtube.com/shorts/k93pL2oW9xA',
    thumbnail: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80',
    duration: '00:58',
    author: 'Chef Reactions & Bites',
    authorAvatar: 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=120&q=80',
    views: '3.4M views',
    isShort: true,
    formats: [
      { id: 'f-s-1080', type: 'video', quality: 'Shorts 1080p Full HD (60fps)', resolution: '1080p', format: 'mp4', size: '18.5 MB', fps: 60, hasAudio: true },
      { id: 'f-s-720', type: 'video', quality: 'Shorts 720p HD', resolution: '720p', format: 'mp4', size: '9.2 MB', fps: 30, hasAudio: true },
      { id: 'f-s-mp3', type: 'audio', quality: 'Shorts Audio Only (MP3 320k)', bitrate: '320 kbps', format: 'mp3', size: '2.1 MB' }
    ]
  },
  {
    id: 'yt-acoustic-live',
    title: 'Acoustic Guitar Live Session - Relaxing Fingerstyle (Studio Quality)',
    platform: 'youtube',
    url: 'https://www.youtube.com/watch?v=LXb3EKWsInQ_acoustic',
    thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
    duration: '04:15',
    author: 'Acoustic Sessions Studio',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=120&q=80',
    views: '5.1M views',
    formats: [
      { id: 'yt-ac-1080', type: 'video', quality: '1080p Full HD (60fps)', resolution: '1080p', format: 'mp4', size: '88 MB', fps: 60, hasAudio: true },
      { id: 'yt-ac-720', type: 'video', quality: '720p HD', resolution: '720p', format: 'mp4', size: '42 MB', fps: 30, hasAudio: true },
      { id: 'yt-ac-mp3', type: 'audio', quality: 'Master Audio (MP3 320kbps)', bitrate: '320 kbps', format: 'mp3', size: '9.8 MB' }
    ]
  }
];

export const FAQ_LIST = [
  {
    id: 'faq-1',
    question: 'Best YouTube Downloader Online?',
    answer: '4K Video Downloader Plus is the best free online YouTube video downloader. Download YouTube videos and YouTube Shorts in 4K and 1080p HD quality. Fast, free, and works on all devices.'
  },
  {
    id: 'faq-2',
    question: 'Download YouTube 4K Videos?',
    answer: 'Yes, you can download YouTube videos in 4K, 1080p and HD. Just paste the YouTube link into 4K Video Downloader Plus and select your quality. We support full 4K and 1080p 60fps downloads.'
  },
  {
    id: 'faq-3',
    question: 'How To Download YouTube MP3?',
    answer: 'Use 4K Video Downloader Plus as a YouTube to MP3 downloader. Paste any YouTube link and choose MP3 or M4A format up to 320kbps. Instantly convert and download YouTube audio for offline listening.'
  },
  {
    id: 'faq-4',
    question: 'Is YouTube Downloader Free?',
    answer: 'Yes, 100% free and unlimited. 4K Video Downloader Plus lets you download unlimited YouTube videos, Shorts and MP3s with no limit, no registration and no fees.'
  },
  {
    id: 'faq-5',
    question: 'Need App For Video Downloading?',
    answer: 'No app or extension needed. 4K Video Downloader Plus is a web-based YouTube downloader online. It works directly in your browser on Android, iPhone, Windows and Mac. No APK, no software, just paste and download.'
  },
  {
    id: 'faq-6',
    question: 'Is Downloader Safe And GDPR Compliant?',
    answer: 'Yes, completely safe and GDPR compliant. 4K Video Downloader Plus uses SSL encryption, collects no personal data, and never asks for your YouTube login. Your downloads are anonymous and secure.'
  },
  {
    id: 'faq-7',
    question: 'Download Private YouTube Videos?',
    answer: 'No, you cannot download private content. For privacy and copyright reasons, 4K Video Downloader Plus only works for public YouTube videos. Private, unlisted or deleted videos cannot be downloaded.'
  }
];
