export interface VideoFormat {
  id: string;
  type: 'video' | 'audio';
  quality: string;
  resolution?: string;
  bitrate?: string;
  format: 'mp4' | 'mkv' | 'webm' | 'mp3' | 'm4a';
  size: string;
  fps?: number;
  hasAudio?: boolean;
  watermarkFree?: boolean;
}

export interface VideoMetadata {
  id: string;
  title: string;
  platform: 'youtube' | 'vimeo' | 'facebook' | 'soundcloud' | 'twitch' | 'other';
  url: string;
  thumbnail: string;
  duration: string;
  author: string;
  authorAvatar?: string;
  views: string;
  formats: VideoFormat[];
  subtitles?: { lang: string; label: string }[];
  isShort?: boolean;
}

export interface DownloadHistoryItem {
  id: string;
  title: string;
  platform: string;
  format: string;
  quality: string;
  size: string;
  timestamp: number;
  thumbnail: string;
  downloadedAt?: string;
  blobUrl?: string;
}

export type DownloadItem = DownloadHistoryItem;

export interface SmartModeSettings {
  enabled: boolean;
  defaultFormat: 'mp4' | 'mp3' | 'mkv';
  defaultQuality: '2160p' | '1080p' | '720p' | 'best';
  autoDownloadSubtitles: boolean;
  osTarget: 'windows' | 'macos' | 'android' | 'ios' | 'linux';
}
