import { Play, Music, Shield, Sparkles } from 'lucide-react';

export function FeatureCards() {
  const cards = [
    {
      id: 'feature-shorts',
      icon: <Play className="w-5 h-5 text-white fill-white stroke-[2.5]" />,
      title: 'YouTube Video Downloader',
      description:
        'Save any public YouTube video instantly. As a fast video downloader, you can download MP4 files in 4K Ultra HD, 1080p and 60fps with original quality. Works on all devices.'
    },
    {
      id: 'feature-dubbed',
      icon: <Music className="w-5 h-5 text-white stroke-[2.5]" />,
      title: 'Download MP3 & Music',
      description:
        'Need music offline? You can download MP3 and M4A up to 320kbps. Our mp3 downloader and music downloader saves songs, podcasts and audio tracks with multi-language support.'
    },
    {
      id: 'feature-protected',
      icon: <Shield className="w-5 h-5 text-white stroke-[2.5]" />,
      title: 'Download 4K Videos',
      description:
        'Choose the quality you actually need. You can download MP4 in 4K, 1080p, 60FPS and HDR with no compression or quality loss. Built as a powerful 4K downloader and MP4 downloader for crystal-clear playback.'
    },
    {
      id: 'feature-smart-mode',
      icon: <Sparkles className="w-5 h-5 text-white stroke-[2.5]" />,
      title: '100% Safe, Fast, Private to Use',
      description:
        '4K Video Downloader Plus is 100% safe, GDPR compliant and SSL secured. You can download audio privately with zero tracking and no login. A trusted audio downloader for Windows, macOS, Android and iOS.'
    }
  ];

  return (
    <section id="features-grid-section" className="w-full max-w-4xl mx-auto px-4 py-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {cards.map((card) => (
          <div
            key={card.id}
            id={card.id}
            className="group bg-white dark:bg-zinc-900 rounded-2xl p-5 sm:p-6 border border-slate-200/90 dark:border-zinc-800 shadow-md hover:shadow-xl hover:border-slate-300 dark:hover:border-zinc-700 transition-all duration-200 flex flex-col justify-start"
          >
            {/* Simple, Soft-cornered Bold Icon Badge */}
            <div className="w-10 h-10 rounded-xl bg-[#e50914] text-white flex items-center justify-center mb-4 shadow-md shadow-[#e50914]/25 group-hover:scale-105 transition-transform duration-200">
              {card.icon}
            </div>

            <h3 className="text-lg sm:text-xl font-inter-800 text-slate-900 dark:text-white tracking-tight leading-snug mb-2 group-hover:text-[#e50914] dark:group-hover:text-[#ef4444] transition-colors">
              {card.title}
            </h3>

            <p className="text-slate-600 dark:text-zinc-300 text-xs sm:text-sm leading-relaxed">
              {card.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
