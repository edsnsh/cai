import { useState } from 'react';
import { X, Sliders } from 'lucide-react';
import { SmartModeSettings } from '../types';

interface SmartModeModalProps {
  settings: SmartModeSettings;
  onSave: (newSettings: SmartModeSettings) => void;
  onClose: () => void;
}

export function SmartModeModal({ settings, onSave, onClose }: SmartModeModalProps) {
  const [enabled, setEnabled] = useState(settings.enabled);
  const [defaultFormat, setDefaultFormat] = useState(settings.defaultFormat);
  const [defaultQuality, setDefaultQuality] = useState(settings.defaultQuality);
  const [autoSubtitles] = useState(settings.autoDownloadSubtitles);
  const [osTarget, setOsTarget] = useState(settings.osTarget);

  const handleSave = () => {
    onSave({
      enabled,
      defaultFormat,
      defaultQuality,
      autoDownloadSubtitles: autoSubtitles,
      osTarget
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white dark:bg-zinc-900 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl border border-slate-100 dark:border-zinc-800"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 border-b border-slate-100 dark:border-zinc-800 flex items-center justify-between bg-slate-50/70 dark:bg-zinc-900">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-[#e50914]" />
            <span className="font-inter-800 text-base text-slate-900 dark:text-white">Smart Mode Settings</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 dark:text-zinc-500 hover:text-slate-700 dark:hover:text-zinc-200 hover:bg-slate-200/60 dark:hover:bg-zinc-800 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 text-sm text-slate-700 dark:text-zinc-300">
          {/* Toggle Smart Mode */}
          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-zinc-800/70 rounded-2xl border border-slate-100 dark:border-zinc-700/60">
            <div>
              <div className="font-bold text-slate-900 dark:text-white">Enable Smart Mode</div>
              <div className="text-xs text-slate-500 dark:text-zinc-400 font-medium">
                Automatically download links with predefined format & quality
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-300 dark:bg-zinc-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#e50914]"></div>
            </label>
          </div>

          {/* Default Format */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-zinc-400 mb-2">
              Default Format
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['mp4', 'mp3', 'mkv'] as const).map((fmt) => (
                <button
                  key={fmt}
                  type="button"
                  onClick={() => setDefaultFormat(fmt)}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold uppercase transition-all cursor-pointer ${
                    defaultFormat === fmt
                      ? 'border-[#e50914] bg-[#e50914]/10 text-[#e50914] dark:bg-[#e50914]/20'
                      : 'border-slate-200 dark:border-zinc-700 hover:border-slate-300 text-slate-700 dark:text-zinc-300 dark:bg-zinc-800'
                  }`}
                >
                  {fmt}
                </button>
              ))}
            </div>
          </div>

          {/* Default Resolution */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-zinc-400 mb-2">
              Preferred Resolution
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: '2160p', label: '4K Ultra' },
                { id: '1080p', label: '1080p' },
                { id: '720p', label: '720p HD' },
                { id: 'best', label: 'Best Avail' }
              ].map((res) => (
                <button
                  key={res.id}
                  type="button"
                  onClick={() => setDefaultQuality(res.id as any)}
                  className={`py-2 px-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    defaultQuality === res.id
                      ? 'border-[#e50914] bg-[#e50914]/10 text-[#e50914] dark:bg-[#e50914]/20'
                      : 'border-slate-200 dark:border-zinc-700 hover:border-slate-300 text-slate-700 dark:text-zinc-300 dark:bg-zinc-800'
                  }`}
                >
                  {res.label}
                </button>
              ))}
            </div>
          </div>

          {/* Target OS */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-zinc-400 mb-2">
              Target Operating System
            </label>
            <select
              value={osTarget}
              onChange={(e) => setOsTarget(e.target.value as any)}
              className="w-full bg-slate-50 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-xl px-3 py-2 text-sm font-bold text-slate-800 dark:text-zinc-200 outline-none"
            >
              <option value="windows">Windows (Default MP4/AAC)</option>
              <option value="macos">macOS / iOS (Apple Friendly)</option>
              <option value="android">Android (Mobile Optimized)</option>
              <option value="linux">Linux (Open Formats)</option>
            </select>
          </div>
        </div>

        <div className="px-6 py-4 bg-slate-50 dark:bg-zinc-900 border-t border-slate-100 dark:border-zinc-800 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-full border border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-300 font-bold text-xs hover:bg-slate-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-6 py-2 rounded-full bg-[#e50914] hover:bg-[#c90812] text-white font-bold text-xs shadow-sm shadow-[#e50914]/25 cursor-pointer"
          >
            Apply Settings
          </button>
        </div>
      </div>
    </div>
  );
}
