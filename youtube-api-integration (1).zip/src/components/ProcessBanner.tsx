export function ProcessBanner() {
  return (
    <section id="process-banner-section" className="w-full max-w-5xl mx-auto px-4 py-8">
      <div className="w-full rounded-2xl bg-gradient-to-r from-[#e50914] via-[#dc2626] to-[#991b1b] p-8 sm:p-10 text-white text-center shadow-xl shadow-[#e50914]/20 border border-red-500/20">
        {/* Step Items Row */}
        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-3 font-inter-800 text-xl sm:text-2xl md:text-3xl tracking-tight mb-4">
          <div className="inline-flex items-center gap-2">
            <span className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-white/20 backdrop-blur-sm text-white flex items-center justify-center text-base sm:text-lg font-bold">
              1
            </span>
            <span>Copy a link</span>
          </div>

          <div className="inline-flex items-center gap-2">
            <span className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-white/20 backdrop-blur-sm text-white flex items-center justify-center text-base sm:text-lg font-bold">
              2
            </span>
            <span>Paste into the app</span>
          </div>

          <div className="inline-flex items-center gap-2">
            <span className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-white/20 backdrop-blur-sm text-white flex items-center justify-center text-base sm:text-lg font-bold">
              3
            </span>
            <span>Download</span>
          </div>

          <div className="inline-flex items-center gap-2">
            <span className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-white/20 backdrop-blur-sm text-white flex items-center justify-center text-base sm:text-lg font-bold">
              4
            </span>
            <span>Enjoy!</span>
          </div>
        </div>

        {/* Subtitle */}
        <p className="text-white/95 text-sm sm:text-base font-normal max-w-xl mx-auto">
          Downloading videos has never been easier.<br className="hidden sm:inline" />
          Turn links into files in seconds.
        </p>
      </div>
    </section>
  );
}
