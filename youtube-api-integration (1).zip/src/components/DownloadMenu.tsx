import React, { useState, useMemo, useEffect } from 'react';
import { 
  Video, 
  Music, 
  Download, 
  Check, 
  Loader2, 
  AlertCircle, 
  RefreshCw, 
  Image as ImageIcon,
  ChevronLeft,
  ChevronRight,
  Layers
} from 'lucide-react';

export interface VideoInfoData {
  id: string;
  mediaType?: 'video' | 'post';
  title: string;
  channelTitle: string;
  thumbnail: string;
  images?: string[];
  postText?: string;
  duration?: string;
  maxQuality: string;
  availableQualities: string[];
  availableAudioQualities?: string[];
  availableImageFormats?: string[];
  previewUrl?: string;
  url: string;
}

interface DownloadMenuProps {
  videoUrl: string;
  onUrlChange?: (newUrl: string) => void;
}

// Client-side oEmbed fallback helper
async function resolveClientYouTubeMeta(videoId: string) {
  try {
    const res = await fetch(`https://noembed.com/embed?url=https://www.youtube.com/watch?v=${videoId}`);
    if (res.ok) {
      const data = await res.json();
      if (data.title || data.author_name) {
        return {
          title: data.title || '',
          channelTitle: data.author_name || '',
          thumbnail: data.thumbnail_url || `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`
        };
      }
    }
  } catch {
    // continue
  }

  try {
    const res2 = await fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`);
    if (res2.ok) {
      const data = await res2.json();
      if (data.title || data.author_name) {
        return {
          title: data.title || '',
          channelTitle: data.author_name || '',
          thumbnail: data.thumbnail_url || `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`
        };
      }
    }
  } catch {
    // continue
  }

  return null;
}

export function DownloadMenu({ videoUrl }: DownloadMenuProps) {
  const [format, setFormat] = useState<'MP4' | 'MP3' | 'JPG' | 'PNG'>('MP4');
  const [selectedQuality, setSelectedQuality] = useState<string>('1080p');
  const [activeImageIndex, setActiveImageIndex] = useState<number>(0);
  const [videoData, setVideoData] = useState<VideoInfoData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [imgFallbackLevel, setImgFallbackLevel] = useState<number>(0);

  const isPost = videoData?.mediaType === 'post';

  const mp4Qualities = useMemo(() => ['144p', '360p', '720p', '1080p', '2K', '4K'], []);
  const mp3Qualities = useMemo(() => ['64kbps', '128kbps', '192kbps', '256kbps', '320kbps', 'FLAC'], []);
  const imageQualities = useMemo(() => ['Original', '1080p', '720p', '480p'], []);

  // Touch / Drag swipe state for multi-image posts
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const [isMouseDragging, setIsMouseDragging] = useState(false);
  const [mouseStartX, setMouseStartX] = useState(0);

  // Fetch video or post data from API
  useEffect(() => {
    let isMounted = true;
    async function fetchInfo() {
      if (!videoUrl) return;
      setIsLoading(true);
      setError(null);
      setImgFallbackLevel(0);
      setActiveImageIndex(0);

      // Extract YouTube ID locally
      let ytId = '';
      const match = videoUrl.match(/(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/|live\/))([a-zA-Z0-9_-]{11})/i);
      if (match && match[1]) {
        ytId = match[1];
      } else if (/^[a-zA-Z0-9_-]{11}$/.test(videoUrl.trim())) {
        ytId = videoUrl.trim();
      }

      let fetchedData: VideoInfoData | null = null;

      try {
        const res = await fetch(`/api/info?url=${encodeURIComponent(videoUrl)}`);
        if (res.ok) {
          fetchedData = await res.json();
        }
      } catch {
        // Fallback to client extraction
      }

      // If backend returned default placeholder or failed for videos, resolve directly on client
      if (
        (!fetchedData || !fetchedData.title || fetchedData.title === 'YouTube Video' || fetchedData.channelTitle === 'YouTube Channel' || fetchedData.channelTitle === 'YouTube Creator') &&
        fetchedData?.mediaType !== 'post'
      ) {
        if (ytId) {
          const clientMeta = await resolveClientYouTubeMeta(ytId);
          if (clientMeta) {
            fetchedData = {
              id: ytId,
              mediaType: 'video',
              title: clientMeta.title || fetchedData?.title || 'YouTube Video',
              channelTitle: clientMeta.channelTitle || fetchedData?.channelTitle || 'YouTube Creator',
              thumbnail: clientMeta.thumbnail || fetchedData?.thumbnail || `https://img.youtube.com/vi/${ytId}/maxresdefault.jpg`,
              duration: fetchedData?.duration || '04:15',
              maxQuality: fetchedData?.maxQuality || '1080p',
              availableQualities: mp4Qualities,
              availableAudioQualities: mp3Qualities,
              url: videoUrl
            };
          }
        }
      }

      if (!isMounted) return;

      if (fetchedData) {
        setVideoData(fetchedData);
        if (fetchedData.mediaType === 'post') {
          setFormat('JPG');
          setSelectedQuality('Original');
        } else {
          setFormat('MP4');
          const is4kAvailable = fetchedData.maxQuality && (fetchedData.maxQuality.toLowerCase().includes('4k') || fetchedData.maxQuality.includes('2160'));
          if (is4kAvailable) {
            setSelectedQuality('4K');
          } else if (fetchedData.maxQuality && mp4Qualities.includes(fetchedData.maxQuality)) {
            setSelectedQuality(fetchedData.maxQuality);
          } else {
            setSelectedQuality('1080p');
          }
        }
      } else {
        // Final fallback structure
        setVideoData({
          id: ytId || 'custom-yt',
          mediaType: 'video',
          title: ytId ? `YouTube Video (${ytId})` : 'YouTube Video',
          channelTitle: 'YouTube Creator',
          thumbnail: ytId ? `https://img.youtube.com/vi/${ytId}/hqdefault.jpg` : '',
          duration: '03:45',
          maxQuality: '1080p',
          availableQualities: mp4Qualities,
          availableAudioQualities: mp3Qualities,
          url: videoUrl
        });
      }

      setIsLoading(false);
    }

    fetchInfo();
    return () => {
      isMounted = false;
    };
  }, [videoUrl, mp4Qualities, mp3Qualities]);

  // Gallery images list for YouTube posts
  const postImages = useMemo(() => {
    if (!videoData) return [];
    if (videoData.images && videoData.images.length > 0) {
      return videoData.images;
    }
    if (videoData.thumbnail) {
      return [videoData.thumbnail];
    }
    return [];
  }, [videoData]);

  const currentPostImage = postImages[activeImageIndex] || videoData?.thumbnail || '';

  // Determine which qualities are disabled based on maxQuality
  const maxQualityIndex = useMemo(() => {
    if (isPost) return 3;
    if (!videoData?.maxQuality) return 3;
    const mq = videoData.maxQuality.toLowerCase();
    if (mq.includes('4k') || mq.includes('2160')) return 5;
    if (mq.includes('2k') || mq.includes('1440')) return 4;
    if (mq.includes('1080')) return 3;
    if (mq.includes('720')) return 2;
    if (mq.includes('480') || mq.includes('360')) return 1;
    if (mq.includes('144')) return 0;
    return 3;
  }, [videoData, isPost]);

  const isQualityDisabled = (index: number) => {
    if (isPost) return false;
    if (format === 'MP4') {
      return index > maxQualityIndex;
    }
    if (format === 'MP3') {
      // mp3Qualities = ['64kbps', '128kbps', '192kbps', '256kbps', '320kbps', 'FLAC']
      // YouTube source does not have native lossless FLAC
      if (index === 5) return true;
      // If video is max 144p or 360p, high bitrates (256k & 320k) are not supported
      if (maxQualityIndex <= 1 && index >= 3) return true;
      return false;
    }
    return false;
  };

  // Ensure selected quality is valid if current quality becomes disabled
  useEffect(() => {
    if (isPost) {
      if (!imageQualities.includes(selectedQuality)) {
        setSelectedQuality('Original');
      }
      return;
    }
    const currentList = format === 'MP4' ? mp4Qualities : mp3Qualities;
    const currentIndex = currentList.indexOf(selectedQuality);
    if (currentIndex === -1 || isQualityDisabled(currentIndex)) {
      const enabledQualities = currentList.filter((_, idx) => !isQualityDisabled(idx));
      if (enabledQualities.length > 0) {
        setSelectedQuality(enabledQualities[enabledQualities.length - 1]);
      }
    }
  }, [format, maxQualityIndex, isPost, mp4Qualities, mp3Qualities, selectedQuality]);

  // Button text: only "Download [Quality]"
  const downloadButtonText = useMemo(() => {
    if (isDownloading) return 'Preparing Download...';
    if (downloadSuccess) return 'Download Started!';
    return `Download ${selectedQuality}`;
  }, [selectedQuality, isDownloading, downloadSuccess]);

  // Handle download trigger
  const handleDownload = async () => {
    if (isDownloading) return;
    setIsDownloading(true);
    setDownloadSuccess(false);
    setError(null);

    try {
      if (isPost) {
        // Download Image from Post
        const safeChannel = (videoData?.channelTitle || 'youtube').replace(/[^a-zA-Z0-9_-]/g, '_');
        const filename = `youtube_post_${safeChannel}_${activeImageIndex + 1}.${format.toLowerCase()}`;
        const downloadUrl = `/api/download?imageUrl=${encodeURIComponent(currentPostImage)}&quality=${encodeURIComponent(selectedQuality)}&format=${format.toLowerCase()}&type=image&filename=${encodeURIComponent(filename)}`;

        const link = document.createElement('a');
        link.href = downloadUrl;
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        // Video / Audio Download using FastSaver API with selected settings
        let requestedFormat = selectedQuality;
        if (format === 'MP3') {
          requestedFormat = 'mp3';
        } else {
          if (selectedQuality === '4K') requestedFormat = '2160p';
          else if (selectedQuality === '2K') requestedFormat = '1440p';
          else requestedFormat = selectedQuality;
        }

        const res = await fetch('/api/download', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            url: videoUrl,
            format: requestedFormat,
            quality: selectedQuality,
          }),
        });

        const data = await res.json();

        if (res.ok && data.ok && data.download_url) {
          // Trigger direct in-browser download without opening new tabs
          const link = document.createElement('a');
          link.href = data.download_url;
          if (data.filename) {
            link.setAttribute('download', data.filename);
          }
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        } else {
          throw new Error(data.error || data.message || 'Download link could not be generated.');
        }
      }

      setDownloadSuccess(true);
      setTimeout(() => {
        setDownloadSuccess(false);
      }, 4000);
    } catch (e: any) {
      console.error('Download error:', e);
      setError(e?.message || 'Download failed. Please check the link or API key.');
    } finally {
      setIsDownloading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="w-full max-w-[480px] md:max-w-[920px] mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 items-center">
          <div className="aspect-[16/9] w-full rounded-[20px] bg-slate-200 dark:bg-zinc-800/60 animate-pulse" />
          <div className="space-y-3.5">
            <div className="h-10 rounded-[12px] bg-slate-200 dark:bg-zinc-800/60 animate-pulse" />
            <div className="grid grid-cols-2 gap-2">
              <div className="h-9 rounded-[12px] bg-slate-200 dark:bg-zinc-800/60 animate-pulse" />
              <div className="h-9 rounded-[12px] bg-slate-200 dark:bg-zinc-800/60 animate-pulse" />
              <div className="h-9 rounded-[12px] bg-slate-200 dark:bg-zinc-800/60 animate-pulse" />
              <div className="h-9 rounded-[12px] bg-slate-200 dark:bg-zinc-800/60 animate-pulse" />
            </div>
            <div className="h-11 rounded-[12px] bg-slate-200 dark:bg-zinc-800/60 animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (error && !videoData) {
    return (
      <div className="w-full max-w-[480px] mx-auto px-4 py-8 text-center bg-[#1e1e1e] rounded-[20px] border border-red-500/20 my-4">
        <AlertCircle className="w-10 h-10 text-red-500 mx-auto mb-3" />
        <h3 className="text-white font-bold text-lg mb-2">Could Not Load Content</h3>
        <p className="text-white/60 text-sm mb-4">{error}</p>
        <button
          onClick={() => window.location.reload()}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#e50914] text-white font-bold text-xs"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Try Again
        </button>
      </div>
    );
  }

  const ytId = videoData?.id;
  const title = videoData?.title || (isPost ? 'YouTube Community Post' : 'YouTube Video');
  const channelTitle = videoData?.channelTitle || 'YouTube Creator';
  const postText = videoData?.postText;
  
  const displayImage = isPost 
    ? currentPostImage 
    : (imgFallbackLevel === 0
        ? (videoData?.thumbnail || (ytId ? `https://img.youtube.com/vi/${ytId}/maxresdefault.jpg` : ''))
        : (ytId ? `https://img.youtube.com/vi/${ytId}/hqdefault.jpg` : ''));

  // Swipe distance threshold in px
  const minSwipeDistance = 45;

  const onTouchStartHandler = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMoveHandler = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEndHandler = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    if (isLeftSwipe && postImages.length > 1) {
      setActiveImageIndex(prev => (prev === postImages.length - 1 ? 0 : prev + 1));
    }
    if (isRightSwipe && postImages.length > 1) {
      setActiveImageIndex(prev => (prev === 0 ? postImages.length - 1 : prev - 1));
    }
    setTouchStart(null);
    setTouchEnd(null);
  };

  const onMouseDownHandler = (e: React.MouseEvent) => {
    setIsMouseDragging(true);
    setMouseStartX(e.clientX);
  };

  const onMouseUpHandler = (e: React.MouseEvent) => {
    if (!isMouseDragging) return;
    setIsMouseDragging(false);
    const distance = mouseStartX - e.clientX;
    if (distance > minSwipeDistance && postImages.length > 1) {
      setActiveImageIndex(prev => (prev === postImages.length - 1 ? 0 : prev + 1));
    } else if (distance < -minSwipeDistance && postImages.length > 1) {
      setActiveImageIndex(prev => (prev === 0 ? postImages.length - 1 : prev - 1));
    }
  };

  return (
    <div id="download-menu-container" className="w-full max-w-[480px] md:max-w-[920px] lg:max-w-[960px] mx-auto px-4 py-4 sm:py-6 text-slate-900 dark:text-white antialiased">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 lg:gap-10 items-center">
        
        {/* Sol Taraf (Left): 1:1 (Post) veya 16:9 (Video) Görsel / Kapak Kartı */}
        <div className="flex flex-col gap-3">
          <div
            onTouchStart={isPost ? onTouchStartHandler : undefined}
            onTouchMove={isPost ? onTouchMoveHandler : undefined}
            onTouchEnd={isPost ? onTouchEndHandler : undefined}
            onMouseDown={isPost ? onMouseDownHandler : undefined}
            onMouseUp={isPost ? onMouseUpHandler : undefined}
            onMouseLeave={isPost ? () => setIsMouseDragging(false) : undefined}
            className={`relative ${isPost ? 'aspect-square max-w-[420px] mx-auto md:max-w-full cursor-grab active:cursor-grabbing select-none' : 'aspect-[16/9]'} w-full overflow-hidden rounded-[20px] bg-[#111] shadow-xl shadow-black/30 border border-slate-200/50 dark:border-white/10 group`}
          >
            {displayImage ? (
              <img
                src={displayImage}
                alt={title}
                draggable={false}
                onError={() => setImgFallbackLevel(prev => prev + 1)}
                className="absolute inset-0 h-full w-full object-cover transition-all duration-300 pointer-events-none"
              />
            ) : (
              <div className="absolute inset-0 bg-gradient-to-br from-zinc-900 to-black flex items-center justify-center">
                {isPost ? <ImageIcon className="w-12 h-12 text-white/30" /> : <Video className="w-12 h-12 text-white/30" />}
              </div>
            )}

            {/* Cinematic dark gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/55 to-black/80 pointer-events-none" />

            {/* Community Post Top Badge */}
            {isPost && (
              <div className="absolute top-3.5 left-3.5 z-20 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/15 text-white text-[11px] font-bold tracking-wide pointer-events-none">
                <span className="w-2 h-2 rounded-full bg-[#e50914]" />
                <span>COMMUNITY POST (1:1)</span>
                {postImages.length > 1 && (
                  <span className="ml-1 pl-1 border-l border-white/20 text-zinc-300">
                    {activeImageIndex + 1}/{postImages.length}
                  </span>
                )}
              </div>
            )}

            {/* Multi-image carousel buttons if post has multiple photos */}
            {isPost && postImages.length > 1 && (
              <div className="absolute inset-x-2 top-1/2 -translate-y-1/2 flex justify-between items-center z-20 pointer-events-auto">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveImageIndex(prev => (prev === 0 ? postImages.length - 1 : prev - 1));
                  }}
                  className="w-9 h-9 rounded-full bg-black/75 hover:bg-black text-white flex items-center justify-center border border-white/20 transition-all hover:scale-110 shadow-lg cursor-pointer backdrop-blur-xs"
                  title="Önceki fotoğraf (Sağa kaydır)"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveImageIndex(prev => (prev === postImages.length - 1 ? 0 : prev + 1));
                  }}
                  className="w-9 h-9 rounded-full bg-black/75 hover:bg-black text-white flex items-center justify-center border border-white/20 transition-all hover:scale-110 shadow-lg cursor-pointer backdrop-blur-xs"
                  title="Sonraki fotoğraf (Sola kaydır)"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            )}

            {/* Center-aligned title/text and channel info */}
            <div className="absolute inset-0 flex flex-col items-center justify-center px-6 sm:px-8 text-center z-10 pointer-events-none">
              <h1 className="w-full max-w-[92%] font-black text-[16px] sm:text-[18px] md:text-[20px] leading-[1.3] tracking-[-0.01em] text-white drop-shadow-[0_2px_14px_rgba(0,0,0,0.95)] line-clamp-3">
                {postText || title}
              </h1>
              <p className="mt-2.5 text-[13px] sm:text-[14px] font-semibold tracking-wide text-zinc-300 drop-shadow-[0_1px_8px_rgba(0,0,0,0.9)] flex items-center gap-1.5 justify-center">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#e50914]" />
                {channelTitle}
              </p>
            </div>
          </div>

          {/* Multi-Photo Thumbnail Bar / Indicators for Posts */}
          {isPost && postImages.length > 1 && (
            <div className="flex items-center justify-center gap-2 max-w-[420px] mx-auto md:max-w-full overflow-x-auto py-1 px-1">
              {postImages.map((imgUrl, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setActiveImageIndex(idx)}
                  className={`relative w-11 h-11 rounded-lg overflow-hidden border-2 transition-all cursor-pointer flex-shrink-0 ${
                    activeImageIndex === idx
                      ? 'border-[#e50914] scale-105 shadow-md shadow-[#e50914]/20 ring-2 ring-[#e50914]/40'
                      : 'border-white/10 opacity-60 hover:opacity-100'
                  }`}
                  title={`Fotoğraf ${idx + 1}`}
                >
                  <img
                    src={imgUrl}
                    alt={`Thumb ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                  {activeImageIndex === idx && (
                    <div className="absolute inset-0 bg-[#e50914]/15" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Sağ Taraf (Right): İndirme Seçenekleri / Controls Container */}
        <div className="w-full flex flex-col justify-center">
          {/* Format Switcher */}
          {isPost ? (
            /* Post Image Formats (JPG / PNG) */
            <div className="flex gap-2">
              {(['JPG', 'PNG'] as const).map((fmt) => (
                <button
                  key={fmt}
                  type="button"
                  onClick={() => setFormat(fmt)}
                  className={`flex-1 h-[40px] rounded-[12px] flex items-center justify-center gap-1.5 text-[13px] font-bold tracking-wide border transition-all cursor-pointer ${
                    format === fmt
                      ? 'bg-[#e50914] border-[#e50914] text-white shadow-[0_4px_16px_rgba(229,9,20,0.35)]'
                      : 'bg-white dark:bg-[#1e1e1e] border-slate-200 dark:border-white/[0.07] text-slate-700 dark:text-white/60 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-[#252525] shadow-xs'
                  }`}
                >
                  <ImageIcon className="h-3.5 w-3.5" /> {fmt}
                </button>
              ))}
            </div>
          ) : (
            /* Video Formats (MP4 / MP3) */
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setFormat('MP4');
                  setSelectedQuality('1080p');
                }}
                className={`flex-1 h-[40px] rounded-[12px] flex items-center justify-center gap-1.5 text-[13px] font-bold tracking-wide border transition-all cursor-pointer ${
                  format === 'MP4'
                    ? 'bg-[#e50914] border-[#e50914] text-white shadow-[0_4px_16px_rgba(229,9,20,0.35)]'
                    : 'bg-white dark:bg-[#1e1e1e] border-slate-200 dark:border-white/[0.07] text-slate-700 dark:text-white/60 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-[#252525] shadow-xs'
                }`}
              >
                <Video className="h-3.5 w-3.5" /> MP4
              </button>

              <button
                type="button"
                onClick={() => {
                  setFormat('MP3');
                  setSelectedQuality('320kbps');
                }}
                className={`flex-1 h-[40px] rounded-[12px] flex items-center justify-center gap-1.5 text-[13px] font-bold tracking-wide border transition-all cursor-pointer ${
                  format === 'MP3'
                    ? 'bg-[#e50914] border-[#e50914] text-white shadow-[0_4px_16px_rgba(229,9,20,0.35)]'
                    : 'bg-white dark:bg-[#1e1e1e] border-slate-200 dark:border-white/[0.07] text-slate-700 dark:text-white/60 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-[#252525] shadow-xs'
                }`}
              >
                <Music className="h-3.5 w-3.5" /> MP3
              </button>
            </div>
          )}

          {/* Quality Selector */}
          <div className="mt-3.5">
            <div className="mb-2 flex items-center justify-between px-0.5">
              <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400 dark:text-white/35">
                Quality
              </span>
              {isPost && postImages.length > 1 && (
                <span className="text-[11px] font-semibold text-[#e50914] flex items-center gap-1">
                  <Layers className="w-3 h-3" /> Photo {activeImageIndex + 1} of {postImages.length}
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              {(isPost ? imageQualities : (format === 'MP4' ? mp4Qualities : mp3Qualities)).map((q, idx) => {
                const disabled = isQualityDisabled(idx);
                const isSelected = selectedQuality === q;

                return (
                  <button
                    key={q}
                    type="button"
                    disabled={disabled}
                    onClick={() => !disabled && setSelectedQuality(q)}
                    className={`relative h-[36px] rounded-[12px] border text-[12.5px] font-semibold tracking-wide transition-all ${
                      disabled
                        ? 'cursor-not-allowed border-slate-200 dark:border-white/[0.08] bg-slate-100/80 dark:bg-[#1a1a1a]/80 text-slate-400 dark:text-zinc-400 opacity-60 pointer-events-none select-none'
                        : isSelected
                        ? 'border-[#e50914] bg-red-50 text-[#e50914] dark:bg-[#e50914]/15 dark:text-white font-bold ring-1 ring-[#e50914]/30 dark:ring-0 shadow-xs cursor-pointer'
                        : 'border-slate-200 dark:border-white/[0.06] bg-white dark:bg-[#1e1e1e] text-slate-700 dark:text-white/70 hover:bg-slate-50 dark:hover:bg-[#252525] hover:text-slate-900 dark:hover:text-white shadow-xs cursor-pointer'
                    }`}
                  >
                    {q}
                    {isSelected && !disabled && (
                      <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full border-2 border-white dark:border-[#121212] bg-[#e50914] shadow-xs">
                        <Check className="h-2.5 w-2.5 text-white" strokeWidth={3} />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Download Action Button */}
          <button
            type="button"
            id="main-download-action-btn"
            onClick={handleDownload}
            disabled={isDownloading}
            className="mt-4 flex h-[44px] w-full items-center justify-center gap-2 rounded-[12px] bg-[#e50914] text-[13.5px] font-black tracking-wide text-white shadow-[0_8px_24px_rgba(229,9,20,0.4)] transition-all hover:bg-[#ff1220] active:scale-[0.99] cursor-pointer disabled:opacity-80"
          >
            {isDownloading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : downloadSuccess ? (
              <Check className="h-4 w-4 text-white" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            {downloadButtonText}
          </button>

          {error && (
            <p className="mt-2.5 text-xs text-red-500 font-semibold text-center flex items-center justify-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
              {error}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

