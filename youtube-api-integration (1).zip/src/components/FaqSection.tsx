import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { FAQ_LIST } from '../data/mockData';

export function FaqSection() {
  const [openId, setOpenId] = useState<string | null>(null);

  const toggle = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section id="faq-section" className="w-full max-w-5xl mx-auto px-4 pt-4 pb-16">
      <div className="w-full divide-y divide-slate-200 dark:divide-zinc-800 border-t border-b border-slate-200 dark:border-zinc-800">
        {FAQ_LIST.map((faq) => {
          const isOpen = openId === faq.id;
          return (
            <div
              key={faq.id}
              className="py-1"
            >
              <button
                type="button"
                id={`faq-btn-${faq.id}`}
                onClick={() => toggle(faq.id)}
                className="w-full py-4 text-left flex items-center justify-between gap-4 group cursor-pointer select-none"
                aria-expanded={isOpen}
              >
                <span
                  className={`text-base sm:text-lg font-bold transition-colors duration-200 ${
                    isOpen
                      ? 'text-[#e50914] dark:text-[#ef4444]'
                      : 'text-slate-900 dark:text-zinc-100 group-hover:text-[#e50914] dark:group-hover:text-[#ef4444]'
                  }`}
                >
                  {faq.question}
                </span>
                <motion.div
                  animate={{ rotate: isOpen ? 180 : 0 }}
                  transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                  className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-colors duration-200 ${
                    isOpen 
                      ? 'text-[#e50914] dark:text-[#ef4444] bg-red-50 dark:bg-red-950/40' 
                      : 'text-slate-400 dark:text-zinc-500 group-hover:text-[#e50914] dark:group-hover:text-[#ef4444]'
                  }`}
                >
                  <ChevronDown className="w-5 h-5 stroke-[2.5]" />
                </motion.div>
              </button>

              {/* Buttery smooth height and fade animation */}
              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    key={`faq-content-${faq.id}`}
                    initial={{ height: 0, opacity: 0 }}
                    animate={{
                      height: 'auto',
                      opacity: 1,
                      transition: {
                        height: { duration: 0.32, ease: [0.16, 1, 0.3, 1] },
                        opacity: { duration: 0.25, delay: 0.05, ease: 'easeOut' },
                      },
                    }}
                    exit={{
                      height: 0,
                      opacity: 0,
                      transition: {
                        height: { duration: 0.25, ease: [0.16, 1, 0.3, 1] },
                        opacity: { duration: 0.15, ease: 'easeIn' },
                      },
                    }}
                    className="overflow-hidden"
                  >
                    <div className="pb-5 pr-4 sm:pr-8 text-slate-600 dark:text-zinc-300 text-sm sm:text-base leading-relaxed font-medium">
                      <motion.p
                        initial={{ y: -6, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -4, opacity: 0 }}
                        transition={{ duration: 0.25, ease: 'easeOut' }}
                      >
                        {faq.answer}
                      </motion.p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </section>
  );
}
