import { useState } from 'react';
import { 
  X, 
  Download, 
  CheckCircle2, 
  Music, 
  Video, 
  User,
  Eye
} from 'lucide-react';
import { VideoMetadata, VideoFormat, DownloadHistoryItem } from '../types';
import { triggerFileDownload } from '../utils/downloader';

interface DownloadModalProps {
  video: VideoMetadata;
  onClose: () => void;
  onDownloaded?: (item: DownloadHistoryItem) => void;
}

export function DownloadModal({ video, onClose, onDownloaded }: DownloadModalProps) {
  const [selectedFormatId, setSelectedFormatId] = useState<string>(video.formats[0]?.id || '');
  const [activeTab, setActiveTab] = useState<'video' | 'audio'>('video');
  const [includeSubtitles, setIncludeSubtitles] = useState(false);
  const [selectedSubtitle, setSelectedSubtitle] = useState('en');
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadSpeed, setDownloadSpeed] = useState('14.2 MB/s');
  const [downloadComplete, setDownloadComplete] = useState(false);

  const selectedFormat = video.formats.find((f: VideoFormat) => f.id === selectedFormatId) || video.formats[0];
  const filteredFormats = video.formats.filter((f: VideoFormat) => f.type === activeTab);

  const handleStartDownload = () => {
    if (!selectedFormat) return;
    setIsDownloading(true);
    setDownloadProgress(0);

    let current = 0;
    const interval = setInterval(() => {
      current += Math.floor(Math.random() * 15) + 12;
      if (current >= 100) {
        current = 100;
        clearInterval(interval);
        setTimeout(() => {
          triggerFileDownload(video.title, selectedFormat.format, selectedFormat.quality);
          const historyItem: DownloadHistoryItem = {
            id: `dl-${Date.now()}`,
            title: video.title,
            platform: video.platform,
            thumbnail: video.thumbnail,
            format: selectedFormat.format,
            quality: selectedFormat.quality,
            size: selectedFormat.size,
            downloadedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            timestamp: Date.now()
          };
          if (onDownloaded) {
            onDownloaded(historyItem);
          }
          setIsDownloading(false);
          setDownloadComplete(true);
        }, 400);
      }
      setDownloadProgress(Math.min(current, 100));
      setDownloadSpeed(`${(Math.random() * 8 + 10).toFixed(1)} MB/s`);
    }, 180);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white dark:bg-zinc-900 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-slate-100 dark:border-zinc-800 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-zinc-800 flex items-center justify-between bg-slate-50/70 dark:bg-zinc-900/90">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-[#e50914] animate-pulse"></span>
            <span className="font-inter-800 text-sm sm:text-base text-slate-900 dark:text-white">
              4K Video Downloader
            </span>
          </div>
          <button
            id="close-modal-btn"
            onClick={onClose}
            className="p-1.5 text-slate-400 dark:text-zinc-500 hover:text-slate-700 dark:hover:text-zinc-200 hover:bg-slate-200/60 dark:hover:bg-zinc-800 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Video Metadata Card */}
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center bg-slate-50 dark:bg-zinc-800/80 p-4 rounded-2xl border border-slate-100 dark:border-zinc-700/60">
            <div className="relative w-full sm:w-44 h-28 shrink-0 rounded-xl overflow-hidden bg-slate-200 dark:bg-zinc-700">
              <img
                src={video.thumbnail}
                alt={video.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-2 right-2 px-1.5 py-0.5 bg-black/80 text-white text-[11px] font-bold rounded">
                {video.duration}
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base leading-snug line-clamp-2 mb-1.5">
                {video.title}
              </h3>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 dark:text-zinc-400 font-bold">
                <span className="flex items-center gap-1">
                  <User className="w-3.5 h-3.5" />
                  {video.author}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5" />
                  {video.views}
                </span>
              </div>
            </div>
          </div>

          {/* Download Completion View */}
          {downloadComplete ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-[#e50914]/15 text-[#e50914] rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
              </div>
              <div>
                <h4 className="text-xl font-inter-800 text-slate-900 dark:text-white">Download Complete!</h4>
                <p className="text-slate-500 dark:text-zinc-400 text-sm mt-1">
                  {selectedFormat.quality} ({selectedFormat.format.toUpperCase()}) saved to your device.
                </p>
              </div>
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => {
                    setDownloadComplete(false);
                    setDownloadProgress(0);
                  }}
                  className="px-5 py-2.5 rounded-full border border-slate-200 dark:border-zinc-700 text-slate-700 dark:text-zinc-300 text-sm font-bold hover:bg-slate-50 dark:hover:bg-zinc-800 cursor-pointer"
                >
                  Choose Another Quality
                </button>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-full bg-[#e50914] hover:bg-[#c90812] text-white text-sm font-bold shadow-md shadow-[#e50914]/25 cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          ) : isDownloading ? (
            /* Downloading Progress View */
            <div className="py-6 space-y-4">
              <div className="flex items-center justify-between text-sm font-bold text-slate-800 dark:text-zinc-200">
                <span>Downloading {selectedFormat.quality}...</span>
                <span className="text-[#e50914] font-bold">{downloadProgress}%</span>
              </div>

              {/* Progress bar in Red */}
              <div className="w-full h-3 bg-slate-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#e50914] transition-all duration-200 rounded-full"
                  style={{ width: `${downloadProgress}%` }}
                ></div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-zinc-400 font-bold">
                <span>Speed: {downloadSpeed}</span>
                <span>Size: {selectedFormat.size}</span>
              </div>
            </div>
          ) : (
            /* Quality & Format Selection */
            <div className="space-y-4">
              {/* Type Switcher (Video / Audio) */}
              <div className="flex items-center bg-slate-100 dark:bg-zinc-800 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('video');
                    const firstVid = video.formats.find((f: VideoFormat) => f.type === 'video');
                    if (firstVid) setSelectedFormatId(firstVid.id);
                  }}
                  className={`flex-1 py-2 rounded-lg text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    activeTab === 'video'
                      ? 'bg-white dark:bg-zinc-700 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-500 dark:text-zinc-400 hover:text-slate-800 dark:hover:text-white'
                  }`}
                >
                  <Video className="w-4 h-4" />
                  <span>Video (MP4 / 4K)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('audio');
                    const firstAud = video.formats.find((f: VideoFormat) => f.type === 'audio');
                    if (firstAud) setSelectedFormatId(firstAud.id);
                  }}
                  className={`flex-1 py-2 rounded-lg text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    activeTab === 'audio'
                      ? 'bg-white dark:bg-zinc-700 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-500 dark:text-zinc-400 hover:text-slate-800 dark:hover:text-white'
                  }`}
                >
                  <Music className="w-4 h-4" />
                  <span>Audio Only (MP3)</span>
                </button>
              </div>

              {/* Format List */}
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {filteredFormats.map((format: VideoFormat) => {
                  const isSelected = format.id === selectedFormatId;
                  return (
                    <div
                      key={format.id}
                      onClick={() => setSelectedFormatId(format.id)}
                      className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'border-[#e50914] bg-[#e50914]/5 dark:bg-[#e50914]/15 ring-1 ring-[#e50914]'
                          : 'border-slate-200 dark:border-zinc-700/80 hover:border-slate-300 dark:hover:border-zinc-600 bg-white dark:bg-zinc-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                            isSelected
                              ? 'border-[#e50914] bg-[#e50914]'
                              : 'border-slate-300 dark:border-zinc-600'
                          }`}
                        >
                          {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 dark:text-white text-sm">
                              {format.quality}
                            </span>
                            {format.watermarkFree && (
                              <span className="px-2 py-0.5 bg-red-100 dark:bg-red-950/80 text-red-700 dark:text-red-300 text-[10px] font-bold rounded-full border border-red-200/50">
                                No Watermark
                              </span>
                            )}
                            {format.fps && format.fps >= 60 && (
                              <span className="px-1.5 py-0.5 bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 text-[10px] font-bold rounded">
                                60 FPS
                              </span>
                            )}
                          </div>
                          <span className="text-xs text-slate-500 dark:text-zinc-400 font-medium">
                            {format.resolution || format.bitrate} • {format.format.toUpperCase()}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-xs font-bold text-slate-700 dark:text-zinc-300">{format.size}</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Subtitles Option for YouTube if available */}
              {video.subtitles && video.subtitles.length > 0 && activeTab === 'video' && (
                <div className="pt-2 border-t border-slate-100 dark:border-zinc-800 flex items-center justify-between">
                  <label className="flex items-center gap-2 text-xs sm:text-sm font-bold text-slate-700 dark:text-zinc-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeSubtitles}
                      onChange={(e) => setIncludeSubtitles(e.target.checked)}
                      className="rounded text-[#e50914] focus:ring-[#e50914] accent-[#e50914]"
                    />
                    <span>Download Subtitles (.SRT)</span>
                  </label>

                  {includeSubtitles && (
                    <select
                      value={selectedSubtitle}
                      onChange={(e) => setSelectedSubtitle(e.target.value)}
                      className="text-xs bg-slate-100 dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-lg px-2 py-1 outline-none text-slate-700 dark:text-zinc-200 font-bold"
                    >
                      {video.subtitles.map((sub: { lang: string; label: string }) => (
                        <option key={sub.lang} value={sub.lang}>
                          {sub.label}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        {!downloadComplete && !isDownloading && (
          <div className="px-6 py-4 bg-slate-50 dark:bg-zinc-900 border-t border-slate-100 dark:border-zinc-800 flex items-center justify-between">
            <div className="text-xs text-slate-500 dark:text-zinc-400 font-medium">
              Selected: <strong className="text-slate-800 dark:text-white font-bold">{selectedFormat?.quality}</strong> ({selectedFormat?.size})
            </div>

            <button
              id="confirm-download-btn"
              onClick={handleStartDownload}
              className="bg-[#e50914] hover:bg-[#c90812] active:scale-95 text-white font-bold text-sm px-6 py-2.5 rounded-full transition-all flex items-center gap-2 shadow-md shadow-[#e50914]/25 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Now</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
