import React from 'react';
import { CloudDownload } from 'lucide-react';

interface FooterProps {
  onScrollToHome?: () => void;
  onScrollToHowToUse?: () => void;
  onScrollToFaq?: () => void;
}

export function Footer({ onScrollToHome, onScrollToHowToUse, onScrollToFaq }: FooterProps) {
  const handleScrollHome = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onScrollToHome) {
      onScrollToHome();
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleScrollHelp = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onScrollToHowToUse) {
      onScrollToHowToUse();
    } else {
      const el = document.getElementById('process-banner-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollFaq = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onScrollToFaq) {
      onScrollToFaq();
    } else {
      const el = document.getElementById('faq-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="app-footer" className="w-full border-t border-slate-200 dark:border-zinc-800 py-8 px-4 mt-8 bg-slate-50/50 dark:bg-zinc-900/50">
      <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-zinc-400">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 bg-[#e50914] rounded-full flex items-center justify-center text-white">
            <CloudDownload className="w-3 h-3" />
          </div>
          <span className="font-bold text-slate-800 dark:text-zinc-100">4K Video Downloader Plus</span>
          <span>© {new Date().getFullYear()}</span>
        </div>

        {/* Footer links: Home, Help, FAQ */}
        <div className="flex items-center gap-6 font-bold text-slate-600 dark:text-zinc-400">
          <a 
            id="footer-home-link"
            href="#hero-downloader-section" 
            onClick={handleScrollHome}
            className="hover:text-[#e50914] dark:hover:text-[#ef4444] transition-colors cursor-pointer"
          >
            Home
          </a>
          <a 
            id="footer-help-link"
            href="#process-banner-section" 
            onClick={handleScrollHelp}
            className="hover:text-[#e50914] dark:hover:text-[#ef4444] transition-colors cursor-pointer"
          >
            Help
          </a>
          <a 
            id="footer-faq-link"
            href="#faq-section" 
            onClick={handleScrollFaq}
            className="hover:text-[#e50914] dark:hover:text-[#ef4444] transition-colors cursor-pointer"
          >
            FAQ
          </a>
        </div>
      </div>
    </footer>
  );
}
