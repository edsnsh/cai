import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Header } from './components/Header';
import { HeroDownloader, isValidYouTubeUrl } from './components/HeroDownloader';
import { DownloadMenu } from './components/DownloadMenu';
import { FeatureCards } from './components/FeatureCards';
import { ProcessBanner } from './components/ProcessBanner';
import { DownloadGuide } from './components/DownloadGuide';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';

export default function App() {
  const [currentUrl, setCurrentUrl] = useState<string>('');
  const [isDownloadView, setIsDownloadView] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Initialize dark mode from localStorage or system preference
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('4k_downloader_theme');
      if (saved !== null) {
        return saved === 'dark';
      }
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return true;
    }
  });

  // Sync dark mode class with root html, body and dataset
  useEffect(() => {
    const root = document.documentElement;
    const body = document.body;

    if (darkMode) {
      root.classList.add('dark');
      body.classList.add('dark');
      root.setAttribute('data-theme', 'dark');
      try {
        localStorage.setItem('4k_downloader_theme', 'dark');
      } catch {
        // ignore
      }
    } else {
      root.classList.remove('dark');
      body.classList.remove('dark');
      root.setAttribute('data-theme', 'light');
      try {
        localStorage.setItem('4k_downloader_theme', 'light');
      } catch {
        // ignore
      }
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  // Sync state with URL pathname & search parameters
  const checkUrlRoute = useCallback(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const urlParam = urlParams.get('url');
      const isDownloadPath = window.location.pathname.startsWith('/download') || Boolean(urlParam);

      if (isDownloadPath && urlParam && isValidYouTubeUrl(urlParam)) {
        setCurrentUrl(urlParam);
        setIsDownloadView(true);
      } else {
        setIsDownloadView(false);
      }
    } catch {
      // Fallback
    }
  }, []);

  useEffect(() => {
    checkUrlRoute();
    window.addEventListener('popstate', checkUrlRoute);
    return () => window.removeEventListener('popstate', checkUrlRoute);
  }, [checkUrlRoute]);

  // When user enters a URL to analyze & download
  const handleAnalyzeUrl = (url: string) => {
    if (!url || !url.trim()) return;
    const cleanUrl = url.trim();
    if (!isValidYouTubeUrl(cleanUrl)) return;
    
    setIsLoading(true);
    setCurrentUrl(cleanUrl);
    setIsDownloadView(true);

    // Update browser URL to /download?url=...
    try {
      const newPath = `/download?url=${encodeURIComponent(cleanUrl)}`;
      window.history.pushState({ url: cleanUrl }, '', newPath);
    } catch {
      // ignore history errors in sandboxed iframes
    }

    setTimeout(() => {
      setIsLoading(false);
    }, 300);

    // Scroll to top smoothly
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Nav scroll helpers with smooth view switching
  const handleScrollToHome = () => {
    if (isDownloadView) {
      setIsDownloadView(false);
      try {
        window.history.pushState({}, '', '/');
      } catch {
        // ignore
      }
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleScrollToHowToUse = () => {
    if (isDownloadView) {
      setIsDownloadView(false);
      try {
        window.history.pushState({}, '', '/');
      } catch {
        // ignore
      }
      setTimeout(() => {
        const el = document.getElementById('process-banner-section') || document.getElementById('download-guide-section');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 150);
    } else {
      const el = document.getElementById('process-banner-section') || document.getElementById('download-guide-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleScrollToFaq = () => {
    const el = document.getElementById('faq-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#fafbfc] dark:bg-[#18181b] text-[#1a1e29] dark:text-[#f4f4f5] flex flex-col font-sans transition-colors duration-300 justify-between">
      {/* Top Header Navbar: Home, Help, FAQ, Dark Mode Toggle */}
      <Header
        onScrollToHome={handleScrollToHome}
        onScrollToHowToUse={handleScrollToHowToUse}
        onScrollToFaq={handleScrollToFaq}
        darkMode={darkMode}
        onToggleDarkMode={toggleDarkMode}
        activeSection="home"
        isDownloadView={isDownloadView}
      />

      <main className="flex-1 w-full overflow-hidden">
        <AnimatePresence mode="wait">
          {isDownloadView ? (
            /* ========================================================================= */
            /* DOWNLOAD VIEW: Search Bar -> Download Menu (Artifact) -> FAQ              */
            /* ========================================================================= */
            <motion.div
              key="download-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="w-full flex flex-col items-center"
            >
              {/* 1. Sitedeki arama çubuğu (üstte, aynı kırmızı borderlı pill) */}
              <div className="w-full pt-4 pb-2">
                <HeroDownloader
                  onAnalyzeUrl={handleAnalyzeUrl}
                  isLoading={isLoading}
                  compact={true}
                  initialUrl={currentUrl}
                />
              </div>

              {/* 2. Attığım kod - İndirme Menüsü */}
              <div className="w-full my-2">
                <DownloadMenu
                  videoUrl={currentUrl}
                  onUrlChange={handleAnalyzeUrl}
                />
              </div>

              {/* 3. Sitedeki FAQ kısmı */}
              <div className="w-full mt-6">
                <FaqSection />
              </div>
            </motion.div>
          ) : (
            /* ========================================================================= */
            /* HOME VIEW: 1.Hero -> 2.Features -> 3.ProcessBanner -> 4.Guide -> 5.FAQ   */
            /* ========================================================================= */
            <motion.div
              key="home-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="w-full"
            >
              {/* 1. Hero & Downloader Input */}
              <HeroDownloader
                onAnalyzeUrl={handleAnalyzeUrl}
                isLoading={isLoading}
                compact={false}
              />

              {/* 2. Four Feature Cards Grid */}
              <FeatureCards />

              {/* 3. Gradient 4-Step Banner */}
              <ProcessBanner />

              {/* 4. YouTube 4K Download Guide Card */}
              <DownloadGuide />

              {/* 5. FAQ Accordion Section */}
              <FaqSection />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer with Home, Help, FAQ links */}
      <Footer
        onScrollToHome={handleScrollToHome}
        onScrollToHowToUse={handleScrollToHowToUse}
        onScrollToFaq={handleScrollToFaq}
      />
    </div>
  );
}
