import React, { useState } from 'react';
import { 
  CloudDownload, 
  Clipboard, 
  ArrowDownToLine, 
  Loader2, 
  AlertCircle,
  Link2,
  X
} from 'lucide-react';

interface HeroDownloaderProps {
  onAnalyzeUrl: (url: string) => void;
  isLoading: boolean;
  compact?: boolean;
  initialUrl?: string;
}

export function isValidYouTubeUrl(url: string): boolean {
  if (!url || typeof url !== 'string') return false;
  const cleanUrl = url.trim();

  // Direct YouTube video ID (11 characters)
  if (/^[a-zA-Z0-9_-]{11}$/.test(cleanUrl)) {
    return true;
  }

  // Regex matching any standard or shortened YouTube URL (watch, shorts, live, embed, youtu.be, music.youtube.com, m.youtube.com)
  const ytPattern = /^(https?:\/\/)?(www\.|m\.|music\.)?(youtube(?:-nocookie)?\.com\/(?:watch|shorts|live|embed|v|attribution_link)|youtu\.be\/)/i;
  return ytPattern.test(cleanUrl);
}

export function HeroDownloader({ onAnalyzeUrl, isLoading, compact = false, initialUrl = '' }: HeroDownloaderProps) {
  const [urlInput, setUrlInput] = useState(initialUrl);
  const [errorMsg, setErrorMsg] = useState('');

  // Sync initialUrl if it changes
  React.useEffect(() => {
    if (initialUrl) {
      setUrlInput(initialUrl);
    }
  }, [initialUrl]);

  const hasInput = urlInput.trim().length > 0;

  const validateAndProceed = (urlToTest: string) => {
    const trimmed = urlToTest.trim();
    if (!trimmed) {
      setErrorMsg('Please enter a valid YouTube or Shorts link.');
      return false;
    }

    if (!isValidYouTubeUrl(trimmed)) {
      setErrorMsg('Unsupported platform! Only YouTube and Shorts links are supported.');
      return false;
    }

    setErrorMsg('');
    onAnalyzeUrl(trimmed);
    return true;
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!hasInput) {
      handlePaste();
      return;
    }
    validateAndProceed(urlInput);
  };

  const handlePaste = async () => {
    let pastedText = '';
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text && text.trim()) {
          pastedText = text.trim();
        }
      }
    } catch {
      // Fallback
    }

    if (!pastedText) {
      const prompted = window.prompt('Paste YouTube video or Shorts link here:');
      if (prompted && prompted.trim()) {
        pastedText = prompted.trim();
      }
    }

    if (pastedText) {
      setUrlInput(pastedText);
      validateAndProceed(pastedText);
    }
  };

  const handleInputPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const pastedData = e.clipboardData.getData('text');
    if (pastedData) {
      const trimmed = pastedData.trim();
      if (!isValidYouTubeUrl(trimmed)) {
        setErrorMsg('Unsupported platform! Only YouTube and Shorts links are supported.');
      } else {
        setErrorMsg('');
      }
    }
  };

  const handleClear = () => {
    setUrlInput('');
    setErrorMsg('');
  };

  return (
    <section id="hero-downloader-section" className="w-full max-w-4xl mx-auto px-4 pt-4 sm:pt-6 pb-6 sm:pb-8 text-center flex flex-col items-center">
      {/* Top Red Cloud Icon */}
      <div className="mb-3.5 inline-flex items-center justify-center">
        <div className="w-16 h-16 sm:w-20 sm:h-20 bg-[#e50914] rounded-full flex items-center justify-center shadow-lg shadow-[#e50914]/30 transition-transform duration-300 hover:scale-105">
          <CloudDownload className="w-9 h-9 sm:w-11 sm:h-11 text-white stroke-[2.4]" />
        </div>
      </div>

      {/* Main Title with Inter 800 bold */}
      <h1 className="text-3xl sm:text-5xl md:text-6xl font-inter-800 text-[#111827] dark:text-white tracking-tight leading-[1.08] mb-3.5">
        4K Video<br />Downloader Plus
      </h1>

      {/* Platforms Description & Authentic YouTube Icon */}
      <div className="max-w-2xl text-center mb-5">
        <p className="text-slate-800 dark:text-zinc-200 font-bold text-sm sm:text-base mb-2.5">
          Download high quality videos from YouTube:
        </p>

        <div className="inline-flex flex-wrap items-center justify-center gap-2 text-xs sm:text-sm font-bold">
          {/* Authentic Official YouTube Icon Pill */}
          <span 
            id="youtube-platform-pill"
            className="inline-flex items-center gap-2 font-bold text-slate-900 dark:text-white bg-white dark:bg-zinc-800/90 px-3 py-1.5 rounded-full border border-slate-200 dark:border-zinc-700/80 shadow-xs transition-colors duration-250 ease-in-out"
          >
            <svg className="w-5 h-4 shrink-0" viewBox="0 0 28 20" fill="none">
              <path 
                d="M27.444 3.093a3.524 3.524 0 0 0-2.478-2.493C22.78 0 14 0 14 0S5.22 0 3.034.6A3.524 3.524 0 0 0 .556 3.093C0 5.292 0 9.866 0 9.866s0 4.573.556 6.772a3.524 3.524 0 0 0 2.478 2.494C5.22 19.733 14 19.733 14 19.733s8.78 0 10.966-.601a3.524 3.524 0 0 0 2.478-2.494C28 14.439 28 9.866 28 9.866s0-4.574-.556-6.773z" 
                fill="#FF0000" 
              />
              <polygon points="11.2,14.133 18.467,9.867 11.2,5.6" fill="#FFFFFF" />
            </svg>
            <span>YouTube &amp; Shorts</span>
          </span>

          <span className="text-slate-600 dark:text-zinc-400 font-bold ml-1">in 4K, Full HD & MP3.</span>
        </div>
      </div>

      {/* Main Pill Search / Input Box with Red Accent */}
      <div className="w-full max-w-2xl">
        <form
          onSubmit={handleSubmit}
          className="relative w-full flex items-center bg-white dark:bg-[#202024] rounded-full border-2 border-[#e50914] shadow-sm hover:shadow-md transition-all duration-200 p-1.5 sm:p-2"
        >
          <div className="pl-3 pr-2 text-slate-400 dark:text-zinc-400">
            <Link2 className="w-5 h-5 text-[#e50914] stroke-[2.4]" />
          </div>

          <input
            id="video-url-input"
            type="url"
            value={urlInput}
            onChange={(e) => {
              setUrlInput(e.target.value);
              if (errorMsg) setErrorMsg('');
            }}
            onPaste={handleInputPaste}
            placeholder="Paste YouTube video or Shorts link here..."
            className="flex-1 bg-transparent text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-zinc-400 text-sm sm:text-base outline-none px-1 py-1.5 font-bold min-w-0"
            disabled={isLoading}
          />

          {hasInput && !isLoading && (
            <button
              type="button"
              onClick={handleClear}
              className="p-1.5 text-slate-400 hover:text-slate-700 dark:text-zinc-400 dark:hover:text-zinc-200 rounded-full cursor-pointer mr-1 transition-transform active:scale-90"
              title="Clear input"
            >
              <X className="w-4 h-4 stroke-[2.4]" />
            </button>
          )}

          {/* Unified dynamic action button */}
          <div className="relative shrink-0 flex items-center justify-center">
            <button
              type={hasInput ? "submit" : "button"}
              id={hasInput ? "download-submit-btn" : "paste-action-btn"}
              disabled={isLoading}
              onClick={hasInput ? undefined : handlePaste}
              title={hasInput ? "Download video" : "Paste video link from clipboard"}
              aria-label={hasInput ? "Download" : "Paste link"}
              className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#e50914] hover:bg-[#c90812] active:scale-90 text-white flex items-center justify-center shadow-md shadow-[#e50914]/30 cursor-pointer disabled:opacity-75 transition-all duration-300 ease-out group relative overflow-hidden"
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin stroke-[2.6]" />
              ) : (
                <div className="relative w-5 h-5 flex items-center justify-center">
                  <Clipboard 
                    className={`w-5 h-5 absolute inset-0 stroke-[2.6] transition-all duration-300 ease-out ${
                      hasInput 
                        ? 'opacity-0 scale-50 rotate-45 pointer-events-none' 
                        : 'opacity-100 scale-100 rotate-0 group-hover:scale-110 group-hover:-rotate-6'
                    }`} 
                  />
                  <ArrowDownToLine 
                    className={`w-5 h-5 absolute inset-0 stroke-[2.6] transition-all duration-300 ease-out ${
                      hasInput 
                        ? 'opacity-100 scale-100 rotate-0 group-hover:translate-y-0.5 group-hover:scale-110' 
                        : 'opacity-0 scale-50 -rotate-45 pointer-events-none'
                    }`} 
                  />
                </div>
              )}
            </button>
          </div>
        </form>

        {/* Error message */}
        {errorMsg && (
          <div className="mt-2 text-xs sm:text-sm text-red-500 font-bold flex items-center justify-center gap-1.5 animate-fadeInSmooth">
            <AlertCircle className="w-4 h-4 stroke-[2.2]" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>
    </section>
  );
}
