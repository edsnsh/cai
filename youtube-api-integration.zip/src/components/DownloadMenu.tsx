import React, { useState, useMemo, useEffect } from 'react';
import { Video, Music, Download, Check, Loader2, AlertCircle, RefreshCw } from 'lucide-react';

export interface VideoInfoData {
  id: string;
  title: string;
  channelTitle: string;
  thumbnail: string;
  duration?: string;
  maxQuality: string;
  availableQualities: string[];
  availableAudioQualities?: string[];
  previewUrl?: string;
  url: string;
}

interface DownloadMenuProps {
  videoUrl: string;
  onUrlChange?: (newUrl: string) => void;
}

// Client-side oEmbed fallback helper
async function resolveClientYouTubeMeta(videoId: string) {
  try {
    const res = await fetch(`https://noembed.com/embed?url=https://www.youtube.com/watch?v=${videoId}`);
    if (res.ok) {
      const data = await res.json();
      if (data.title || data.author_name) {
        return {
          title: data.title || '',
          channelTitle: data.author_name || '',
          thumbnail: data.thumbnail_url || `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`
        };
      }
    }
  } catch {
    // continue
  }

  try {
    const res2 = await fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`);
    if (res2.ok) {
      const data = await res2.json();
      if (data.title || data.author_name) {
        return {
          title: data.title || '',
          channelTitle: data.author_name || '',
          thumbnail: data.thumbnail_url || `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`
        };
      }
    }
  } catch {
    // continue
  }

  return null;
}

export function DownloadMenu({ videoUrl }: DownloadMenuProps) {
  const [format, setFormat] = useState<'MP4' | 'MP3'>('MP4');
  const [selectedQuality, setSelectedQuality] = useState<string>('1080p');
  const [videoData, setVideoData] = useState<VideoInfoData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [imgFallbackLevel, setImgFallbackLevel] = useState<number>(0);

  const mp4Qualities = useMemo(() => ['144p', '360p', '720p', '1080p', '2K', '4K'], []);
  const mp3Qualities = useMemo(() => ['64kbps', '128kbps', '192kbps', '256kbps', '320kbps', 'FLAC'], []);

  // Fetch video data from API
  useEffect(() => {
    let isMounted = true;
    async function fetchInfo() {
      if (!videoUrl) return;
      setIsLoading(true);
      setError(null);
      setImgFallbackLevel(0);

      // Extract YouTube ID locally
      let ytId = '';
      const match = videoUrl.match(/(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/|live\/))([a-zA-Z0-9_-]{11})/i);
      if (match && match[1]) {
        ytId = match[1];
      } else if (/^[a-zA-Z0-9_-]{11}$/.test(videoUrl.trim())) {
        ytId = videoUrl.trim();
      }

      let fetchedData: VideoInfoData | null = null;

      try {
        const res = await fetch(`/api/info?url=${encodeURIComponent(videoUrl)}`);
        if (res.ok) {
          fetchedData = await res.json();
        }
      } catch {
        // Fallback to client extraction
      }

      // If backend returned default placeholder or failed, resolve directly on client
      if (!fetchedData || !fetchedData.title || fetchedData.title === 'YouTube Video' || fetchedData.channelTitle === 'YouTube Channel' || fetchedData.channelTitle === 'YouTube Creator') {
        if (ytId) {
          const clientMeta = await resolveClientYouTubeMeta(ytId);
          if (clientMeta) {
            fetchedData = {
              id: ytId,
              title: clientMeta.title || fetchedData?.title || 'YouTube Video',
              channelTitle: clientMeta.channelTitle || fetchedData?.channelTitle || 'YouTube Creator',
              thumbnail: clientMeta.thumbnail || fetchedData?.thumbnail || `https://img.youtube.com/vi/${ytId}/maxresdefault.jpg`,
              duration: fetchedData?.duration || '04:15',
              maxQuality: fetchedData?.maxQuality || '4K',
              availableQualities: mp4Qualities,
              availableAudioQualities: mp3Qualities,
              url: videoUrl
            };
          }
        }
      }

      if (!isMounted) return;

      if (fetchedData) {
        setVideoData(fetchedData);
        if (fetchedData.maxQuality && mp4Qualities.includes(fetchedData.maxQuality)) {
          setSelectedQuality(fetchedData.maxQuality);
        } else {
          setSelectedQuality('1080p');
        }
      } else {
        // Final fallback structure
        setVideoData({
          id: ytId || 'custom-yt',
          title: ytId ? `YouTube Video (${ytId})` : 'YouTube Video',
          channelTitle: 'YouTube Creator',
          thumbnail: ytId ? `https://img.youtube.com/vi/${ytId}/hqdefault.jpg` : '',
          duration: '03:45',
          maxQuality: '4K',
          availableQualities: mp4Qualities,
          availableAudioQualities: mp3Qualities,
          url: videoUrl
        });
      }

      setIsLoading(false);
    }

    fetchInfo();
    return () => {
      isMounted = false;
    };
  }, [videoUrl, mp4Qualities, mp3Qualities]);

  // Determine which qualities are disabled based on maxQuality
  const maxQualityIndex = useMemo(() => {
    if (!videoData?.maxQuality) return 3; // default 1080p index
    const mq = videoData.maxQuality.toLowerCase();
    if (mq.includes('4k') || mq.includes('2160')) return 5;
    if (mq.includes('2k') || mq.includes('1440')) return 4;
    if (mq.includes('1080')) return 3;
    if (mq.includes('720')) return 2;
    if (mq.includes('360')) return 1;
    if (mq.includes('144')) return 0;
    return 3;
  }, [videoData]);

  const isQualityDisabled = (index: number) => {
    if (format === 'MP4') {
      return index > maxQualityIndex;
    }
    // Audio qualities are all available
    return false;
  };

  // Button text
  const downloadButtonText = useMemo(() => {
    if (isDownloading) return 'Preparing Download...';
    if (downloadSuccess) return 'Download Started!';
    return `Download ${selectedQuality}`;
  }, [selectedQuality, isDownloading, downloadSuccess]);

  // Handle download trigger
  const handleDownload = async () => {
    if (isDownloading) return;
    setIsDownloading(true);
    setDownloadSuccess(false);

    try {
      // Direct call to download endpoint
      const downloadUrl = `/api/download?url=${encodeURIComponent(videoUrl)}&quality=${encodeURIComponent(selectedQuality)}&format=${format.toLowerCase()}`;
      
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.setAttribute('download', '');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setDownloadSuccess(true);
      setTimeout(() => {
        setDownloadSuccess(false);
      }, 4000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsDownloading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="w-full max-w-[480px] mx-auto px-4 py-12 flex flex-col items-center justify-center">
        <div className="w-12 h-12 rounded-full border-2 border-white/10 border-t-[#e50914] animate-spin mb-4" />
        <p className="text-white/60 font-semibold text-sm animate-pulse">Loading video details & formats...</p>
      </div>
    );
  }

  if (error && !videoData) {
    return (
      <div className="w-full max-w-[480px] mx-auto px-4 py-8 text-center bg-[#1e1e1e] rounded-[20px] border border-red-500/20 my-4">
        <AlertCircle className="w-10 h-10 text-red-500 mx-auto mb-3" />
        <h3 className="text-white font-bold text-lg mb-2">Could Not Load Video</h3>
        <p className="text-white/60 text-sm mb-4">{error}</p>
        <button
          onClick={() => window.location.reload()}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#e50914] text-white font-bold text-xs"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Try Again
        </button>
      </div>
    );
  }

  const ytId = videoData?.id;
  const title = videoData?.title || 'YouTube Video';
  const channelTitle = videoData?.channelTitle || 'YouTube Creator';
  const thumbnail = imgFallbackLevel === 0
    ? (videoData?.thumbnail || (ytId ? `https://img.youtube.com/vi/${ytId}/maxresdefault.jpg` : ''))
    : (ytId ? `https://img.youtube.com/vi/${ytId}/hqdefault.jpg` : '');

  return (
    <div id="download-menu-container" className="w-full max-w-[480px] mx-auto px-4 py-4 sm:py-6 text-slate-900 dark:text-white antialiased">
      {/* Cover: Video thumbnail with cinematic gradient overlay */}
      <div className="relative aspect-[16/9] w-full overflow-hidden rounded-[20px] bg-[#111] shadow-lg shadow-black/40 border border-slate-200/50 dark:border-white/5">
        {thumbnail ? (
          <img
            src={thumbnail}
            alt={title}
            onError={() => setImgFallbackLevel(prev => prev + 1)}
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 hover:scale-105"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-zinc-900 to-black flex items-center justify-center">
            <Video className="w-12 h-12 text-white/30" />
          </div>
        )}

        {/* Cinematic dark gradient overlay for optimal legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/45 to-black/25 pointer-events-none" />

        {/* Centered / bottom video title and channel text */}
        <div className="absolute inset-x-0 bottom-0 flex flex-col items-center justify-end px-5 py-4 text-center z-10 pointer-events-none">
          <h1 className="w-full font-black text-[16px] sm:text-[18.5px] leading-[1.3] tracking-[-0.01em] text-white drop-shadow-[0_2px_12px_rgba(0,0,0,0.95)] line-clamp-2">
            {title}
          </h1>
          <p className="mt-1.5 text-[13px] font-semibold tracking-wide text-zinc-300 drop-shadow-[0_1px_8px_rgba(0,0,0,0.9)] flex items-center gap-1.5 justify-center">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#e50914]" />
            {channelTitle}
          </p>
        </div>
      </div>

      {/* Controls Container */}
      <div className="mt-5">
        {/* Format Switcher (MP4 / MP3) */}
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => {
              setFormat('MP4');
              setSelectedQuality('1080p');
            }}
            className={`flex-1 h-[40px] rounded-[12px] flex items-center justify-center gap-1.5 text-[13px] font-bold tracking-wide border transition-all cursor-pointer ${
              format === 'MP4'
                ? 'bg-[#e50914] border-[#e50914] text-white shadow-[0_4px_16px_rgba(229,9,20,0.35)]'
                : 'bg-white dark:bg-[#1e1e1e] border-slate-200 dark:border-white/[0.07] text-slate-700 dark:text-white/60 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-[#252525] shadow-xs'
            }`}
          >
            <Video className="h-3.5 w-3.5" /> MP4
          </button>

          <button
            type="button"
            onClick={() => {
              setFormat('MP3');
              setSelectedQuality('320kbps');
            }}
            className={`flex-1 h-[40px] rounded-[12px] flex items-center justify-center gap-1.5 text-[13px] font-bold tracking-wide border transition-all cursor-pointer ${
              format === 'MP3'
                ? 'bg-[#e50914] border-[#e50914] text-white shadow-[0_4px_16px_rgba(229,9,20,0.35)]'
                : 'bg-white dark:bg-[#1e1e1e] border-slate-200 dark:border-white/[0.07] text-slate-700 dark:text-white/60 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-[#252525] shadow-xs'
            }`}
          >
            <Music className="h-3.5 w-3.5" /> MP3
          </button>
        </div>

        {/* Quality Selector */}
        <div className="mt-4">
          <div className="mb-2 flex items-center justify-between px-0.5">
            <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400 dark:text-white/35">
              Quality
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {(format === 'MP4' ? mp4Qualities : mp3Qualities).map((q, idx) => {
              const disabled = isQualityDisabled(idx);
              const isSelected = selectedQuality === q;

              return (
                <button
                  key={q}
                  type="button"
                  disabled={disabled}
                  onClick={() => !disabled && setSelectedQuality(q)}
                  className={`relative h-[36px] rounded-[12px] border text-[12.5px] font-semibold tracking-wide transition-all ${
                    disabled
                      ? 'cursor-not-allowed border-slate-200/50 dark:border-white/[0.03] bg-slate-100 dark:bg-[#141414] text-slate-300 dark:text-white/20 opacity-35 blur-[0.4px] pointer-events-none'
                      : isSelected
                      ? 'border-[#e50914] bg-red-50 text-[#e50914] dark:bg-[#e50914]/15 dark:text-white font-bold ring-1 ring-[#e50914]/30 dark:ring-0 shadow-xs cursor-pointer'
                      : 'border-slate-200 dark:border-white/[0.06] bg-white dark:bg-[#1e1e1e] text-slate-700 dark:text-white/70 hover:bg-slate-50 dark:hover:bg-[#252525] hover:text-slate-900 dark:hover:text-white shadow-xs cursor-pointer'
                  }`}
                >
                  {q}
                  {isSelected && !disabled && (
                    <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full border-2 border-white dark:border-[#121212] bg-[#e50914] shadow-xs">
                      <Check className="h-2.5 w-2.5 text-white" strokeWidth={3} />
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Download Action Button */}
        <button
          type="button"
          id="main-download-action-btn"
          onClick={handleDownload}
          disabled={isDownloading}
          className="mt-4 flex h-[44px] w-full items-center justify-center gap-2 rounded-[12px] bg-[#e50914] text-[13.5px] font-black tracking-wide text-white shadow-[0_8px_24px_rgba(229,9,20,0.4)] transition-all hover:bg-[#ff1220] active:scale-[0.99] cursor-pointer disabled:opacity-80"
        >
          {isDownloading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : downloadSuccess ? (
            <Check className="h-4 w-4 text-white" />
          ) : (
            <Download className="h-4 w-4" />
          )}
          {downloadButtonText}
        </button>
      </div>
    </div>
  );
}
