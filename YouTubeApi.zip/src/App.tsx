import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroDownloader } from './components/HeroDownloader';
import { FeatureCards } from './components/FeatureCards';
import { ProcessBanner } from './components/ProcessBanner';
import { DownloadGuide } from './components/DownloadGuide';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';

export default function App() {
  const [analyzing, setAnalyzing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('4k_downloader_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  // Sync dark mode class with root html and body
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
      document.documentElement.setAttribute('data-theme', 'dark');
      try {
        localStorage.setItem('4k_downloader_theme', 'dark');
      } catch {
        // ignore
      }
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
      document.documentElement.removeAttribute('data-theme');
      try {
        localStorage.setItem('4k_downloader_theme', 'light');
      } catch {
        // ignore
      }
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  const handleAnalyzeUrl = async (_url: string) => {
    setAnalyzing(true);
    setTimeout(() => {
      setAnalyzing(false);
    }, 500);
  };

  const scrollToHome = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToHowToUse = () => {
    const el = document.getElementById('process-banner-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToFaq = () => {
    const el = document.getElementById('faq-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#fafbfc] dark:bg-[#18181b] text-[#1a1e29] dark:text-[#f4f4f5] flex flex-col font-sans transition-colors duration-200">
      {/* Top Header Navbar: Home, Help, FAQ, Dark Mode Toggle */}
      <Header
        onScrollToHome={scrollToHome}
        onScrollToHowToUse={scrollToHowToUse}
        onScrollToFaq={scrollToFaq}
        darkMode={darkMode}
        onToggleDarkMode={toggleDarkMode}
      />

      {/* Main Content Sections */}
      <main className="flex-1 w-full">
        {/* 1. Hero & Downloader Input */}
        <HeroDownloader
          onAnalyzeUrl={handleAnalyzeUrl}
          isLoading={analyzing}
        />

        {/* 2. Four Feature Cards Grid */}
        <FeatureCards />

        {/* 3. Gradient 4-Step Banner */}
        <ProcessBanner />

        {/* 4. YouTube 4K Download Guide Card */}
        <DownloadGuide />

        {/* 5. FAQ Accordion Section */}
        <FaqSection />
      </main>

      {/* Footer with Home, Help, FAQ links */}
      <Footer 
        onScrollToHome={scrollToHome}
        onScrollToHowToUse={scrollToHowToUse}
        onScrollToFaq={scrollToFaq}
      />

      {/* Toast Notification with Red accent */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 dark:bg-zinc-800 text-white px-5 py-3 rounded-full text-xs sm:text-sm font-bold shadow-2xl flex items-center gap-2.5 animate-fadeInSmooth border border-slate-700/50">
          <span className="w-2.5 h-2.5 rounded-full bg-[#e50914]"></span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
