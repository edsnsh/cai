import { Play, Music, Shield, Sparkles } from 'lucide-react';

export function FeatureCards() {
  const cards = [
    {
      id: 'feature-shorts',
      icon: <Play className="w-5 h-5 text-white fill-white stroke-[2.5]" />,
      title: 'Download YouTube Videos & Shorts in HD',
      description:
        'Easily save public videos from YouTube in original quality. Download YouTube videos and YouTube Shorts in 4K Ultra HD, 1080p Full HD and 60fps. The fastest free online YouTube video downloader for Windows, Mac, Android and iOS.'
    },
    {
      id: 'feature-dubbed',
      icon: <Music className="w-5 h-5 text-white stroke-[2.5]" />,
      title: 'YouTube to MP3 Converter - 320kbps',
      description:
        'Convert YouTube to MP3 and M4A in high quality. Save music, podcasts and audio from YouTube with multi-language support as 320kbps MP3. Best free YouTube MP3 downloader and YouTube to M4A converter online.'
    },
    {
      id: 'feature-protected',
      icon: <Shield className="w-5 h-5 text-white stroke-[2.5]" />,
      title: 'Download YouTube 4K 60FPS with HDR',
      description:
        'Download YouTube videos in true 4K Ultra HD, 60FPS and HDR with no quality loss. Experience crystal-clear YouTube 4K 60fps downloads with original audio. Optimized for high-framerate playback on desktop, tablet and mobile.'
    },
    {
      id: 'feature-smart-mode',
      icon: <Sparkles className="w-5 h-5 text-white stroke-[2.5]" />,
      title: 'Safe & Fast YouTube Downloader - GDPR',
      description:
        '4K Video Downloader Plus is 100% safe, GDPR compliant and SSL secured. Download YouTube videos in 4K, 1080p and MP3 with zero tracking and no login required. The most trusted free YouTube downloader for all devices in Europe.'
    }
  ];

  return (
    <section id="features-grid-section" className="w-full max-w-4xl mx-auto px-4 py-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {cards.map((card) => (
          <div
            key={card.id}
            id={card.id}
            className="group bg-white dark:bg-zinc-900 rounded-2xl p-5 sm:p-6 border border-slate-200/90 dark:border-zinc-800 shadow-md hover:shadow-xl hover:border-slate-300 dark:hover:border-zinc-700 transition-all duration-200 flex flex-col justify-start"
          >
            {/* Simple, Soft-cornered Bold Icon Badge */}
            <div className="w-10 h-10 rounded-xl bg-[#e50914] text-white flex items-center justify-center mb-4 shadow-md shadow-[#e50914]/25 group-hover:scale-105 transition-transform duration-200">
              {card.icon}
            </div>

            <h3 className="text-lg sm:text-xl font-inter-800 text-slate-900 dark:text-white tracking-tight leading-snug mb-2 group-hover:text-[#e50914] dark:group-hover:text-[#ef4444] transition-colors">
              {card.title}
            </h3>

            <p className="text-slate-600 dark:text-zinc-300 text-xs sm:text-sm leading-relaxed">
              {card.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
